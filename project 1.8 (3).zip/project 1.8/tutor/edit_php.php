<?php
session_start();
$id=$_SESSION['id'];
//$id=11;

include("../config.php");
if(isset($_GET['old']))
{
$nleng=strlen($_GET['new']);
$cleng=strlen($_GET['new']);
if($nleng>7)
{
if($_GET['new']==$_GET['cnew'])
{

$result=mysql_query("update tutor set password='".$_GET['new']."' where password='".$_GET['old']."' and id=".$id."");
$no=mysql_affected_rows();

if($no==1)
{
	echo "<td colspan='3' style='color:green'>Password Successfully Updated</td>";
}
else
{
echo "<td colspan='3' style='color:red'>Incorrect old Not Match</td>";
}
}
else
{
	echo "<td colspan='3' style='color:red'>Confirm Password dose Not Match</td>";
}
}
else
{
	echo "<td colspan='3' style='color:red'>At Least 8 Character Password </td>";
}
}
if(isset($_GET['tadd']))
{
	//echo $_GET['neigh'];
	//echo "update t_info set t_p_add='".$_GET['padd']."'";
$result=mysql_query("update t_info set t_p_add='".$_GET['padd']."',t_city='".$_GET['city']."', t_state='".$_GET['state']."', t_zip='".$_GET['zip']."',t_nb='".$_GET['neigh']."' where t_id=".$id."");
$no=mysql_affected_rows();

if($no==1)
{
	echo "<td colspan='3' style='color:green'>Address Successfully Updated</td>";
}
else
{
echo "<td colspan='3' style='color:red'>Eroor..</td>";
}
}
if(isset($_GET['qual']))
{
	//echo $_GET['neigh'];
	//echo "update t_info set t_p_add='".$_GET['padd']."'";
$result=mysql_query("update t_info set t_edu='".$_GET['qual']."',t_date='".$_GET['date']."', t_exp='".$_GET['expe']."' where t_id=".$id."");
$no=mysql_affected_rows();

if($no>0)
{
	echo "<td colspan='3' style='color:green'>Qualification Successfully Updated</td>";
}
else
{
echo "<td colspan='3' style='color:red'>Eroor..</td>";
}
}
if(isset($_GET['session']))
{
	//echo $_GET['neigh'];
	//echo "update t_info set t_p_add='".$_GET['padd']."'";
	//echo "update t_info set t_ses='".$_GET['session']."',t_noofstud='".$_GET['stud']."', t_s_time='".$_GET['stime']."',t_e_time='".$_GET['etime']."',t_expsub='".$_GET['subj']."',t_advancesub='".$_GET['adv']."' where id=".$id;
	
	
$result=mysql_query("update t_info set t_ses='".$_GET['session']."',t_noofstud='".$_GET['stud']."', t_s_time='".$_GET['stime']."',t_e_time='".$_GET['etime']."',t_expsub='".$_GET['subj']."',t_advancesub='".$_GET['adv']."' where t_id=".$id."");
$no=mysql_affected_rows();

if($no>0)
{
	echo "<td colspan='3' style='color:green'>Qualification Successfully Updated</td>";
}
else
{
echo "<td colspan='3' style='color:red'>Error..</td>";
}
}
if(isset($_GET['f_name']))
{
	//echo $_GET['neigh'];
	//echo "update t_info set t_p_add='".$_GET['padd']."'";
	//echo "update t_info set t_ses='".$_GET['session']."',t_noofstud='".$_GET['stud']."', t_s_time='".$_GET['stime']."',t_e_time='".$_GET['etime']."',t_expsub='".$_GET['subj']."',t_advancesub='".$_GET['adv']."' where id=".$id;
	
	
$result=mysql_query("update tutor set u_name='".$_GET['sch_name']."',contact='".$_GET['m_no']."', phone='".$_GET['p_no']."',sub='".$_GET['subj']."',birth_date='".$_GET['date1']."',sex='".$_GET['sex']."' where id=".$id."");
$no=mysql_affected_rows();

if($no>0)
{
	echo "<td colspan='3' style='color:green'>Account Details Successfully Updated</td>";
}
else
{
echo "<td colspan='3' style='color:red'>Error..</td>";
}
}
?>