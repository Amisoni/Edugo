
function toverlay()
{
var overlay=document.getElementById('overlay');
overlay.style.opacity=.5;
if(overlay.style.display=="block")
{
	overlay.style.display="none";
}
else
{
	overlay.style.display="block";
}
}


