<?php
if(isset($_GET['l']))
{
}
else
{
if(isset($_COOKIE['ID_username']))
{
	//echo "hi...";
	//header('Location:first.php');
	header('Location:../cookie.php');
}
}
?><head>
<script>
function forget()
{
document.getElementById("loginform").style.display="none";
document.getElementById("arjun").style.display="block";
}
function display()
{
document.getElementById("loginform").style.display="block";
document.getElementById("arjun").style.display="none";
}

</script>
</head>

<TR bgcolor="#F0F0F0" style="height:120px; width:200">
<td style="vertical-align: middle; font-size: 50px; font-family: Miriam; color: #FFFFFF; font-weight: bold;" height="120px";><div style="margin-left:100px"><img src="image/logo.png" height="80" /></div></td>
<td style="font-size: large;; color: #06c;" width="50%">

<table id="loginform">
<form action="../login.php" method="post">
<tr><td>
<table style="width:200px;">
<tr>
  <td style="font-stretch:semi-condensed">User Name/Email:</td></tr>
 <tr>
 <td><input name="u_name" type="text" tabindex="1"  /></td>
 </tr>
 <tr>
 <td><input name="keep" type="checkbox" style="font-size:medium"/>Keep me Log In</td></tr></table>
    </td>
    	
<td style="font-size: medium; color:#06c;" width="40%" align="left">

<table><tr><td>Password:</td></tr>
<tr><td>
      <input name="password" type="password" tabindex="2"/></td></tr>
      <tr><td style="font-size:medium; color:#06c"><label style="text-decoration:underline; cursor:pointer;" onclick="forget()">Forgot Password?</label></td></tr></table>
      </td>
    <td width="50%" align="left">
    <table><tr><td><br /></td></tr><tr><td>
    <input type="submit" value="Log In" align="middle" style="color: #FFF; background-color:#06F" /></td></tr><tr><td><br /></td></tr></table>
    </td></tr>
    </form>
    </table>
 
 <table id="arjun" style="display:none;">
 <form action="../forget.php" method="post">
 <tr><td><br /></td>
<td></td><td></td>
</tr>
<tr>
  <td>User Name/Email:</td>

 <td><input name="u_name" type="text" tabindex="1" required="Required"/></td>
 <td><input type="submit" style="background-color: #00F; color:#FFF;" value="Submit" /></td>
 </tr>
  </form>
 <tr>
 <td></td>
 <td><label onclick="display()"  style="text-decoration:underline;">Go To Log In</label></td>
 </table>

    </td>
</TR>
<tr  bgcolor="#F0F0F0">
<td colspan="4" align="center">
<?php if (isset($_GET['msg']))
					{
						$msg=$_GET['msg'];
						if($msg==1)
						{
				 			echo  "<font color='#FF0000' size='3'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Worng Username And Password </font>";
						}
						if($msg==2)
						{
				 			echo  "<font color='#FF0000' size='3'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Send Password Email Address </font>";
						}
						if($msg==3)
						{
				 			echo  "<font color='#FF0000' size='3'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wrong Email Address </font>";
						}
						
					}
			?>


</td>
</tr>
