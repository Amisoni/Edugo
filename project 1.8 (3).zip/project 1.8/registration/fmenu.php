<TD align="center" valign="top" width="60%">

<table background="image/new1.gif" width="572px" height="400px" style="vertical-align:top">
<tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr>
<tr>
<td height="100px" colspan="3" align="center">
<a href="first.php"><img src="image/studsmall.png" class="rightImage"  onmouseover="this.className='mouseOver'" onmouseout="this.className='mouseOut'" /></a>
</td>
</tr>
<tr></tr>
<tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr>
<tr></tr><tr></tr><tr>
<tr></tr>
<tr>
<td align="right" width="100px" height="120px" valign="center">
<a href="parence.php" style="border:0px;">
<img src="image/parent1.png" class="rightImage" alt="Student Registration"  onmouseover="this.className='mouseOver'" onmouseout="this.className='mouseOut'"/></a>
</td>

<td  align="center" width="180px" height="120px" valign="center"><a href="feculty.php"><img src="image/bigteacher1.png" alt="Feculty Registration" style="width:100px;height:100px; border:0px;"/></a>
</td>

<td align="left" width="100px" height="120px" valign="center">
<a href="tutor_teachar.php"><img src="image/tutor2.png" 
 alt="Parents Registration" class="rightImage"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a>
</td>
</tr>
<tr></tr>
<tr></tr>
<tr></tr>
<tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr>
<tr>
<td colspan="3" align="center" width="100px" height="120px" valign="top"><a href="school.php"><img src="image/school2.png" alt="School Registration" class="rightImage"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a></td>
</tr>

</table>
</td>
