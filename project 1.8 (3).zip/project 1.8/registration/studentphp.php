<?php
include("../config.php");
//$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

//mysql_select_db("wabsupport", $con);

$no=0;

@$result=mysql_query("Select * from feculty where email='$_POST[email]'");
@$no=$no+mysql_num_rows($result);
@$result=mysql_query("Select * from student where email='$_POST[email]'");
@$no=$no+mysql_num_rows($result);
@$result=mysql_query("Select * from tutor where email='$_POST[email]'");
@$no=$no+mysql_num_rows($result);
@$result=mysql_query("Select * from father where email='$_POST[email]'");
@$no=$no+mysql_num_rows($result);
@$result=mysql_query("Select * from school where email='$_POST[email]'");
@$no=$no+mysql_num_rows($result);
if($_POST['standard']=="Graduate")
{
	$std=$_POST['Graduate'];	
}
else
{
	$std=$_POST['standard'];	
}
if($no==0)
{
mysql_query("INSERT INTO student (f_name,l_name,s_name,email,Contact,phone,std,midium,sex,birth_date,password,affiliance)
values('$_POST[first_name]','$_POST[last_name]','$_POST[school_name]','$_POST[email]','$_POST[number]','$_POST[pnumber]','$std','$_POST[md]','$_POST[sex]','".$_POST['year'].$_POST['month'].$_POST['day']."','$_POST[pwd]','$_POST[affi]')");

@$result=mysql_query("Select * from student where email='$_POST[email]'");
@$data=mysql_fetch_array($result);

session_start();
$_SESSION['id']=$data[0];
echo($_SESSION['id']);
mysql_query("insert into s_info (s_id) value(".$data[0].")");
mysql_close($con);
//echo "hhi..";
header('Location:../student/agree.php');	
}
else
{
	header('Location:first.php?p=1');
}
?>