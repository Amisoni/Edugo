<?php
if(isset($_GET['id']))
{
	include("../config.php");
	$result=mysql_query("select * from school where id=".$_GET['id']);
	@$data=mysql_fetch_array($result);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/StyleSheet.css" />
<script type="text/javascript">
function validation(id)
{
document.getElementById("valid").style.display="none";	
document.getElementById("radio_affi").style.display="none";	
document.getElementById("radio_type").style.display="none";
document.getElementById("valid").style.display="none";	
document.getElementById("f_n").style.display="none";		
document.getElementById("e_i").style.display="none";		
document.getElementById("c_n").style.display="none";
document.getElementById("st_n").style.display="none";
document.getElementById("p_n").style.display="none";
document.getElementById("m_n").style.display="none";
document.getElementById("pr_n").style.display="none";	
document.getElementById("pw_n").style.display="none";	
document.getElementById("es_n").style.display="none";	
document.getElementById("s1_n").style.display="none";
document.getElementById("chkid12").style.display="none";		
document.getElementById("drop_day").style.display="none";
document.getElementById("drop_month").style.display="none";
document.getElementById("drop_year").style.display="none";	
document.getElementById(id).style.display="block";	
}
function validateForm()
{
document.getElementById("drop_day").style.display="none";
document.getElementById("drop_month").style.display="none";
document.getElementById("drop_year").style.display="none";	
document.getElementById("valid").style.display="none";	
document.getElementById("f_n").style.display="none";		
document.getElementById("e_i").style.display="none";		
document.getElementById("c_n").style.display="none";
document.getElementById("st_n").style.display="none";
document.getElementById("p_n").style.display="none";
document.getElementById("m_n").style.display="none";
document.getElementById("pr_n").style.display="none";	
document.getElementById("pw_n").style.display="none";	
document.getElementById("es_n").style.display="none";	
document.getElementById("s1_n").style.display="none";
document.getElementById("chkid12").style.display="none";		

document.getElementById("school").style.display="none";
document.getElementById("e_id").style.display="none";
document.getElementById("cnt").style.display="none";
document.getElementById("p_name").style.display="none";
document.getElementById("std").style.display="none";
document.getElementById("medium").style.display="none";
document.getElementById("afflia").style.display="none";
document.getElementById("pwd1").style.display="none";
document.getElementById("b1_date").style.display="none";
document.getElementById("lan").style.display="none";
var x=document.forms["myform"]["s_name"].value;
var y=document.forms["myform"]["email"].value;
var z=document.forms["myform"]["contact"].value;
var l=document.forms["myform"]["pnumber"].value;
var p=document.forms["myform"]["HOD"].value;
var q=document.forms["myform"]["student"].value;
var r=document.forms["myform"]["affi"].value;
var t=document.forms["myform"]["pwd"].value;
var d=document.forms["myform"]["day"].value;
var m=document.forms["myform"]["month"].value;
var yy=document.forms["myform"]["year"].value;
var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
var numbers = /^[0-9]+$/; 
var reg = /^(.{0,20})$/; 
var reg1 = /^(.{0,20})$/; 
var reg2 = /^([0-9]{0,7})$/; 
var s="";
var a=1;
if(l==null || l=="")
{
	document.getElementById("lan").style.display="block";
}
if(x==null || x=="")
{
	document.getElementById("school").style.display="block";
	s=s+a+"Enter School Name\n";
	a++;
}
if(!reg.test(x))
	{
		document.getElementById("school").style.display="block";
		s=s+a+"MAximum 20 character...\n";
		a++;
	}

if(y==null || y=="")
{
	document.getElementById("e_id").style.display="block";
	s=s+a+"Enter Email\n";
	a++;
}
else
{
	if (!filter.test(y)) {
		document.getElementById("e_id").style.display="block";
    s=s+a+"Please provide a valid email address\n";
	a++;
	}	
}
if(z==null || z=="")
{
	document.getElementById("cnt").style.display="block";
	s=s+a+"Enter Contact No.\n";
	a++;
}
else
	{	
	
      if((!numbers.test(z))|| z.length!=10)
      { 
	  document.getElementById("cnt").style.display="block";  
      s=s+a+"Enter Valid Number \n";
	  a++;
      }  
	}

if(p==null || p=="")
{
	document.getElementById("p_name").style.display="block";
	s=s+a+"Enter HOD \n";
	a++;
}
if(!reg1.test(p))
	{
		document.getElementById("p_name").style.display="block";
		s=s+a+"MAximum 20 character...\n";
		a++;
	}

if(q==null || q=="")
{
	document.getElementById("std").style.display="block";
	s=s+a+"Enter Student\n";
	a++;
}
if(!reg2.test(q))
	{
		document.getElementById("std").style.display="block";
		s=s+a+"MAximum 20 character...\n";
		a++;
	}
if(r=="Select Affiliation")
{
	document.getElementById("afflia").style.display="block";
	s=s+a+"Enter Affilation\n";
	a++;
}

if(t==null || t=="")
{
	document.getElementById("pwd1").style.display="block";
	s=s+a+"Enter Password\n";
	a++;
}

 	if(t.length<8)
      {   
	   document.getElementById("pwd1").style.display="block";
      s=s+a+"Enter At Least 8 character Password \n";
	  a++;
	  }
	 // alert("hi..");
if(d=="--Day--" || m=="--Month--" || yy=="--\Year--" )
	{
		document.getElementById("b1_date").style.display="block";
		s=s+a+"Select Proper Date\n";
		a++;
	}
	
	
	
	var b_no=0;
	for(var i=0;i<3;i++)
	{
		//alert("hi..");
		if(document.getElementById("b["+i+"]").checked==true)
		{
			//alert("hi..me");
			b_no++;
			
		}
	
		
		
	}
		  
	//alert(no);
	if(b_no<=0)
	{
		document.getElementById("medium").style.display="block";
	}
	// alert("hi...");
if (s!="")
	  {
	  //alert("Please.......\n "+s);

	 document.getElementById("valid").style.display="block";
	 return false;
	  }
	    else
  {
	  document.getElementById("myfrom").submit();
  }
}
</script>
</head>

<body style="alignment-adjust: central; text-align: left; font-size: 36px; font-family: 'Times New Roman', Times, serif; font-style: normal; vertical-align: top; color: #D6D6D6; border: 0; outline: 0; outline-color: #0033FF;margin:0px;">
<table border="0" width="100%" height="100%" align="center" cellpadding="0" cellspacing="0" style="margin-top:-10px">
<?php include('header.php')?>
<TR style="width:100%;position:relative ">
<?php include('hmenu.php') ?>
<TD colspan="3" valign="top" width="40%">
<div style="width:95%;">
<form id="myfrom" action="school_php.php" method="post" name="myform" onsubmit="return validateForm()" style="margin-top:-30px;background-color:#F0F0F0;padding-left:5px;" >
<H4 style="color:#C60;font-family:Corbel; height:10px;padding-top:5px;"><img src="image/arrow1.png" style="margin-left:-14px;" />&nbsp;School Sign Up</H4>
<table border="0" cellpadding="4" cellspacing="2" width="100%" onmouseout="validation('')">
<tr>
	<td width="100px" class="label">School Name:</td>
	<td><label id="school" style="color:#F00; display:none" class="label">*</label></td>
	<td>
    <input type="text" maxlength="20" name="s_name" placeholder="Enter Name Of School" class="placeholder" onfocus="validation('f_n')" value="<?php echo @$data['s_name']; ?>"/>
	</td>
</tr>

<tr>
	<td width="100px" class="label">Email:</td>
	<td><label id="e_id" style="color:#F00; display:none" class="label">*</label></td>
	<td><input name="email" type="text" placeholder="Enter Email Address" class="placeholder"  onfocus="validation('e_i')" value="<?php echo @$data['email']; ?>"/>
	</td>
</tr>

<tr>
	<td width="100px" class="label">Mobile:</td>
	<td><label id="cnt" style="color:#F00; display:none" class="label">*</label></td>
	<td><input type="text" maxlength="10" name="contact" placeholder="Contact Number" class="placeholder" onfocus="validation('p_n')" value="<?php echo @$data['contact']; ?>"/>
	</td>
</tr>

<tr>
<td width="100px" class="label">Phone No:</td>
<td width="10px"><label id="lan" style="color:#F00; display:none" class="label">*</label></td>
<td><input type="text" name="pnumber" class="tb1" onfocus="validation('c_n')" style="width:10%; margin-right:5%" maxlength="2" placeholder="+91" /><input type="text" name="pnumber1" class="conutry" onfocus="validation('st_n')" style="width:20%;margin-right:5%" maxlength="3" placeholder="Code" /><input type="text" name="pnumber2" class="phone" onfocus="validation('m_n')" style="width:41%;"  maxlength="8" placeholder="Enter Number"/>
</td>
</tr>

<tr>
	<td width="100px" class="label">Principal Name:</td>
	<td><label id="p_name" style="color:#F00; display:none" class="label">*</label></td>
	<td><input type="text" name="HOD" maxlength="20" placeholder="Owner/Principal Name" class="placeholder" onfocus="validation('pr_n')" value="<?php echo @$data['HOD']; ?>"/>
	</td>
</tr>

<tr>
<td width="100px" class="label">Password:</td>
<td><label id="pwd1" style="color:#F00; display:none" class="label">*</label></td>
<td><input type="password" name="pwd" placeholder="Enter Password" class="placeholder" onfocus="validation('pw_n')" value="<?php echo @$data['password']; ?>"/>
</td>
</tr>

<tr>
	<td width="116px" class="label">Established Date:</td>
	<td><label id="b1_date" style="color:#F00; display:none" class="label">*</label></td>
	<td style="color:#000; font-size:15px">
	<select name="day" class="day1" onfocus="validation('drop_day');">
	<option value="--Day--">--Day--</option>
<?php
$i=1;

$d=explode('-',@$data['s_date']);

while($i<32)
{
	if($i<10){
	if($d[2]=$i)
	{
	echo "<option value=0$i selected='selected'>0".$i."</option>";
	}
	else
	{
	echo "<option value=0$i>0".$i."</option>";
	}
}
else
{
	if($d[2]=$i)
	{
	echo "<option value=$i>$i</option>";
	}
	else
	{
	echo "<option value=$i selected='selected'>$i</option>";
	}
}
$i++;
}
?>
</select>
<select name="month" class="month1" onfocus="validation('drop_month')">
<option value="--Month--">--Month--</option>
<option value=01 selected="selected">Jan</option>
<option value=02>Feb</option>
<option value=03>Mar</option>
<option value=04>Apr</option>
<option value=05>May</option>
<option value=06>Jun</option>
<option value=07>Jul</option>
<option value=08>Aug</option>
<option value=09>Sep</option>
<option value=10>Oct</option>
<option value=11>Nov</option>
<option value=12>Dec</option>
</select>

<select name="year" class="year1" onfocus="validation('drop_year');">
<option value="--Year--">--Year--</option>
<?php
$i=date('Y');
while($i>1900)
{
	if($d[0]==$i)
	{
	echo "<option value=$i selected='selected'>$i</option>";
	}
	else
	{
		echo "<option value=$i>$i</option>";
	}
$i--;
}
?>
</select>
</td>
</tr>

<tr onmouseover="validation('radio_type')" onkeyup="validation('radio_type')">
	<td  width="100px" class="label">School Type:</td>
	<td style="color:#000; font-size:10px"></td>	
	<td style="color:#000; font-size:15px">
    <?php
	if(@$data['s_type']=="boy")
	{
	echo '<input name="sex" type="radio" value="boy" checked="checked" checked="checked"/>Boys';
	echo '<input type="radio" name="sex" value="girl"/>Girls';
	echo '<input type="radio" name="sex" value="coeducation" />Coeducation';
	}
	else if(@$data['s_type']=="girl")
	{
	echo '<input name="sex" type="radio" value="boy"/>Boys';
	echo '<input type="radio" name="sex" value="girl" checked="checked"/>Girls';
	echo '<input type="radio" name="sex" value="coeducation" />Coeducation';
	}
	else
	{
	echo '<input name="sex" type="radio" value="boy"/>Boys';
	echo '<input type="radio" name="sex" value="girl"/>Girls';
	echo '<input type="radio" name="sex" value="coeducation" checked="checked" />Coeducation';
	}
	?>
	</td>
</tr>

<tr>
	<td  width="100px" class="label" >Strength:</td>
	<td width="10px"><label id="std" style="color:#F00; display:none" class="label">*</label></td>
	<td>
	<input type="text" name="student" maxlength="7" placeholder="Enter No Of Student" class="placeholder" onfocus="validation('s1_n')" value="<?php echo @$data['n_student']; ?>"/>	
	</td>
</tr>
<tr>
	<td width="100px" class="label">Medium:</td>
	<td width="10px" class="label"><label id="medium" style="color:#F00; display:none" class="label">*</label></td>
    <td class="label" onmouseover="validation('chkid12')" onkeyup="validation('chkid12')">
    <?php
	$d=explode(',',@$data['midium']);
	if(@$d[0]=="Hindi" || @$d[1]=="Hindi" || @$d[2]=="Hindi")
	{
    	echo '<input type="checkbox" name="hindi" value="Hindi," id="b[0]" checked="checked"/>Hindi';	
    }
	else
	{
		echo '<input type="checkbox" name="hindi" value="Hindi," id="b[0]"/>Hindi';	
	}
	if(@$d[0]=="English" || @$d[1]=="English" || @$d[2]=="English")
	{
		echo '<input type="checkbox" name="english" value="English," id="b[1]" checked="checked"/>English';
	}
	else
	{
		echo '<input type="checkbox" name="english" value="English," id="b[1]"/>English';
	}
	if(@$d[0]=="Gujarati" || @$d[1]=="Gujarati" || @$d[2]=="Gujarati")
	{
		echo '<input type="checkbox" name="gujarati" value="Gujarati" id="b[2]" checked="checked"/>Gujarati';
	}
	else
	{
		echo '<input type="checkbox" name="gujarati" value="Gujarati" id="b[2]"/>Gujarati';
	}
		?>
    </td>
	
</tr>

<tr>
	<td  width="100px" class="label">Affiliation:</td>
	<td width="10px"><label id="afflia" style="color:#F00; display:none" class="label">*</label>
	</td>
	<td style="color:#000; font-size:15px;" onkeyup="validation('radio_affi')" onmouseover="validation('radio_affi')">
     <?PHP 
	if(@$data['affi']=="State Board")
	{
	echo "<input type='radio' name='affi' value='State Board' checked='checked' size='18px'/>State Board";
	echo "<input type='radio' name='affi' value='CBSC' class='label' />CBSE";
	echo "<input type='radio' name='affi' value='ICSE' class='label'/>ICSE";
	echo "<input name='affi' type='radio' value='IB' />IB";
	}
	else if(@$data['affi']=="CBSE")
	{
		echo "<input type='radio' name='affi' value='State Board' size='18px'/>State Board";
		echo "<input type='radio' name='affi' value='CBSC' class='label' checked='checked' />CBSE";
		echo "<input type='radio' name='affi' value='ICSE' class='label'/>ICSE";
		echo "<input name='affi' type='radio' value='IB' />IB";
	}
	else if(@$data['affi']=="ICSE")
	{
		echo "<input type='radio' name='affi' value='State Board' size='18px'/>State Board";
		echo "<input type='radio' name='affi' value='CBSC' class='label' />CBSE";
		echo "<input type='radio' name='affi' value='ICSE' class='label' checked='checked'/>ICSE";
		echo "<input name='affi' type='radio' value='IB' />IB";
	}
	else if(@$data['affi']=="IB")
	{
		echo "<input type='radio' name='affi' value='State Board' size='18px'/>State Board";
		echo "<input type='radio' name='affi' value='CBSC' class='label' />CBSE";
		echo "<input type='radio' name='affi' value='ICSE' class='label'/>ICSE";
		echo "<input name='affi' type='radio' value='IB' checked='checked'/>IB";
	}
	else
	{
		echo "<input type='radio' name='affi' value='State Board' size='18px'/>State Board";
		echo "<input type='radio' name='affi' value='CBSC' class='label' />CBSE";
		echo "<input type='radio' name='affi' value='ICSE' class='label'/>ICSE";
		echo "<input name='affi' type='radio' value='IB' />IB";
	}
?>
	</td>
</tr>

<tr>
	<td colspan="3" >
	<table><tr><td width="100px">
 	<label id="submit" onclick="validateForm()"><img src="image/menu.png" /></label></td>
    <td>
	<label id="valid" style="color:red; display:none" class="label"> Enter Above Details
    </label>
    <label id="f_n" style="color:green; display:none" class="label"> Enter School Name
    </label>
	<label id="e_i" style="color:green; display:none" class="label"> Enter Email ID
    </label>
    <label id="p_n" style="color:green; display:none" class="label"> Mobile No Should contain 10 character
    </label>
	<label id="m_n" style="color:green; display:none" class="label"> Enter Phone No
    </label>
    <label id="c_n" style="color:green; display:none" class="label"> Country Code Should contain 2 Digit
    </label>
    <label id="st_n" style="color:green; display:none" class="label"> STD Code Should contain 3 Digit
    </label>
    <label id="pr_n" style="color:green; display:none" class="label"> Enter Principal Name
    </label>
    <label id="pw_n" style="color:green; display:none" class="label"> Password Should contain 8 characters
    </label>
     <label id="es_n" style="color:green; display:none" class="label"> Enter Established Date
    </label>
     <label id="s1_n" style="color:green; display:none" class="label"> Strength Would be more than 100 
    </label>
    <label id="chkid12" style="color:green; display:none" class="label">Select at List One Checkbox</label>
    <label id="drop_day" style="color:green; display:none" class="label">Select Day</label>
	<label id="drop_month" style="color:green; display:none" class="label">Select Month</label>
	<label id="drop_year" style="color:green; display:none" class="label">Select Year</label>
    <label id="radio_type" style="color:green; display:none" class="label">Select School Type</label>
    <label id="radio_affi" style="color:green; display:none" class="label">Select Affiliation</label>

	</td>
    <td class="label" style="color:#F00;">
<?php 
if(isset($_GET['p']))
{
	echo "Email ID is Allready Exist";
}
?></td>
</tr></table>
</td>
</table>
</form>
</TD>	
</TR>
</table>
</body>
</html>
<?php
if(isset($_GET['id']))
{
	include("../config.php");
	@$result=mysql_query("delete from school where id=".$_GET['id']);
	//$data=mysql_fetch_array($result);
}
?>