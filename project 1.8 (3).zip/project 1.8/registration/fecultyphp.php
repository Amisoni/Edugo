<?php
include("../config.php");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

$no=0;
$d1=$_POST['cb'];
$class="";
$i=0;
for($i=0;$i<count($d1);$i++)
{
	if($class=="")
	{
		$class=$class.$d1[$i];
	}
	else
	{
		$class=$class.",".$d1[$i];
	}
}

@$result=mysql_query("Select * from feculty where email='$_POST[email]'");
@$no=$no+mysql_num_rows($result);
@$result=mysql_query("Select * from student where email='$_POST[email]'");
@$no=$no+mysql_num_rows($result);
@$result=mysql_query("Select * from tutor where email='$_POST[email]'");
@$no=$no+mysql_num_rows($result);
@$result=mysql_query("Select * from father where email='$_POST[email]'");
@$no=$no+mysql_num_rows($result);
@$result=mysql_query("Select * from school where email='$_POST[email]'");
@$no=$no+mysql_num_rows($result);
if($no==0)
{
	echo "INSERT INTO feculty (f_name,l_name,u_name,email,contact,phone,std,sex,birth_date,sub,password,midium,board)
VALUES ('$_POST[f_name]','$_POST[l_name]','$_POST[institute]','$_POST[email]','$_POST[number]','$_POST[pnumber]','$class','$_POST[sex]','".$_POST['year'].$_POST['month'].$_POST['day']."','$_POST[sub]','$_POST[pwd]','".$_POST['hindi'].",".$_POST['english'].",".$_POST['gujarati']."','".$_POST['state'].",".$_POST['CBSE'].",".$_POST['ICSE'].",".$_POST['IB']."')";
mysql_query("INSERT INTO feculty (f_name,l_name,u_name,email,contact,phone,std,sex,birth_date,sub,password,midium,board)
VALUES ('$_POST[f_name]','$_POST[l_name]','$_POST[institute]','$_POST[email]','$_POST[number]','$_POST[pnumber]','$class','$_POST[sex]','".$_POST['year'].$_POST['month'].$_POST['day']."','$_POST[sub]','$_POST[pwd]','".$_POST['hindi'].$_POST['english'].$_POST['gujarati']."','".$_POST['state'].$_POST['CBSE'].$_POST['ICSE'].$_POST['IB']."')");

@$result=mysql_query("Select * from feculty where email='$_POST[email]'");
@$data=mysql_fetch_array($result);

session_start();
$_SESSION['id']=$data[0];
mysql_query("insert into parent (p_id) value(".$data[0].")");
mysql_close($con);
header('Location:../feculty/agree.php');
}
else
{
	header('Location:feculty.php?p=1');	
}
?>