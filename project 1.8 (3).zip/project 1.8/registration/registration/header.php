<head>
<script>
function forget()
{
document.getElementById("loginform").style.display="none";
document.getElementById("arjun").style.display="block";
}
function display()
{
document.getElementById("loginform").style.display="block";
document.getElementById("arjun").style.display="none";
}

</script>
<style>
</style>
</head>
<TR bgcolor="#F0F0F0" style="height:100px; width:200">
<td style="vertical-align: middle; font-size: 50px; font-family: Miriam; color: #FFFFFF; font-weight: bold;" height="120px";><div style="margin-left:100px"><img src="image/edugo.png" /></div></td>
<td style="font-size:small; font-family: Ebrima; color:#06C;" width="50%">

<table id="loginform" border="0">
<form action="../login.php" method="post">
<tr><td>
<table border="0">
<tr>
  <td>&nbsp;User Name/Email</td></tr>
 <tr>
 <td><input  name="u_name" type="text" tabindex="1"  /></td>
 </tr>
 <tr>
 <td><input type="checkbox" />&nbsp;Keep me Logged In</td></tr></table>
    </td>
    	
<td style="font-size: medium; color: #FFFFFF; font-family: Ebrima;" width="40%" align="left">

<table><tr><td style="font-size:small; color:#06C">&nbsp;Password</td></tr>
<tr><td>
      <input name="password" type="password" tabindex="2"/></td></tr>
      <tr><td style="font-size:small; color:#06c">&nbsp;<label style="text-decoration:underline; cursor:pointer;" onclick="forget()">Forgot Password?</label></td></tr></table>
      </td>
    <td width="50%" align="left">
    <table><tr><td><br /></td></tr><tr><td>
    <input type="submit" value="Log In" align="middle" style="background-color:#06C;color:#FFF;border-style:outset" /></td></tr><tr><td><br /></td></tr></table>
    </td></tr>
    </form>
    </table>
 
 <table id="arjun" style="display:none;">
 <form action="../forget.php" method="post">
 <tr><td><br /></td>
<td></td><td></td>
</tr>
<tr>
  <td>User Name/Email:</td>

 <td><input name="u_name" type="text" tabindex="1"  /></td>
 <td><input type="submit" style="background-color: #30C; color: #FFF;" /></td>
 </tr>
  </form>
 <tr>
 <td></td>
 <td><label onclick="display()"  style="text-decoration:underline;color:#06C">Go To Log In</label></td>
 </table>

    </td>
</TR>
<tr  bgcolor="#3745F0">
<td colspan="4" align="center">
<?php if (isset($_GET['msg']))
					{
						$msg=$_GET['msg'];
						if($msg==1)
						{
				 			echo  "<font color='#FF0000' size='3'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Worng Username And Password </font>";
						}
						if($msg==2)
						{
				 			echo  "<font color='#FF0000' size='3'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Send Password Email Address </font>";
						}
						if($msg==3)
						{
				 			echo  "<font color='#FF0000' size='3'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wrong Email Address </font>";
						}
						
					}
			?>


</td>
</tr>
