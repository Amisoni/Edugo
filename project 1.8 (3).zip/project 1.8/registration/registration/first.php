<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="css/StyleSheet.css" />
<script type="text/javascript">
function validation(id)
{
document.getElementById("valid").style.display="none";	
document.getElementById("f_n").style.display="none";
document.getElementById("l_n").style.display="none";
document.getElementById("e_i").style.display="none";		
document.getElementById("c_n").style.display="none";
document.getElementById("st_n").style.display="none";
document.getElementById("p_n").style.display="none";
document.getElementById("m_n").style.display="none";
document.getElementById("pw_n").style.display="none";	
document.getElementById("s_n").style.display="none";
document.getElementById(id).style.display="block";	
}
function validateForm()
{
document.getElementById("valid").style.display="none";	
document.getElementById("f_n").style.display="none";
document.getElementById("l_n").style.display="none";
document.getElementById("e_i").style.display="none";		
document.getElementById("c_n").style.display="none";
document.getElementById("st_n").style.display="none";
document.getElementById("p_n").style.display="none";
document.getElementById("m_n").style.display="none";
document.getElementById("pw_n").style.display="none";	
document.getElementById("s_n").style.display="none";
	document.getElementById("name").style.display="none";
	document.getElementById("school").style.display="none";
	document.getElementById("emailv").style.display="none";
	document.getElementById("std").style.display="none";
	document.getElementById("cnt").style.display="none";
	document.getElementById("pwd1").style.display="none";
	document.getElementById("b_date").style.display="none";
	var x=document.forms["myform"]["first_name"].value;
	var y=document.forms["myform"]["last_name"].value;
	var z=document.forms["myform"]["school_name"].value;
	var p=document.forms["myform"]["email"].value;
	var q=document.forms["myform"]["standard"].value;
	var g=document.forms["myform"]["Graduate"].value;
	var r=document.forms["myform"]["number"].value;
	var t=document.forms["myform"]["sex"].value;
	var u=document.forms["myform"]["pwd"].value;
	var d=document.forms["myform"]["day"].value;
	var m=document.forms["myform"]["month"].value;
	var yy=document.forms["myform"]["year"].value;
	var numbers1 = /^[0-9]+$/;  
	var char = /^[A-Za-z]+$/;  
	var reg = /^([a-zA-Z0-9]{0,8})$/;
	var s="";
	var a=1;
	if(x==null || x=="" || y==null || y=="")
	{
		s=s+a+"Enter first Name\n";
		document.getElementById("name").style.display="block";
		a++;
	}
	/*if()
	{
		s=s+a+"Enter Last Name\n";
		a++;
	}*/
	if(z==null || z=="")
	{
		document.getElementById("school").style.display="block";
		s=s+a+"Enter School Name\n";
		a++;
	}
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if(p==null || p=="")
	{
		document.getElementById("emailv").style.display="block";
		s=s+a+"Enter Email\n";
		a++;
	}	
	if(!filter.test(p))
	{
		document.getElementById("emailv").style.display="block";
		s=s+a+"Enter Valid Email\n";
		a++;
	}
	if((q==null || q=="Select Standard") && (g==null || g=="Select Graduate"))
	{
		document.getElementById("std").style.display="block";
		s=s+a+"Select standard\n";
		a++;
	}
	else if(q=="Graduate" && g=="Select Graduate")
	{
		document.getElementById("std").style.display="block";
		s=s+a+"Select standard\n";
		a++;
	}
	
	if(r==null || r=="" )
	{
		document.getElementById("cnt").style.display="block";
		s=s+a+"Enter Number\n";
		a++;
	}
	if( !numbers1.test(r) || r.length!=10)
	{
		document.getElementById("cnt").style.display="block";
		s=s+a+"Enter Valid Number\n";
		a++;
	}
	
	if(u==null|| u=="")
	{
		document.getElementById("pwd1").style.display="block";
		s=s+a+"Enter Password\n";
		a++;
	}
	 
	 if(u.length<8)
     {   
	   		document.getElementById("pwd1").style.display="block";
      		s=s+a+"Enter At Least 6 character Password \n";
	  		a++;
	 }
	
	 if(d=="--Day--" || m=="--Month--" || yy=="--Year--" )
	{
		document.getElementById("b_date").style.display="block";
		s=s+a+"Select Proper Date\n";
		a++;
	}
 	
	if (s!="")
	  {
	 // alert("Please.......\n "+s);
	 document.getElementById("valid").style.display="block";
	 return false;
	  }
	  else
	  {
		  document.getElementById("myfrom").submit();
	  }
}

function change()
{
	var x=document.forms["myform"]["standard"].value;
	//alert(x);
	document.getElementById("gra").options[0].selected = true;
	//document.getElementById("stand").options[0].selected = true; 
	if(x=="Graduate")
	{
		document.getElementById("gra").style.display="block";
		//document.getElementById("stand").style.display="block";	
	}
	else
	{
		//document.getElementById("stand").style.display="none";
		document.getElementById("gra").style.display="none";
	}
		
}

</script>
 <script src="../dropdown/jquery.min.js" type="text/javascript"></script>
    <link href="../dropdown/modalPopLite1.3.0.css" rel="stylesheet" type="text/css" />
    <script src="../dropdown/modalPopLite1.3.0.min.js" type="text/javascript"></script>
	<script type="text/javascript">
	    $(function () {
           
	        $('#popup-wrapper').modalPopLite({ openButton: '#clicker', closeButton: '#close-btn', isModal: false });
function f1()
{
	}
	    });
		
	</script>
</head>
<body style="alignment-adjust: central; text-align: left; font-size: 36px; font-family: 'Times New Roman', Times, serif; font-style: normal; vertical-align: top; color: #D6D6D6; border: 0; outline: 0; outline-color: #0033FF;margin:0px;">
<table border="0" width="100%" height="100%" align="center" cellpadding="0" cellspacing="0" style="margin-top:-10px;">

<?php include('header.php')?>

<TR style="width:100%; position:relative" >

<?php include('smenu.php')?>

<TD colspan="3" valign="top" width="40%">
<div style="width:95%;">
<form id="myfrom" action="studentphp.php" method="post" name="myform" onsubmit="return validateForm()" style="margin-top:-30px;background-color:#F0F0F0;padding-left:5px;">
<H4 style="color:#C60;font-family:Corbel; height:10px;padding-top:5px;"><img src="image/arrow1.png" style="margin-left:-14px;" />&nbsp;Student Sign Up</H4>
<table cellpadding="4" cellspacing="2" border="0" style="width:100%;">
<tr>
	<td width="100px" class="label">First Name:</td>
	<td width="10px" class="label"><label id="name" style="color:#F00; display:none" class="label">*</label></td>
	<td class="label" width="288"><input type="text" name="first_name" placeholder="First Name" style="width:85px; height:20px; font-size:15px" onclick="validation('f_n')"  class="tb1" /> Last Name <input type="text" name="last_name" placeholder="Last Name" style="width:85px; height:20px; font-size:15px" onclick="validation('l_n')" class="tb1" />
	</td>
</tr>

<tr>
	<td width="116px" class="label">School Name:</td>
	<td width="10px"><label id="school" style="color:#F00; display:none" class="label">*</label></td>
	<td><input type="text" name="school_name" placeholder="Enter School Name" class="placeholder" onclick="validation('s_n')"/></td>
</tr>

<tr>
	<td width="100px" class="label">Email:</td>
	<td width="10px"><label id="emailv" style="color:#F00; display:none" class="label">*</label>
    </td>
	<td><input type="text" name="email" placeholder="Enter Email Address" class="placeholder" onclick="validation('e_i')"/>
    </td>
</tr>

<tr>
	<td width="100px" class="label">Standard:</td>
	<td width="10px"><label id="std" style="color:#F00; display:none" class="label">*</label></td>
	<td>
	<table cellpadding="0" cellspacing="0" style="text-transform:capitalize;"><tr><td>
	<select id="stand" class="stand1" name="standard" onchange="change()" style="width:120px; height:30px;">
		<option value="Select Standard">--Standard--</option>
		<?php
		include("../config.php");
	$result=mysql_query("select * from class");
	while($data=mysql_fetch_array($result))
	{
		echo "<option value='".$data[0]."'>".ucfirst($data[1])."</option>";
	}
		?>
		<option value="Graduate">Other >></option>
	</select></td><td>
	<select id="gra" class="label" name="Graduate" style="display:none;">
		<option value="Select Graduate">--Graduate--</option>	
		<option value="Diploma">Diploma</option>
		<option value="BCA">BA</option>
		<option value="BCom">BCom</option>		
		<option value="BBA">BSC</option>
		<option value="BSC IT">BBA</option>
	</select>
	</td></tr></table>
	</td>
</tr>
<tr>
	<td  width="100px" class="label">Medium:</td>
	<td width="10px"><label id="afflia" style="color:#F00; display:none" class="label">*</label>
	</td>
	<td style="color:#000; font-size:15px;">
	<input type="radio" name="md" value="Gujarati" checked="checked" size="18px"/>English
	<input type="radio" name="md" value="Hindi" class="label" />Hindi
	<input type="radio" name="md" value="Gujarati" class="label"/>Gujarati
	<input type="radio" name="md" value="Other" />Other
	</td>
</tr>
<tr>
<td width="100px" class="label">Mobile:</td>
<td width="10px"><label id="cnt" style="color:#F00; display:none" class="label">*</label></td>
<td><input type="text" name="number" placeholder="Enter Mobile Number" class="placeholder" onclick="validation('m_n')"/>
</td>
</tr>

<tr>
<td width="100px" class="label">Phone No:</td>
<td width="10px"><label id="lan" style="color:#F00; display:none" class="label">*</label></td>
<td><input type="text" name="pnumber" class="tb1" onclick="validation('c_n')" style="width:10%; margin-right:5%" maxlength="2" placeholder="+91"  /><input type="text" name="pnumber1" class="conutry" onclick="validation('st_n')" style="width:20%; margin-right:5%" maxlength="3"  placeholder="Code" /><input type="text" name="pnumber2" class="phone" onclick="validation('p_n')" style="width:41%;"  maxlength="8" placeholder="Enter Number"/>
</td>
</tr>

<tr>
<td width="100px" class="label">Password:</td>
<td width="10px"><label id="pwd1" style="color:#F00; display:none" class="label">*</label></td>
<td><input type="password" name="pwd" placeholder="Enter Password" class="placeholder" onclick="validation('pw_n')"/>
</td>
</tr>

<tr>
<td width="100px" class="label">Birth Date:</td>
<td width="10px"><label id="b_date" style="color:#F00; display:none" class="label">*</label></td>
<td class="birthday_td">
<select name="day" id="day" class="day1">
<option value="--Day--">--Day--</option>
<?php
$i=1;
while($i<32)
{if($i<10){
echo "<option value=0$i>0".$i."</option>";}else
{echo "<option value=$i>$i</option>";}
$i++;
}
?>
</select>
<select name="month" id="month" class="month1">
<option value="--Month--">--Month--</option>
<option value=01>Jan</option>
<option value=02>Feb</option>
<option value=03>Mar</option>
<option value=04>Apr</option>
<option value=05>May</option>
<option value=06>Jun</option>
<option value=07>Jul</option>
<option value=08>Aug</option>
<option value=09>Sep</option>
<option value=10>Oct</option>
<option value=11>Nov</option>
<option value=12>Dec</option>
</select>
<select name="year" id="year" class="year1">
<option value="--Year--">--Year--</option>
<?php
$i=1900;
while($i<2031)
{
echo "<option value=$i>$i</option>";
$i++;
}
?>
</select>
</td>
</tr>
<tr>
	<td  width="100px" class="label">Affiliation:</td>
	<td width="10px"><label id="afflia" style="color:#F00; display:none" class="label">*</label>
	</td>
	<td style="color:#000; font-size:15px;">
	<input type="radio" name="affi" value="State Board" checked="checked" size="18px"/>State Board
	<input type="radio" name="affi" value="CBSC" class="label" />CBSE
	<input type="radio" name="affi" value="ICSE" class="label"/>ICSE
	<input name="affi" type="radio" value="IB" />IB
	</td>
</tr>
<tr>
	<td width="100px" class="label">Gender:</td>
	<td></td>
	<td style="color:#000; font-size:15px">
	<input name="sex" type="radio" value="Male" checked="checked"/>Male
	<input type="radio" name="sex" value="Female" />Female
	</td>
</tr>
<tr><td colspan="3">
<table><tr><td width="100px">

<label id="submit" onclick="validateForm()"><img src="image/menu.png" /></label></td><td>
<label id="valid" style="color:#F00; display:none" class="label">Please Fill Above Details</label>
<label id="f_n" style="color:#F00; display:none" class="label">Please Fill First Name</label>
<label id="l_n" style="color:#F00; display:none" class="label">Please Fill Last Name</label>
<label id="s_n" style="color:#F00; display:none" class="label">Please Fill School Name</label>
<label id="e_i" style="color:#F00; display:none" class="label">Please Fill Email ID</label>
<label id="m_n" style="color:#F00; display:none" class="label">Mobile No Should be contain 10 Digit</label>
<label id="p_n" style="color:#F00; display:none" class="label">Please Fill Phone No</label>
<label id="c_n" style="color:#F00; display:none" class="label">Country Code Should be contain 2 Digit</label>
<label id="st_n" style="color:#F00; display:none" class="label">STD Code Should be contain 3 Digit</label>

<label id="pw_n" style="color:#F00; display:none" class="label">At Least 8 Character's Password</label>
</td><td class="label" style="color:#F00;">
<?php 
if(isset($_GET['p']))
{
	echo "Email ID is Allready Exist";
}
?></td>
</tr></table>
</td>
</tr>
</table>
</form>
</div>
</TD>

</TR>
</table>
</body>
</html>