<?php
include("config.php");
//$id=$_GET['id'];
//echo $id;
$result=mysql_query("insert into class cname values($sname)");
?>