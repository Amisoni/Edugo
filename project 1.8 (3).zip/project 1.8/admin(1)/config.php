<?php 
$localhost="localhost";
$username="root";
$database="edugo";
$password="";
$con=mysql_connect($localhost,$username,$password);
mysql_select_db($database,$con);
?>