<?php include("header.php"); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table align="center" width="100%" bordercolor="#0099CC" cellpadding="0" cellspacing="0"  bgcolor="#F0F0F0" style="color:#999;margin-top:5px;">

<tr style="height:50px">
	<th ><a href="addclass.php" style="color:#999;text-decoration:none">Add Class </a></th>
    <th ><a href="addsubject.php" style="color:#999;text-decoration:none" >Add Subject </a></th>
    <th ><a href="subject.php" style="color:#999;text-decoration:none">View Subject </a></th>
	<th ><a href="addchap.php" style="color:#999;text-decoration:none">Add Chapter </a></th>
    <th ><a href="chapter.php" style="color:#999;text-decoration:none">View Chapter </a></th>
    <th ><a href="select_chp_sub_cla.php" style="color:#999;text-decoration:none">Add Question </a></th>
    <th ><a href="teacherque.php" style="color:#999;text-decoration:none">View Question </a></th>
    <th ><a href="viewque.php" style="color:#999;text-decoration:none">View All Question </a></th>
    

</tr>

</table>
</body>
</html>