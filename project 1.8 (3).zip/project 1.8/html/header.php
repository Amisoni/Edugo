<div class="header">
  <div class="wrapper">
    <div class="logo"><a href="index.html"><img src="images/edugo-logo.png" alt="Edu Go" /></a></div>
    <div class="login">
      <div class="login-form">
        <input type="text" value="Enter User Name/Email" class="login-input" onclick="new_home()"/>
        <input type="text" value="Enter Password" class="login-input"/>
        <input type="submit" value="Log In" class="login-btn"/>
      </div>
      <div class="login-detail"> <span>
        <input type="checkbox" />
        <a href="#">Keep me Logged In</a></span> <span><a href="#">Forgot Password?</a></span> </div>
    </div>
  </div>
</div>
