<div class="footer clear">
  <div class="wrapper">
    <div class="copyrights">EduGo © 2013, All Rights Reserved.</div>
  </div>
</div>
