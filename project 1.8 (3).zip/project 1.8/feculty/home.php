<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<table background="image/new1.gif" align="center" width="572px" height="400px" style="vertical-align:top">
<tr>
<td height="100px" align="center">
<a href=""><img src="../registration/image/tutor2.png" alt="Feculty Registration" class="rightImage"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a>
</td>
<td align="center" width="100px" height="120px">
<a href="" style="border:0px;">
<img src="../registration/image/studsmall.png" class="rightImage" alt="Student Registration"  onmouseover="this.className='mouseOver'" onmouseout="this.className='mouseOut'"/></a>
</td>
</tr>
<tr>
<td colspan="3" align="center" width="180px" height="120px"><a href=""><img src="../registration/image/bigteacher1.png" height="100" width="100" class="rightImage"  onmouseover="this.className='mouseOver'" onmouseout="this.className='mouseOut'"/></a></td>
</tr><tr>
<td align="center" width="100px" height="120px">
<a href=""><img src="../registration/image/parent1.png" alt="Parents Registration" class="rightImage"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a>
</td>

<td colspan="2" align="center" width="100px" height="120px"><a href=""><img src="../registration/image/school2.png" alt="School Registration" /></a></td>
</tr>
</table>
<h2>WelCome To EduGo..</h2>

</body>
</html>