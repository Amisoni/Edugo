<?php 
session_start();
	//session_unset();
	unset($_SESSION['id']);
	session_destroy();
	header("Location:registration/first.php");
	//unset($_GET['logout.php']);


?>