<?php
include("../config.php");

@session_start();
$id=$_SESSION['id'];
$result=mysql_query("select * from sch_profile where sch_id=".$id);
$data=mysql_fetch_array($result);

if(isset($_POST['b_picture']))
{
//@session_start();
$id=$_SESSION['id'];	
if ($_FILES['sh_image']['type'] != 'image/jpeg')
			{
				echo "file not supported";
			}
			else
			{
			move_uploaded_file($_FILES['sh_image']['tmp_name'], "images/".$_FILES['sh_image']['name']);
			$filepath = "images/".$_FILES['sh_image']['name']; 
			
			if($_SESSION['id']!="")
			{
			$id=$_SESSION['id'];
			$q="select * from school where ID=".$id;
			$res=mysql_query($q);
			$data2=mysql_fetch_array($res);
			
			}
			mysql_query("update school set image='$filepath' where id=$id" ) ;

			
			//header('Location:header6.php');
			
	}
}


$result4=mysql_query("select * from school where id=".$id);
$data1=mysql_fetch_array($result4);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sample Home Page</title>
<link rel="stylesheet" type="text/css" href="../css/popup.css" />
<script src="../css/popup1.js" type="text/javascript"></script>
<script>
function display(id)
{
	//
	document.getElementById('s_add').style.display="none";
	document.getElementById('cpwd').style.display="none";
	document.getElementById('s_det').style.display="none";
	document.getElementById('s_acc').style.display="none";

	
	document.getElementById('p_del').style.display="none";
	//document.getElementById('s_det').style.display="none";
	document.getElementById('p_del').style.display="none";
	document.getElementById('pro').style.display="none";
	document.getElementById('archi').style.display="none";
	//alert("hi..");
	document.getElementById('s_add1').style.backgroundColor="gray";
	document.getElementById('s_acc1').style.backgroundColor="gray";
	document.getElementById('s_det1').style.backgroundColor="gray";
	document.getElementById('p_del1').style.backgroundColor="gray";
	document.getElementById('pro1').style.backgroundColor="gray";
	document.getElementById('archi1').style.backgroundColor="gray";
	document.getElementById('cpwd1').style.backgroundColor="gray";
	document.getElementById(id).style.display="table";
	var sid=id+"1";
	document.getElementById(sid).style.backgroundColor="white";
}
function set_city()
{
var ddl = document.getElementById('sh_city');
	var opts = ddl.options.length;
	for (var i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['city']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
var ddl = document.getElementById('sh_state');
	var opts = ddl.options.length;
	for (var i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['state']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	var ddl = document.getElementById('sh_join');
	var opts = ddl.options.length;
	for (var i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['p_join']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
var ddl = document.getElementById('sh_exp');
	var opts = ddl.options.length;
	for (var i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['p_experience']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	ddl = document.getElementById('sh_standard2');
	var opts = ddl.options.length;
	<?php
	
	if($data['s_standard']=="" || $data['s_standard']=="-")
	{
		$dap="0-0";
	}
	else
	{
		$dap=$data['s_standard'];
	}
	$d=explode ('-',$dap);
	?>
	for (var i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[1]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
var ddl = document.getElementById('sh_standard1');
	var opts = ddl.options.length;
	for (var i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[0]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	<?php
  	$d=explode("-",$data['a_date']);
  	?>
	ddl = document.getElementById('day');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[2]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	ddl = document.getElementById('month');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
		
    if (ddl.options[i].value == '<?php echo $d[1]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	//alert("hi..");
	}
	ddl = document.getElementById('year');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[0]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	var ddl = document.getElementById('sh_qul1');
	var opts = ddl.options.length;
	for (var i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['p_quli']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	//alert("<?php echo $data['p_experience']; ?>");
}
function Change_Password()
{
	
var old=document.forms["edit"]["opwd"].value;
var pwd=document.forms["edit"]["npwd"].value;
var cpwd=document.forms["edit"]["rpwd"].value;

	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("pmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  
	 xmlhttp.open("GET","edit_php.php?old="+old+"&&new="+pwd+"&&cnew="+cpwd,true); 
	 xmlhttp.send();
}
function Change_schooldel()
{
	var numbers = /^[0-9]+$/; 
var lib = get_radio_value1();
var grd = get_radio_value();	
var s_fecu=document.forms["edit"]["sh_feculty"].value;
var s_room=document.forms["edit"]["sh_room"].value;
var std1=document.forms["edit"]["sh_standard1"].value;
var std2=document.forms["edit"]["sh_standard2"].value;
document.getElementById("r_id").style.display="none"; 
//var a=document.getElementById("sh_standard1");	
//var std1=a.options[a.selectedIndex].value;
//var a=document.getElementById("sh_standard2");	
//var std2=a.options[b.selectedIndex].value;
if((!numbers.test(s_room)))
      { 
	  document.getElementById("r_id").style.display="block"; 
	  document.getElementById("sdelmsg").innerHTML=""; 
      
      }  
	 else
	 {
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("sdelmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  		//alert("edit_php.php?s_fecu="+s_fecu+"&&s_room="+s_room+"&&std1="+std1+"&&std2="+std2);
	 xmlhttp.open("GET","edit_php.php?s_fecu="+s_fecu+"&&s_room="+s_room+"&&std1="+std1+"&&std2="+std2+"&&lib="+lib+"&&grd="+grd,true); 
	 xmlhttp.send();
}
}
function Change_address()
{

var add=document.forms["edit"]["sh_add"].value;
//var city=document.forms["edit"]["sh_city"].value;
//var state=document.forms["edit"]["sh_state"].value;
var zip=document.forms["edit"]["sh_zip"].value;
var neig=document.forms["edit"]["sh_neighbour"].value;
var a=document.getElementById("sh_city");	
var city=a.options[a.selectedIndex].value;
var a=document.getElementById("sh_state");	
var state=a.options[a.selectedIndex].value;
//alert("hiii");
	document.getElementById("z_id").style.display="none"; 
	var numbers = /^[0-9]+$/; 
	 if((!numbers.test(zip))|| zip.length!=6)
      { 
	  document.getElementById("z_id").style.display="block"; 
	  document.getElementById("addmsg").innerHTML=""; 
      
      }  
	 else
	 {
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("addmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  		//alert("edit_php.php?add="+add+"&&city="+city+"&&zip="+zip+"&&neig="+neig);
	 xmlhttp.open("GET","edit_php.php?add="+add+"&&city="+city+"&&state="+state+"&&zip="+zip+"&&neig="+neig,true); 
	 xmlhttp.send();
}
}
function Change_archi()
{
	
var a_name=document.forms["edit"]["sh_achive"].value;
	
var desc=document.forms["edit"]["sh_des"].value;

var a=document.getElementById("day");	
var day=a.options[a.selectedIndex].value;
a=document.getElementById("month");
var month=a.options[a.selectedIndex].value;
a=document.getElementById("year");
var year=a.options[a.selectedIndex].value;
var date=year+"-"+month+"-"+day;
//alert(date);
//alert(add+city+state+zip+neig);

	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("archimsg").innerHTML=xmlhttp.responseText;
    }
  	}
  		//alert("edit_php.php?add="++"&&city="+city+"&&zip="+zip+"&&neig="+neig);
	 xmlhttp.open("GET","edit_php.php?a_name="+a_name+"&&desc="+desc+"&&date="+date,true); 
	 xmlhttp.send();
}

function Change_pricipal()
{

var a=document.getElementById("sh_qul1");	
var qul=a.options[a.selectedIndex].value;	
alert(qul);
a=document.getElementById("sh_join");
var joint=a.options[a.selectedIndex].value;	

a=document.getElementById("sh_exp");
var expe=a.options[a.selectedIndex].value;	


	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("prinmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  		//alert("edit_php.php?add="+add+"&&city="+city+"&&zip="+zip+"&&neig="+neig);
	 xmlhttp.open("GET","edit_php.php?qul="+qul+"&&joint="+joint+"&&expe="+expe,true); 
	 xmlhttp.send();
}

function get_radio_value()
{
            var inputs = document.getElementsByName("sex");
			var inputs = document.getElementsByName("sh_library");
			var inputs = document.getElementsByName("sh_ground");
			var inputs = document.getElementsByName("affi");
            for (var i = 0; i < inputs.length; i++) {
              if (inputs[i].checked) {
                return inputs[i].value;
              }
      }
}
function get_radio_value1()
{
            var inputs = document.getElementsByName("sh_library");
			for (var i = 0; i < inputs.length; i++) {
              if (inputs[i].checked) {
                return inputs[i].value;
              }
      }
}

function Change_Acoount()
{

var scontact=document.forms["edit"]["contact"].value;
var spnumber=document.forms["edit"]["pnumber2"].value;
var shod=document.forms["edit"]["HOD"].value;
var snstudent=document.forms["edit"]["student"].value;
var ssex = get_radio_value();
var affi = get_radio_value();
alert(affi);

//alert(add+city+state+zip+neig);


	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("addmsg3").innerHTML=xmlhttp.responseText;
    }
  	}
	//alert(ssex);
 		//alert("edit_php.php?add="+add+"&&city="+city+"&&zip="+zip+"&&neig="+neig);
	 xmlhttp.open("GET","edit_php.php?scontact="+scontact+"&&spnumber="+spnumber+"&&shod="+shod+"&&snstudent="+snstudent+"&&ssex="+ssex+"&&affi="+affi,true); 
 
	 xmlhttp.send();
}
</script>
</head>
<body style="margin:0px" onload="set_city();">

<form method="post" name="edit" action="" style="margin-bottom:0px" enctype="multipart/form-data">

<table width="70%" align="center" border="1px"><tr>
<td>
<table width="100%" style="vertical-align:top; text-transform:capitalize; color:#CCC; cursor:pointer;" cellpadding="0" cellspacing="0">
<tr bgcolor="gray" style="text-align:center; cursor:pointer">
<td id="pro1" bgcolor="#FFFFFF" width="100px" height="30px;"><label bgcolor="#FFFFFF" onclick="display('pro')">Profile</label></td>
<td id="s_add1"  width="100px" height="30px;"><label onclick="display('s_add')">Address</label></td>
<td id="s_acc1" width="100px" height="30px;"><label onclick="display('s_acc')">Account</label></td>
<td id="s_det1" width="100px" height="30px;"><label onclick="display('s_det')" >School</label></td>
<td id="p_del1" width="100px" height="30px;"><label onclick="display('p_del')">Principal</label></td>
<td id="archi1" width="100px" height="30px;"><label onclick="display('archi')">Achievement </label></td>
<td id="cpwd1" width="100px" height="30px;"><label onclick="display('cpwd')">Password</label></td>
</tr>
</table>
</td>
</tr>
<tr bgcolor="#FFFFFF">
<td>
<table id="cpwd" width="60%" align="center" style="vertical-align:top; text-align:left; display:none;" cellpadding="5" cellspacing="5">
<tr>
<td colspan="3">
<h2><u>Change Password</u></h2>
</td>
</tr>
<tr><td>Old Password</td><td>:</td><td><input type="password" width="200px" name="opwd" /></td></tr>
<tr><td>New Password</td><td>:</td><td><input type="password" width="200px" name="npwd" /></td></tr>
<tr><td>Confirm Password</td><td>:</td><td><input type="password" width="200px" name="rpwd" /></td></tr>
<tr id="pmsg"></tr>
<tr><td colspan="3"><input type="button" name="password" id="password" value="Change Password" onclick="Change_Password()" /></td></tr>
</table>

<table id="s_add" width="60%" align="center" style="vertical-align:top; display:none;" cellpadding="5" cellspacing="5">
<tr>
	<td colspan="3"><h2><u>Address Detail</u></h2></td>
</tr>
<tr></tr>
<tr>	<td>Address</td><td>:</td>

    <td><input type="text" name="sh_add" placeholder="Enter Address" style="width:200px;" value='<?php echo $data[2] ?> ' /> </td>
</tr>
<tr>
	<td>City</td><td>:</td>
    <td><select name="sh_city" id="sh_city" style="width:200px;">
    <option value="Ahmedabad">Ahmedabad</option>
    <option value="Gadhinagar">Gadhinagar</option>    	
    <option value="Patan">Patan</option>    	
    <option value="Surat">Surat</option>    	    	
    </select></td>
</tr>
<tr>
	<td>State</td><td>:</td>
    <td><select name="sh_state" id="sh_state" style="width:200px;">
	<option value="Select State">Select State</option>    	
    <option value="Gujarat">Gujarat</option>
    <option value="Mumbai">Mumbai</option>    	
    <option value="Rajesthan">Rajesthan</option>    	
    <option value="Dehli">Dehli</option>    	    	
    </select></td>
    
</tr>
<tr>
	<td>Zip</td><td>:</td>
    <td><input type="text" name="sh_zip" maxlength="6" size="5" width="200px" placeholder=" Zip Code" value="<?php echo $data['zip']; ?>"/></td>
</tr>
<tr>
	<td>Neighbourhood</td><td>:</td>
    <td><input type="text" width="200px" name="sh_neighbour" placeholder=" Enter Neighbourhood" value="<?php echo $data['n_hood']; ?>"/></td>
</tr>
<tr id="addmsg">
</tr>
<tr>
   	<td colspan="3"><label id="z_id" style="color:#F00;display:none;">Enter Only 6 Digits in Zip Code..</label></td>
	</tr>   
<tr>
	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('s_det')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('s_det')"/>
    <input type="button" value="Save" onclick="Change_address()"/>
    </th>
</tr>

</table>

<table align="center" cellpadding="5" cellspacing="5" id="s_det" style="display:none;vertical-align:top" width="60%">
<tr>
	<td colspan="3"><h2><u>School Detail</u></h2></td>
</tr>
<tr>
	<td>No Of Feculty</td><td>:</td>
    <td><input type="text" name="sh_feculty" placeholder=" No Of Feculty" value='<?php echo $data['s_feculty']; ?>'/></td>
</tr>
<tr>
	<td>Standard</td><td>:</td>
    <td>
    <table cellpadding="0" cellspacing="0">
    <tr>
    <td>
    <select name="sh_standard1" id="sh_standard1">
    <option value="">Select Class</option>
    
    <?php 
		include("../config.php");
		$q="select * from class";
		$res=mysql_query($q);
		while($data3=mysql_fetch_array($res))
		{
				echo "<option value='$data3[0]'>".$data3['cname']."</option>";
		}
	?>
    </select>
    
        <select name="sh_standard2" id="sh_standard2">
  	  <option value="">Select Class</option>
    <?php 
		include("../config.php");
		$q="select * from class";
		$res=mysql_query($q);
		while($data3=mysql_fetch_array($res))
		{
				echo "<option value='$data3[0]'>".$data3['cname']."</option>";
		}
	?>
    		</select>
         </td>
        </tr>
    </table>
    </td>
</tr>
<tr>
	<td width="116" class="label">Library:</td>
	<td></td>
	<td style="color:#000; font-size:15px">
	 <?php
	if($data['s_library']=="Yes")
	{
		echo '<input name="sh_library" id="sh_library" type="radio" value="Yes" checked="checked"/>Yes';
	echo '<input type="radio" name="sh_library" id="sh_library" value="No" />No';
	}
	else
	{
		echo '<input name="sh_library" type="radio" id="sh_library" value="Yes" />Yes';
	echo '<input type="radio" name="sh_library" value="No" id="sh_library" checked="checked"/>No';
	}
	?>
	</td>
</tr>
<tr>
	<td width="116" class="label">Play Ground:</td>
	<td></td>
	<td style="color:#000; font-size:15px">
	 <?php
	if($data['s_ground']=="Yes")
	{
		echo '<input name="sh_ground" id="sh_ground" type="radio" value="Yes" checked="checked"/>Yes';
	echo '<input type="radio" name="sh_ground" id="sh_ground" value="No" />No';
	}
	else
	{
		echo '<input name="sh_ground" type="radio" id="sh_ground" value="Yes" />Yes';
	echo '<input type="radio" name="sh_ground" value="No" id="sh_ground" checked="checked"/>No';
	}
	?>
	</td>
</tr>
<tr>
	<td>No Of Class Room</td><td>:</td>
    <td><input type="text" name="sh_room" value="<?php echo $data['s_room']; ?>" />
    </td>
</tr>
<tr>
   	<td colspan="3"><label id="r_id" style="color:#F00;display:none;">Enter Only  Digits in No of Room..</label></td>
	</tr>   
<tr id="sdelmsg">

  </tr>
<tr>
	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('p_del')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('p_del')"/>
    <input type="button" name="b_address" value="Save" onclick="Change_schooldel()"/>
    </th>
</tr>


</table>
<table id="p_del" align="center" style="display:none; width:60%; vertical-align:top;" cellpadding="5" cellspacing="5">
	<tr>
    	<tr>
	<td colspan="3"><h2><u>Qualification</u></h2></td>
</tr>
    </tr>
    <tr>
    	<td>Qulification</td><td>:</td>
        <td><select name="sh_qul1" id="sh_qul1" style="width:200px;">
            <option value="MBA">MBA</option>
            <option value="MCA">MCA</option>
            <option value="MCom">MCom</option>
            <option value="Mscit">Mscit</option>
            </select>
        </td>
    </tr>
    <tr>
    	<td>Year Of Joining</td><td>:</td>
        <td><select name="sh_join" id="sh_join" style="width:200px;">
                <?php 
					$i=1990;
					//echo $i;
					while($i<2014)
					{
						echo "<option value='$i'>".$i."</option>";
						$i++;
					}
				?>
            </select>
        </td>
    </tr>
    <tr>
    	<td>Experience</td><td>:</td>
        <td><select name="sh_exp" id="sh_exp" style="width:200px;">
                <?php 
					$i=1;
					while($i<11)
					{
						echo "<option value='$i'>".$i." year</option>";
						$i++;
					}
				?>
            </select>
        </td>
    </tr>
    <tr id="prinmsg">
    
    </tr>
    <tr>
    	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('archi')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('archi')"/>
    <input type="button" name="b_address" value="Save" onclick="Change_pricipal()"/>
    </th>
    </tr>
    
</table>


	<table id="archi" align="center" style="display:none; width:60%; vertical-align:top;" cellpadding="5" cellspacing="5">

    	<tr>
        	<tr>
	<td colspan="3"><h2><u>School Of Achivement</u></h2></td>
</tr>
        </tr>
        <tr>
        	<td>Name Of Achivement</td><td>:</td>
            <td><input type="text" width="200px" name="sh_achive" value="<?php echo $data['a_name']; ?>" placeholder=" Name Of Achivement" style="width:200px;"/></td>
        </tr>
        <tr>
        	<td>Description</td><td>:</td>
            <td><textarea rows="3" style="width:200px;" name="sh_des" placeholder="Description Of Achivement"><?php echo $data['a_des']; ?></textarea></td>
        </tr>
        <tr>
        	<td>Upload Certificate</td><td>:</td>
            <td><input type="file" style="width:200px;" name="sh_certi" /></td>
        </tr>
        <tr>
        	<td>Date Of Achivement</td><td>:</td>
            <td colspan="2">
            <select name="day" id="day">

<?php
$i=1;
while($i<32)
{if($i<10){
echo "<option value=0$i>0".$i."</option>";}else
{echo "<option value=$i>$i</option>";}
$i++;
}
?>
</select>
<select style="" name="month" id="month">
<option value="--Month--">--Month--</option>
<option value=01>Jan</option>
<option value=02>Feb</option>
<option value=03>Mar</option>
<option value=04>Apr</option>
<option value=05>May</option>
<option value=06>Jun</option>
<option value=07>Jul</option>
<option value=08>Aug</option>
<option value=09>Sep</option>
<option value=10>Oct</option>
<option value=11>Nov</option>
<option value=12>Dec</option>
</select>
<select name="year" id="year">
<option value="--Year--">--Year--</option>
<?php
$i=1990;
while($i<2014)
{
echo "<option value=$i>$i</option>";
$i++;
}
?>
</select>
            </td>
        </tr>
        <tr id="archimsg">
        </tr>
<tr>
<td colspan="3" align="center">
<input type="button" name="b_address" value="Next" onclick="display('cpwd')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('cpwd')"/>
    <input type="button" value="Save" onclick="Change_archi()"/>
</td>
</tr>
    </table>




<table id="pro" align="center" style="width:60%; vertical-align:top; text-align:left;" cellpadding="5" cellspacing="5">

	<tr>
    	<td align="center">
        <img src='<?php echo $data1['image']; ?>' width="150" height="150" />
        
        </td>
    </tr>

    <tr>
    	<td><input type="file" name="sh_image" /></td>
    </tr>
    <tr>
    	<th><input type="submit" name="b_picture" value="Upload" />
        <input type="button" value="Next" onclick="display('s_add')" />
        <input type="button" value="Skip" onclick="display('s_add')" />
        </th>
    </tr>
	<tr>
    	<th></th>
    </tr>
    
</table>

<table id="s_acc" width="76%" align="center" style="vertical-align:top; display:none;" cellpadding="5" cellspacing="5" >

<tr>
	<td colspan="2"><h2><u>Account Detail</u></h2></td>
</tr>
<tr>
	<td  width="105px" class="label">School Name:</td>
	<td>
    <input type="text" maxlength="20" name="s_name" placeholder="Enter Name Of School" class="placeholder" onclick="validation('f_n')" readonly="readonly" value='<?php echo $data1['s_name'];?>'/>
	</td>
</tr>
<tr>
	<td class="label">Email:</td>
	<td><input name="email" type="text" placeholder="Enter Email Address" class="placeholder"  onclick="validation('e_i')" value='<?php echo $data1['email'];?>' readonly="readonly"/>
	</td>
</tr>

<tr>
	<td class="label">Mobile:</td>
	<td><input type="text" maxlength="10" name="contact" placeholder="Contact Number" class="placeholder" onclick="validation('p_n')" value='<?php echo $data1['contact'];?>'/>
	</td>
</tr>

<tr>
<td class="label">Phone No:</td>
<td><input type="text" name="pnumber2" class="placeholder" onclick="validation('p_n')"  maxlength="12"  placeholder="Phone Number" value='<?php echo $data1['phone'];?>'/>
</td>
</tr>

<tr>
	<td class="label">Principal Name:</td>
	<td><input type="text" name="HOD" maxlength="20" placeholder="Owner/Principal Name" class="placeholder" onclick="validation('pr_n')" value='<?php echo $data1['HOD'];?>'/>
	</td>
</tr>

<tr>
	<td class="label">School Type:</td>
	<td style="color:#000; font-size:15px">
    <?php 
    if($data1['s_type']=="boy")
	{
		echo '<input name="sex" type="radio" value="boy" checked="checked"/>Boys';
		echo '<input type="radio" name="sex" value="girl"/>Girls';
		echo '<input type="radio" name="sex" value="coeducation" />Coeducation';	
	}
	else if($data1['s_type']=="girl")
	{
		echo '<input name="sex" type="radio" value="boy" />Boys';
		echo '<input type="radio" name="sex" value="girl" checked="checked"/>Girls';
		echo '<input type="radio" name="sex" value="coeducation" />Coeducation';	
	}
	else 
	{
		echo '<input name="sex" type="radio" value="boy" />Boys';
		echo '<input type="radio" name="sex" value="girl" />Girls';
		echo '<input type="radio" name="sex" value="coeducation" checked="checked"/>Coeducation';	
	}
	
	?>
    
	</td>
</tr>

<tr>
	<td class="label" >Strength:</td>
	<td>
	<input type="text" name="student" maxlength="7" placeholder="Enter No Of Student" class="placeholder" onclick="validation('s1_n')" value='<?php echo $data1['n_student'];?>'/>	
	</td>
</tr>

<tr>
	<td class="label">Medium:</td>
    <td class="label"><input type="checkbox" name="hindi" value="Hindi,"/>Hindi
    	<input type="checkbox" name="english" value="English," />English
        <input type="checkbox" name="gujarati" value="Gujarati"/>Gujarati
    </td>
</tr>

<tr>
	<td class="label">Affiliation:</td>
	<td style="color:#000; font-size:15px;">
	<?php 
    if($data1['s_type']=="State Board")
	{
		echo '<input name="affi" type="radio" value="State Board" checked="checked"/>State Board';
		echo '<input type="radio" name="affi" value="CBSE"/>CBSE';
		echo '<input type="radio" name="affi" value="ICSE" />ICSE';
		echo '<input type="radio" name="affi" value="IB" />IB';	
	}
	else if($data1['s_type']=="CBSE")
	{
		echo '<input name="affi" type="radio" value="State Board" />State Board';
		echo '<input type="radio" name="affi" value="CBSE"/ checked="checked">CBSE';
		echo '<input type="radio" name="affi" value="ICSE" />ICSE';
		echo '<input type="radio" name="affi" value="IB" />IB';	
	}
	else if($data1['s_type']=="ICSE")
	{
		echo '<input name="affi" type="radio" value="State Board" />State Board';
		echo '<input type="radio" name="affi" value="CBSE"/ >CBSE';
		echo '<input type="radio" name="affi" value="ICSE" checked="checked"/>ICSE';
		echo '<input type="radio" name="affi" value="IB" />IB';	
	}
	else 
	{
		echo '<input name="affi" type="radio" value="State Board" />State Board';
		echo '<input type="radio" name="affi" value="CBSE"/ >CBSE';
		echo '<input type="radio" name="affi" value="ICSE" />ICSE';
		echo '<input type="radio" name="affi" value="IB" checked="checked"/>IB';	
	}
	
	?>
	</td>
</tr>

<tr id="addmsg3">
</tr>
<tr>
	<th colspan="2"><input type="button" name="b_address" value="Next" onclick="display('s_det')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('s_det')"/>
    <input type="button" value="Save" onclick="Change_Acoount();"/>
    </th>
</tr>

</table>

</td>
</tr>
</table>

</form>


</body>
</html>