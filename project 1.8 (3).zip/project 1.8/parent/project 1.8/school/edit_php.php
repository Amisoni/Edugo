<?php

session_start();
$id=$_SESSION['id'];
//$id=53;
include("../config.php");
if(isset($_GET['old']))
{
include("../config.php");

$nleng=strlen($_GET['new']);
$cleng=strlen($_GET['new']);
if($nleng>7)
{
if($_GET['new']==$_GET['cnew'])
{
$result=mysql_query("update school set  password='".$_GET['new']."' where password='".$_GET['old']."' and id=".$id."");
$no=mysql_affected_rows();

if($no==1)
{
	echo "<td colspan='3' style='color:green'>Password Successfully Updated</td>";
}
else
{
echo "<td colspan='3' style='color:red'>Incorrect old Not Match</td>";
}
}
else
{
	echo "<td colspan='3' style='color:red'>Confirm Password dose Not Match</td>";
}
}
else
{
	echo "<td colspan='3' style='color:red'>At Least 8 Character Password </td>";
}
}
if(isset($_GET['add']))
{
	//echo "update sch_profile set address='".$_GET['add']."', city='".$_GET['city']."',state='".$_GET['state']."',n_hood='".$_GET['neig']."' , zip='".$_GET['zip']."' where sch_id=".$id;
	@mysql_query("update sch_profile set address='".$_GET['add']."', city='".$_GET['city']."',state='".$_GET['state']."',n_hood='".$_GET['neig']."' , zip='".$_GET['zip']."' where sch_id=".$id);
	$no=mysql_affected_rows();
	if($no>0)
	{
		echo "<td colspan='3' style='color:green'>Address Successfully Updated</td>";
	}
	else
	{
		echo "<td colspan='3' style='color:red'>Error For Address Updating</td>";
	}
}
if(isset($_GET['s_fecu']))
{
	@mysql_query("update sch_profile set s_feculty='".$_GET['s_fecu']."', s_standard='".$_GET['std1']."-".$_GET['std2']."', s_room='".$_GET['s_room']."', s_library='".$_GET['lib']."', s_ground='".$_GET['grd']."' where sch_id=".$id);
	$no=mysql_affected_rows();
	if($no>0)
	{
		echo "<td colspan='2' style='color:green'>Schools Details Successfully Updated</td>";
	}
	else
	{
		echo "<td colspan='2' style='color:red'>Error For School Details Updating</td>";
	}
}
if(isset($_GET['qul']))
{
	//echo "update sch_profile set p_quli='".$_GET['qul']."', p_join='".$_GET['joint']."', p_experience='".$_GET['expe']."' where sch_id=".$id;
	@mysql_query("update sch_profile set p_quli='".$_GET['qul']."', p_join='".$_GET['joint']."', p_experience='".$_GET['expe']."' where sch_id=".$id);
	$no=mysql_affected_rows();
	if($no>0)
	{
		echo "<td colspan='3' style='color:green'>Principal Details Successfully Updated</td>";
	}
	else
	{
		echo "<td colspan='3' style='color:red'>Error For Principal Details Updating</td>";
	}
}
if(isset($_GET['a_name']))
{
	//echo "update sch_profile set a_name='".$_GET['a_name']."', a_des='".$_GET['desc']."', a_date='".$_GET['date']."' where sch_id=".$id;
	mysql_query("update sch_profile set a_name='".$_GET['a_name']."', a_des='".$_GET['desc']."', a_date='".$_GET['date']."' where sch_id=".$id);
	$no=mysql_affected_rows();
	if($no>0)
	{
		echo "<td colspan='3' style='color:green'>Principal Details Successfully Updated</td>";
	}
	else
	{
		echo "<td colspan='3' style='color:red'>Error For Principal Details Updating</td>";
	}
}
if(isset($_GET['scontact']))
{
	//echo "update sch_profile set address='".$_GET['add']."', city='".$_GET['city']."',state='".$_GET['state']."',n_hood='".$_GET['neig']."' , zip='".$_GET['zip']."' where sch_id=".$id;
	@mysql_query("update school set contact='".$_GET['scontact']."', phone='".$_GET['spnumber']."',HOD='".$_GET['shod']."',n_student='".$_GET['snstudent']."',s_type='".$_GET['ssex']."',affi='".$_GET['affi']."' where id=".$id);
	$no=mysql_affected_rows();
	if($no>0)
	{
		echo "<td colspan='3' style='color:green'>Address Successfully Updated</td>";
	}
	else
	{
		echo "<td colspan='3' style='color:red'>Error For Address Updating</td>";
	}
}

?>