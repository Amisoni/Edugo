<?php 
include("../config.php");
if(isset($_POST['saveprofile']))
{	session_start();
	$id=$_SESSION['id'];
	move_uploaded_file($_FILES['sh_image']['tmp_name'], "images/".$_FILES['sh_image']['name']);
	$filepath = "images/".$_FILES['sh_image']['name']; 
	
	mysql_query("update school set image='$filepath' where id=$id" ) ;
	
	

@$q="insert into sch_profile (sch_id,address,city,state,zip,n_hood,s_feculty,s_standard,s_library,s_ground,s_room,p_quli,p_join,p_experience,a_name,a_des,a_certi,a_date,picture) value(".$id.",'".$_POST['sh_add']."','".$_POST['sh_city']."','".$_POST['sh_state']."','".$_POST['sh_zip']."','".$_POST['sh_neighbour']."','".$_POST['sh_feculty']."','".$_POST['sh_standard1']."-".$_POST['sh_standard2']."','".$_POST['sh_library']."','".$_POST['sh_ground']."','".$_POST['sh_room']."','".$_POST['sh_qul']."','".$_POST['sh_join']."','".$_POST['sh_exp']."','".$_POST['sh_achive']."','".$_POST['sh_des']."','".$_POST['sh_certi']."','".$_POST['year'].$_POST['month'].$_POST['day']."','".$_POST['sh_image']."')";
echo $q;
mysql_query($q);
header("location:header6.php");
unset($_POST['saveprofile']);
}


?>