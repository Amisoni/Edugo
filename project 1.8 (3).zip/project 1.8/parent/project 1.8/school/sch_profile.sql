-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 09, 2013 at 10:48 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `edugo`
--

-- --------------------------------------------------------

--
-- Table structure for table `sch_profile`
--

CREATE TABLE IF NOT EXISTS `sch_profile` (
  `ID` int(5) NOT NULL AUTO_INCREMENT,
  `sch_id` int(5) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zip` int(6) NOT NULL,
  `n_hood` varchar(200) NOT NULL,
  `s_feculty` int(3) NOT NULL,
  `s_standard` varchar(10) NOT NULL,
  `s_library` varchar(3) NOT NULL,
  `s_ground` varchar(3) NOT NULL,
  `s_room` int(3) NOT NULL,
  `p_quli` varchar(10) NOT NULL,
  `p_join` int(4) NOT NULL,
  `p_experience` int(2) NOT NULL,
  `a_name` varchar(50) NOT NULL,
  `a_des` varchar(200) NOT NULL,
  `a_certi` varchar(200) NOT NULL,
  `a_date` date NOT NULL,
  `picture` varchar(200) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `sch_profile`
--

INSERT INTO `sch_profile` (`ID`, `sch_id`, `address`, `city`, `state`, `zip`, `n_hood`, `s_feculty`, `s_standard`, `s_library`, `s_ground`, `s_room`, `p_quli`, `p_join`, `p_experience`, `a_name`, `a_des`, `a_certi`, `a_date`, `picture`) VALUES
(1, 0, 'gjgj', 'Ahmedabad', 'Mumbai', 35, '', 0, '', '', '', 0, '', 0, 0, '', '', '', '0000-00-00', ''),
(2, 0, 'fsadf', 'Patan', 'Gujarat', 444541, 'dgsdgfsg', 5434, '2-5', 'yes', 'No', 454, 'MBA', 9, 9, 'yhrdhd', 'dfghgfh', 'Lighthouse.jpg', '2003-08-11', 'Lighthouse.jpg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
