function display(id)
{
	//
	document.getElementById('s_add').style.display="none";
	document.getElementById('cpwd').style.display="none";
	document.getElementById('s_det').style.display="none";
	document.getElementById('s_acc').style.display="none";

	
	document.getElementById('p_del').style.display="none";
	//document.getElementById('s_det').style.display="none";
	document.getElementById('p_del').style.display="none";
	document.getElementById('pro').style.display="none";
	document.getElementById('archi').style.display="none";
	//alert("hi..");
	document.getElementById('s_add1').style.backgroundColor="gray";
	document.getElementById('s_acc1').style.backgroundColor="gray";
	document.getElementById('s_det1').style.backgroundColor="gray";
	document.getElementById('p_del1').style.backgroundColor="gray";
	document.getElementById('pro1').style.backgroundColor="gray";
	document.getElementById('archi1').style.backgroundColor="gray";
	document.getElementById('cpwd1').style.backgroundColor="gray";
	document.getElementById(id).style.display="table";
	var sid=id+"1";
	document.getElementById(sid).style.backgroundColor="white";
}
function Change_Password()
{
	
var old=document.forms["edit"]["opwd"].value;
var pwd=document.forms["edit"]["npwd"].value;
var cpwd=document.forms["edit"]["rpwd"].value;

	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("pmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  
	 xmlhttp.open("GET","edit_php.php?old="+old+"&&new="+pwd+"&&cnew="+cpwd,true); 
	 xmlhttp.send();
}
function Change_schooldel()
{
	var numbers = /^[0-9]+$/; 
var lib = get_radio_value1();
var grd = get_radio_value();	
var s_fecu=document.forms["edit"]["sh_feculty"].value;
var s_room=document.forms["edit"]["sh_room"].value;
var std1=document.forms["edit"]["sh_standard1"].value;
var std2=document.forms["edit"]["sh_standard2"].value;
document.getElementById("r_id").style.display="none"; 
//var a=document.getElementById("sh_standard1");	
//var std1=a.options[a.selectedIndex].value;
//var a=document.getElementById("sh_standard2");	
//var std2=a.options[b.selectedIndex].value;
if((!numbers.test(s_room)))
      { 
	  document.getElementById("r_id").style.display="block"; 
	  document.getElementById("sdelmsg").innerHTML=""; 
      
      }  
	 else
	 {
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("sdelmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  		//alert("edit_php.php?s_fecu="+s_fecu+"&&s_room="+s_room+"&&std1="+std1+"&&std2="+std2);
	 xmlhttp.open("GET","edit_php.php?s_fecu="+s_fecu+"&&s_room="+s_room+"&&std1="+std1+"&&std2="+std2+"&&lib="+lib+"&&grd="+grd,true); 
	 xmlhttp.send();
}
}
function Change_address()
{

var add=document.forms["edit"]["sh_add"].value;
//var city=document.forms["edit"]["sh_city"].value;
//var state=document.forms["edit"]["sh_state"].value;
var zip=document.forms["edit"]["sh_zip"].value;
var neig=document.forms["edit"]["sh_neighbour"].value;
var a=document.getElementById("sh_city");	
var city=a.options[a.selectedIndex].value;
var a=document.getElementById("sh_state");	
var state=a.options[a.selectedIndex].value;
//alert("hiii");
	document.getElementById("z_id").style.display="none"; 
	var numbers = /^[0-9]+$/; 
	 if((!numbers.test(zip))|| zip.length!=6)
      { 
	  document.getElementById("z_id").style.display="block"; 
	  document.getElementById("addmsg").innerHTML=""; 
      
      }  
	 else
	 {
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("addmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  		//alert("edit_php.php?add="+add+"&&city="+city+"&&zip="+zip+"&&neig="+neig);
	 xmlhttp.open("GET","edit_php.php?add="+add+"&&city="+city+"&&state="+state+"&&zip="+zip+"&&neig="+neig,true); 
	 xmlhttp.send();
}
}
function Change_archi()
{
	
var a_name=document.forms["edit"]["sh_achive"].value;
	
var desc=document.forms["edit"]["sh_des"].value;

var a=document.getElementById("day");	
var day=a.options[a.selectedIndex].value;
a=document.getElementById("month");
var month=a.options[a.selectedIndex].value;
a=document.getElementById("year");
var year=a.options[a.selectedIndex].value;
var date=year+"-"+month+"-"+day;
//alert(date);
//alert(add+city+state+zip+neig);

	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("archimsg").innerHTML=xmlhttp.responseText;
    }
  	}
  		//alert("edit_php.php?add="++"&&city="+city+"&&zip="+zip+"&&neig="+neig);
	 xmlhttp.open("GET","edit_php.php?a_name="+a_name+"&&desc="+desc+"&&date="+date,true); 
	 xmlhttp.send();
}

function Change_pricipal()
{

var a=document.getElementById("sh_qul1");	
var qul=a.options[a.selectedIndex].value;	
alert(qul);
a=document.getElementById("sh_join");
var joint=a.options[a.selectedIndex].value;	

a=document.getElementById("sh_exp");
var expe=a.options[a.selectedIndex].value;	


	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("prinmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  		//alert("edit_php.php?add="+add+"&&city="+city+"&&zip="+zip+"&&neig="+neig);
	 xmlhttp.open("GET","edit_php.php?qul="+qul+"&&joint="+joint+"&&expe="+expe,true); 
	 xmlhttp.send();
}

function get_radio_value()
{
            var inputs = document.getElementsByName("sex");
			var inputs = document.getElementsByName("sh_library");
			var inputs = document.getElementsByName("sh_ground");
            for (var i = 0; i < inputs.length; i++) {
              if (inputs[i].checked) {
                return inputs[i].value;
              }
      }
}
function get_radio_value1()
{
            var inputs = document.getElementsByName("sh_library");
			for (var i = 0; i < inputs.length; i++) {
              if (inputs[i].checked) {
                return inputs[i].value;
              }
      }
}

function Change_Acoount()
{

var scontact=document.forms["edit"]["contact"].value;
var spnumber=document.forms["edit"]["pnumber2"].value;
var shod=document.forms["edit"]["HOD"].value;
var snstudent=document.forms["edit"]["student"].value;
var ssex = get_radio_value();

//alert(add+city+state+zip+neig);


	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("addmsg3").innerHTML=xmlhttp.responseText;
    }
  	}
	//alert(ssex);
 		//alert("edit_php.php?add="+add+"&&city="+city+"&&zip="+zip+"&&neig="+neig);
	 xmlhttp.open("GET","edit_php.php?scontact="+scontact+"&&spnumber="+spnumber+"&&shod="+shod+"&&snstudent="+snstudent+"&&ssex="+ssex,true); 
 
	 xmlhttp.send();
}
