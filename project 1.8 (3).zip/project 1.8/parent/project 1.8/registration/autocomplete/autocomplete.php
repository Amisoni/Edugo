<?php
	$q=$_GET['q'];
	
	$result = mysqli_query($mysqli,$sql) or die(mysqli_error());
	
	if($result)
	{
		while($row=mysqli_fetch_array($result))
		{
			echo $row['sname']."\n";
		}
	}
?>