<div id="hindi" style="float:left;margin-top:20px;">
	<ul>
        <li style="margin-bottom:20px;font-size:20px;"><a href="hindipaper.php" target="left" >Hindi Question Paper</a></li>
        <li style="margin-bottom:20px;font-size:20px;"><a href="englishpaper.php" target="left">English Question Paper</a></li>
        <li style="margin-bottom:20px;font-size:20px;"><a href="reasoningpaper.php" target="left">Reasoning Question Paper</a></li>
        <li style="margin-bottom:20px;font-size:20px;"><a href="mathspaper.php" target="left">Mathematics Question Paper</a></li>
    </ul>
</div>
<p></p>
