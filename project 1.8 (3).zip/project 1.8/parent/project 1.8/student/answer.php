<?php 
			session_start();
                        include("../config.php");
			if($_SESSION['id']!="")
			{
			$id=$_SESSION['id'];
			
			$q="select * from result where sid=".$id;
			$res=mysql_query($q);
			$data=mysql_fetch_array($res);
			echo "<font color='#FFFFFF'>Welcome..".$data['sname']."!</font>";
			}
			else
			{
				header('location:registration/first.php');	
			}
			$sql="select * from result where sid=".$id;
			$res=mysql_query($sql);
			echo "<table frame='box' style='border:2px' align='center' cellspacing='0px' cellpadding='10px'>";
	echo "<tr bgcolor='#666666' style='color:#FFF'><td>Result Id</td>";
	echo "<td>Name</td>";
	echo "<td>Attempt</td>";
	echo "<td>skipped</td>";
	echo "<td>TotalMarks</td>";
	echo "<td>Get Marks</td><td>By Date</td></tr>";
			$count=0;
			while($data=mysql_fetch_array($res))
			{$count++;
				$mod=$count%2;
				if($mod==0)
				{
				echo "<tr  bgcolor='#FFFFCC'><td>$data[0]</td><td>$data[2]</td><td>$data[3]</td><td>$data[3]</td><td>$data[5]</td><td>$data[6]</td><td>$data[7]</td></tr>";
				}else
				{
					echo "<tr bgcolor='#FFFFFF'><td>$data[0]</td><td>$data[2]</td><td>$data[3]</td><td>$data[3]</td><td>$data[5]</td><td>$data[6]</td><td>$data[7]</td></tr>";
				}
//echo "Welcome..".$_POST['$var']."!";
			}
			//echo date('dS.m.Y');
			

		?>