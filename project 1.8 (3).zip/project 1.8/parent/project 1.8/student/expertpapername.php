
<?php 
include("../config.php");

if (isset($_GET['q']))
{

echo "<select id='subject' style='width:140px; font-size:15px;' onchange='showchap(this.value)'>";
echo "<option value=''>--Select Subject--</option>";
	if($_GET['q']!='no')
	{
	$sq="select * from subject where c_id=".$_GET['q'];
	$res=mysql_query($sq);
	while($data=mysql_fetch_array($res))
	{ 	echo $data['s_id'];
		echo "<option value='".$data['s_id']."'>".$data['sname']."</option>";	
	}
                   		
	}
	echo "</select>";
}
if(isset($_GET['cname']) && isset($_GET['sname']))
{
	//echo $_GET['cname'];
    //echo $_GET['sname'];
	//echo "select * from expert_paper where s_id='".$_GET['sname']."'and c_id='".$_GET['cname']."'";
	$chpq="select expert_paper.p_id,f.f_name,f.l_name,c.cname,s.sname from expert_paper,subject s, class c,feculty f where expert_paper.s_id='".$_GET['sname']."'and expert_paper.c_id='".$_GET['cname']."' and expert_paper.s_id=s.s_id and expert_paper.c_id=c.c_id and f.id=expert_paper.u_id" ;
	$result=mysql_query($chpq);
	echo "<td colspan='3' align='center'><table border='1' width='80%'>";
	echo "<tr>
		<td>Paper ID</td><td>User Name</td><td>Class</td><td>Subject</td><td></td></tr>";
	$i=0;	

	
	while(@$data1=mysql_fetch_array($result))
	{
		echo "<tr style='text-transform:capitalize;'>
		<td>".$data1[0]."</td><td>".$data1[1]." ".$data1[2]."</td><td>".$data1[3]."</td><td>".$data1[4]."</td><td><a href='expert_paper_exam.php?p_id=".$data1[0]."'>Give Exam</a></td></tr>";
		//echo "expert_paper_exam.php?p_id=".$data1[0]."<br/>";
		$i++;	
	}

	echo "</table></td>";
}
?>
