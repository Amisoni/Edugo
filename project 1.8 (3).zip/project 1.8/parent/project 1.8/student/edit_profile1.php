<?php
include("../config.php");
session_start();
$id=$_SESSION['id'];
//echo "select * from s_info where s_id=".$id;
if(isset($_POST['savep']))
{
include("../config.php");
@session_start();
			{
			move_uploaded_file($_FILES['fileupload']['tmp_name'], "images/".$_FILES['fileupload']['name']);
			$filepath = "images/".$_FILES['fileupload']['name']; 
			$id=$_SESSION['id'];
			if($_SESSION['id']!="")
			{
			$q="select * from student where ID=".$id;
			$res=mysql_query($q);
			$data=mysql_fetch_array($res);			
			}
			
			
			mysql_query("insert into profile_picture (s_id,image) values(".$id.",'".$filepath."')");
			$r1=mysql_query("select max(p_id) from profile_picture");
			$d1=mysql_fetch_array($r1);
			$nid=$d1[0];
			mysql_query("insert into profile(n_id,t_id,s_id) values (".$nid.",1,".$id.")");
			mysql_query("update student set image='$filepath' where id=$id" ) ;
			//echo "update student set image='$filepath' where id=".$id;
			//mysql_close($con);
			
			//header('Location:header2.php');
			}
}
$result1=mysql_query("select * from student where id=".$id);
$data1=mysql_fetch_array($result1);
$result=mysql_query("select * from s_info where s_id=".$id);
$data=mysql_fetch_array($result);
//echo $data[0];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script>
function change()
{
	//alert("hi....");
	var x=document.forms["edit"]["standard"].value;
	//alert(x);
	document.getElementById("gra").options[0].selected = true;
	//document.getElementById("stand").options[0].selected = true; 
	if(x=="Graduate")
	{
		document.getElementById("gra").style.display="block";
		//document.getElementById("stand").style.display="block";	
	}
	else
	{
		//document.getElementById("stand").style.display="none";
		document.getElementById("gra").style.display="none";
	}
		
}
function display(id)
{
	document.getElementById('s_add').style.display="none";
	document.getElementById('s_det').style.display="none";
	document.getElementById('p_del').style.display="none";
	document.getElementById('s_det').style.display="none";
	document.getElementById('p_del').style.display="none";
	document.getElementById('pro').style.display="none";
	document.getElementById('cpwd').style.display="none";
	document.getElementById('archi').style.display="none";
	document.getElementById('acco').style.display="none";
	//alert("hi..");
	document.getElementById('s_add1').style.backgroundColor="gray";
	document.getElementById('s_det1').style.backgroundColor="gray";
	document.getElementById('p_del1').style.backgroundColor="gray";
	document.getElementById('pro1').style.backgroundColor="gray";
	document.getElementById('archi1').style.backgroundColor="gray";
	document.getElementById('cpwd1').style.backgroundColor="gray";
	document.getElementById('acco1').style.backgroundColor="gray";
	document.getElementById(id).style.display="table";
	var sid=id+"1";
	document.getElementById(sid).style.backgroundColor="white";
}
function Change_Password()
{
	
var old=document.forms["edit"]["opwd"].value;
var pwd=document.forms["edit"]["npwd"].value;
var cpwd=document.forms["edit"]["rpwd"].value;
var reg = /^([a-zA-Z0-9]{0,8})$/;
	var opwd1=document.forms["edit"]["opwd"].value;
	var npwd1=document.forms["edit"]["npwd"].value;
	var rpwd1=document.forms["edit"]["rpwd"].value;
	/*if(rpwd1.length<8)
     {   
	   		alert("Enter AtLeast 8 character Password \n");
	  		return false;
	 }*/
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("pmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  
	 xmlhttp.open("GET","edit_php.php?old="+old+"&&new="+pwd+"&&cnew="+cpwd+"&&rpwd1="+rpwd1,true); 
	 xmlhttp.send();
}

function set_city()
{
//alert("hi...");	
	<?php
  $d=explode("-",$data1['birth_date']);
  ?>
  //alert ('<?php echo $d[2]; ?>');
var ddl = document.getElementById('day');
	var opts = ddl.options.length;
	for (var i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[2]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	ddl = document.getElementById('month');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[1]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	ddl = document.getElementById('city');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['s_city']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	ddl = document.getElementById('year');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[0]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	var no=1;
	ddl = document.getElementById('stand');
	opts = ddl.options.length;
	
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data1['std']; ?>'){
		no=0;
        ddl.options[i].selected = true;
        break;
    }
	}
	//alert("hi..."+no);
	if(no==1)
	{
	//alert("hi...");
	document.getElementById('stand').options[9].selected = true;
	document.getElementById("gra").style.display="block";
	ddl = document.getElementById('gra');
	opts = ddl.options.length;
		for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data1['std']; ?>'){
		no=1;
        ddl.options[i].selected = true;
        break;
    }
	}
	}
	
}


function Change_Address()
{	
document.getElementById("z_id").style.display="none"; 
var padd=document.forms["edit"]["paddress"].value;
var ptown=document.forms["edit"]["town"].value;
var pzip=document.forms["edit"]["zipcode"].value;
var pneg=document.forms["edit"]["neighberhood"].value;
var tadd=document.forms["edit"]["taddress"].value;
var a=document.getElementById("city");	
var city=a.options[a.selectedIndex].value;
var numbers = /^[0-9]+$/; 
 if((!numbers.test(pzip))|| pzip.length!=6)
      { 
	  document.getElementById("z_id").style.display="block"; 
	  document.getElementById("addmsg").innerHTML=""; 
      
      }  
	 else
	 {
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("addmsg").innerHTML=xmlhttp.responseText;
    }
  	}

  //alert ("edit_php.php?padd="+padd+"&&ptown="+ptown+"&&pzip"+pzip+"&&pneg"+pneg+"&&tadd"+tadd);
	 xmlhttp.open("GET","edit_php.php?padd="+padd+"&&ptown="+ptown+"&&pzip="+pzip+"&&pneg="+pneg+"&&tadd="+tadd+"&&city="+city,true); 
	 xmlhttp.send();
}
}
function change_interst()
{
	var hobby=document.forms["edit"]["hobby"].value;
	var sport=document.forms["edit"]["sport"].value;
	var subject=document.forms["edit"]["subject"].value;
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("intmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  //alert ("edit_php.php?padd="+padd+"&&ptown="+ptown+"&&pzip"+pzip+"&&pneg"+pneg+"&&tadd"+tadd);
	 xmlhttp.open("GET","edit_php.php?hobby="+hobby+"&&sport="+sport+"&&subject="+subject,true); 
	 xmlhttp.send();
}
function change_aboutyou()
{
	
	var relg=document.forms["edit"]["Relegions"].value;
	var desc=document.forms["edit"]["discription"].value;
	var lang="";
	if(document.getElementById("gujarati").checked==true)
	{
		lang=lang+",gujarati";
	}
	if(document.getElementById("English").checked==true)
	{
		lang=lang+",English";
	}
	if(document.getElementById("Hindi").checked==true)
	{
		lang=lang+",Hindi";
	}
	//alert(lang);
	//var subject=document.forms["edit"]["subject"].value;

	
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("abtarchi").innerHTML=xmlhttp.responseText;
    }
  	}
  //alert ("edit_php.php?padd="+padd+"&&ptown="+ptown+"&&pzip"+pzip+"&&pneg"+pneg+"&&tadd"+tadd);
	 xmlhttp.open("GET","edit_php.php?relg="+relg+"&&desc="+desc+"&&lang="+lang,true); 
	 xmlhttp.send();
}
function change_school()
{
	
	var s_name=document.forms["edit"]["schoolname"].value;
	var s_p_name=document.forms["edit"]["sch_pri_name"].value;
	var s_p_cont=document.forms["edit"]["contactno"].value;
	//var subject=document.forms["edit"]["subject"].value;
	//alert("hi..");
	//alert("hi..");
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("archimsg").innerHTML=xmlhttp.responseText;
    }
  	}
	//alert("edit_php.php?s_name="+s_name+"&&s_p_name="+s_p_name+"&&s_p_cont="+s_p_cont);
  //alert ("edit_php.php?padd="+padd+"&&ptown="+ptown+"&&pzip"+pzip+"&&pneg"+pneg+"&&tadd"+tadd);
	 xmlhttp.open("GET","edit_php.php?s_name="+s_name+"&&s_p_name="+s_p_name+"&&s_p_cont="+s_p_cont,true); 
	 xmlhttp.send();
}
function get_radio_value()
{
            var inputs = document.getElementsByName("sex");
            for (var i = 0; i < inputs.length; i++) {
              if (inputs[i].checked) {
                return inputs[i].value;
              }
      }
}
function change_account()
{
var numbers = /^[0-9]+$/;  
var a=document.getElementById("stand");
var stand=a.options[a.selectedIndex].value;

if(stand=="Graduate")
{
	//alert("hi..");
	 a=document.getElementById("gra");
	 stand=a.options[a.selectedIndex].value;
	 //alert(stand);
}
a=document.getElementById("day");	
var day=a.options[a.selectedIndex].value;
a=document.getElementById("month");	
var month=a.options[a.selectedIndex].value;
a=document.getElementById("year");
year=a.options[a.selectedIndex].value;
date=year+"-"+month+"-"+day;
//alert(date);
//a=document.getElementById("stand");
//var stand=a.options[a.selectedIndex].value;
//alert(stand);
	var f_name=document.forms["edit"]["first_name"].value;
	var l_name=document.forms["edit"]["last_name"].value;
	var sch_name=document.forms["edit"]["school_name"].value;
	var e_id=document.forms["edit"]["email"].value;
	var m_no=document.forms["edit"]["number"].value;
	var p_no=document.forms["edit"]["pnumber"].value;
    var no=0;
 var id = get_radio_value();
	//alert(id);
	if((!numbers.test(m_no))|| m_no.length!=10)
      {   
	  no++;
      }  
	  if((!numbers.test(p_no)))
      {   
	  no++;
      }  
	if(no==0)
	{
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("accountdel").innerHTML=xmlhttp.responseText;
    }
  	}
	 xmlhttp.open("GET","edit_php.php?f_name="+f_name+"&&l_name="+l_name+"&&sch_name="+sch_name+"&&e_id="+e_id+"&&m_no="+m_no+"&&p_no="+p_no+"&&sex="+id+"&&stand="+stand+"&&date="+date,true); 
	 xmlhttp.send();
	}
	else
	{
		document.getElementById("accountdel").innerHTML="<td colspan='2'><label style='color:red;'>Please Fill Valid Details</label></td>";
	}
}
</script>
<title>Untitled Document</title>
</head>

<body style="margin:0px" onload="set_city();">

<form name="edit" method="post" action="" enctype="multipart/form-data">

<table width="70%" align="center" border="1px">
<tr>
<td>

<table width="100%" style="vertical-align:top; text-transform:capitalize; color:#CCC; cursor:pointer;" cellpadding="0" cellspacing="0">
	<tr bgcolor="gray" style="text-align:center; cursor:pointer" >
	<td id="acco1" width="100px" height="30px;"><label onclick="display('acco')">Account</label></td>
	<td id="s_add1" bgcolor="#FFFFFF" width="100px" height="30px;"><label onclick="display('s_add')">Profile Picture</label></td>
	<td id="s_det1" width="100px"><label onclick="display('s_det')">Address</label></td>
	<td id="p_del1" width="100px"><label onclick="display('p_del')">Intersted</label></td>
	<td id="archi1" width="100px"><label onclick="display('archi')">About You</label></td>
	<td id="pro1" width="100px"><label onclick="display('pro')">About School</label></td>	
	<td id="cpwd1" width="100px" height="30px;"><label onclick="display('cpwd')">Password</label></td>
</tr>
</table>

</td>
</tr>

<tr>
<td>

<table id="acco" align="center" width="70%" style="display:none;" >
<tr>
<td colspan="2">
<h2><u>Account Detail</u></h2>
</td>
</tr>
<tr>
	<td  class="label">First Name:</td>
	<td class="label"><input type="text" name="first_name" placeholder="First Name" style="width:85px; height:18px; font-size:15px" readonly="readonly" value="<?php echo $data1['f_name']; ?>"/> Last Name <input type="text" name="last_name" placeholder="Last Name" style="width:85px; height:18px; font-size:15px" readonly="readonly" value="<?php echo $data1['l_name']; ?>"/>
	</td>
</tr>

<tr>
	<td class="label">School Name:</td>
	<td><input type="text" name="school_name" placeholder="Enter School Name" class="placeholder" value="<?php echo $data1['s_name']; ?>"/></td>
</tr>

<tr>
	<td class="label">Email:</td>
    </td>
	<td><input type="text" name="email" placeholder="Enter Email Address" class="placeholder" readonly="readonly" value="<?php echo $data1['email']; ?>"/>
    </td>
</tr>

<tr>
	<td class="label">Standard:</td>
	<td>
	<table cellpadding="0" cellspacing="0" style="text-transform:capitalize;"><tr><td>
	<select id="stand" class="label" name="standard" onchange="change()">
		<option value="Select Standard">--Standard--</option>
		<?php
		include("../config.php");
	$result9=mysql_query("select * from class");
	while($data9=mysql_fetch_array($result9))
	{
		echo "<option value='".$data9[0]."'>".ucfirst($data9[1])."</option>";
	}
		?>
		<option value="Graduate">Other >></option>
	</select></td><td>
	<select id="gra" class="label" name="Graduate" style="display:none;">
		<option value="Select Graduate">--Graduate--</option>	
		<option value="Diploma">Diploma</option>
		<option value="BCA">BA</option>
		<option value="BCom">BCom</option>		
		<option value="BBA">BSC</option>
		<option value="BSC IT">BBA</option>
	</select>
	</td></tr></table>
	</td>
</tr>

<tr>
	<td class="label">Mobile:</td>
	<td><input type="text" name="number" placeholder="Enter Mobile Number" class="placeholder" value="<?php echo $data1['contact']; ?>"/>
	</td>
</tr>

<tr>
<td class="label">Phone No:</td>
<td><input type="text" name="pnumber" class="placeholder" style=" margin-right:5%" maxlength="20" value="<?php echo $data1['phone']; ?>" />
</td>
</tr>

<tr>
<td class="label">Birth Date:</td>
<td style="color:#000; font-size:15px">
  
  <select name="day" id="day">  
    <?php
$i=1;
while($i<32)
{if($i<10){
echo "<option value=0$i>0".$i."</option>";}else
{echo "<option value=$i>$i</option>";}
$i++;
}
?>
  </select>
<select name="month" id="month">
      <option value=01>Jan</option>
      <option value=02>Feb</option>
      <option value=03>Mar</option>
      <option value=04>Apr</option>
      <option value=05>May</option>
      <option value=06>Jun</option>
      <option value=07>Jul</option>
      <option value=08>Aug</option>
      <option value=09>Sep</option>
      <option value=10>Oct</option>
      <option value=11>Nov</option>
      <option value=12>Dec</option>
    </select>
<select name="year" id="year">
<?php
$i=1900;

while($i<2031)
{
echo "<option value=$i>$i</option>";
$i++;
}
?>
</select></td></tr>
<tr>
	<td class="label">Gender:</td>
	<td style="color:#000; font-size:15px">
	 <?php
	if($data1['sex']=="Male")
	{
		echo '<input name="sex" id="sex" type="radio" value="Male" checked="checked"/>Male';
	echo '<input type="radio" name="sex" id="sex" value="Female" />Female';
	}
	else
	{
		echo '<input name="sex" type="radio" id="sex" value="Male" />Male';
	echo '<input type="radio" name="sex" value="Female" id="sex" checked="checked"/>Female';
	}
	?>
	</td>
</tr>


<tr id="accountdel">
<td colspan="3"></td></tr>
<tr>
<td colspan="2">
<input type="button" value="Next" onclick="display('s_add')" />
<input type="button" value="Skip" onclick="display('s_add')" />
<input type="button" value="Update" onclick="change_account()" />
</td>
</tr>
</table>


<table id="cpwd" width="60%" align="center" style="vertical-align:top; text-align:left; display:none;" cellpadding="5" cellspacing="5">
<tr>
<td colspan="3">
<h2><u>Change Password</u></h2>
</td>
</tr>
<tr><td>Old Password</td><td>:</td><td><input type="password" width="200px" name="opwd" /></td></tr>
<tr><td>New Password</td><td>:</td><td><input type="password" width="200px" name="npwd" /></td></tr>
<tr><td>Confirm Password</td><td>:</td><td><input type="password" width="200px" name="rpwd" /></td></tr>
<tr id="pmsg"></tr>
<tr><td colspan="3"><input type="button" name="password" id="password" value="Change Password" onclick="Change_Password()" /></td></tr>
</table>
<table id="s_add" width="60%" align="center" style="vertical-align:top" cellpadding="5" cellspacing="5">

<tr>
<td colspan="2">
<h2><u>Profile Picture</u></h2>
</td>
</tr>

<tr>
    	<td align="center" colspan="3">
        <img src='<?php echo $data1['image'] ?>' width="150" height="150" />
        
        </td>
    </tr>

<tr>
		<td>
			<input type="file" name="fileupload" id="fileupload"/>
            
            </td>
</tr>
<tr>
	<th colspan="2"><input type="button" name="b_address" value="Next" onclick="display('s_det')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('s_det')"/>
    <input type="submit" name="savep" value="Save Profile" />
    
    </th>
</tr>

</table>

<table align="center" cellpadding="5" cellspacing="5" id="s_det" style="display:none;vertical-align:top; text-align:left;" width="62%" >
<tr>
	<td colspan="2">
		<h2><u>Address Detail</u></h2>
	</td>
</tr>
<tr>
        <td>
        <label>Permenent Address:</label>
        </td>
        <td>
        	<input type="text" width="200" name="paddress" id="paddress" value="<?php echo $data['s_p_add'] ?>" /></td></tr>	
		    <tr>   
            <td ><label>Town :</label></td><td><input type="text" width="200" name="town" id="town" value="<?php echo $data['s_town'] ?>" /></td>
			</tr>
            <tr>
           <td ><label>City :</label></td><td><select name="city" id="city">
            <option value="Ahmedabad">Ahmedabad</option>
            <option value="Rajkot">Rajkot</option>
            <option value="Diu">Diu</option>
            <option value="Maheshana">Maheshana</option>
            <option value="London">London</option>
            </select></td></tr>
			<tr>
            <td >
            <label>Zip code :</label></td><td><input type="text" size="6" name="zipcode" id="zipcode" maxlength="6" value="<?php echo $data['s_zipcode'] ?>"/></td>
			</tr>
            
            <tr>
            <td >
            
 	        <label>Neighberhood :</label></td><td><input type="text" width="200" name="neighberhood" id="neighberhood" value="<?php echo $data['s_neighbour'] ?>"/></td>
            </tr>
            
    
	
    <tr>
		<td>
			<label>Temparary Address:</label>
        </td>
        <td>
        	<input type="text" width="200" name="taddress" id="taddress" value="<?php echo $data['s_t_add'] ?>"/>
        </td>
	</tr>    
    <tr id="addmsg">
   </tr>
	<tr>
   	<td colspan="2"><label id="z_id" style="color:#F00;display:none;">Enter Only 6 Digit</label></td>
	</tr>   
<tr>
	<th colspan="2" align="center"><input type="button" name="b_address" value="Next" onclick="display('p_del')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('p_del')"/>
    <input type="button" name="save" value="Save" onclick="Change_Address()" />
    
    </th>
</tr>

</table>

<table id="p_del" align="center" style="display:none; width:60%; vertical-align:top; text-align:left;" cellpadding="5" cellspacing="5">

<tr>
<td colspan="2">
<h2><u>Intersted</u></h2>
</td>
</tr>	
    <tr>
   	 <td>
            <label>Hobby :</label>
            </td>
 
        <td>
        	<input type="text"  name="hobby" id="hoby" value="<?php echo $data['s_hobby'] ?>"/>
        </td></tr>
         <tr>   
        <td>
        	<label>Sports :</label>
        </td>
        <td>
        	<input type="text"  name="sport" id="sport" value="<?php echo $data['s_sport'] ?>"/>
        </td>
        </tr>
         <tr>   
        <td >
        	<label>Subject :</label>
        </td>
        <td>
        	<input type="text"  name="subject" id="subject" value="<?php echo $data['s_subject'] ?>"/>
        </td>
        </tr>
        
 		<tr id="intmsg">
        
    <tr>
    	<th colspan="3" align="center"><input type="button" name="b_address" value="Next" onclick="display('archi')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('archi')"/>
    <input type="button" value="Save" onclick="change_interst()" /></th>
    </tr>
    
</table>

<table id="archi" align="center" style="display:none; width:60%; vertical-align:top; text-align:left;" cellpadding="5" cellspacing="5">

<tr>
<td colspan="2">
<h2><u>About You</u></h2>
</td>
</tr>	

    	<tr>
        <td ><label>Religion :</label></td>
        <td><input type="text" width="200" name="Relegions" id="Relegions" value="<?php echo $data['s_relegions'] ?>"/>
        </td>
        </tr>
       
        <tr>
        <td>
        	<label>language :</label>
            </td><td>
            <?php
			$d=explode(',',$data['s_language']);
			$no=count($d);
			//echo $no;
			if(@$d[1]=="gujarati"||@$d[2]=="gujarati"||@$d[3]=="gujarati")
			{
            echo '<input type="checkbox" name="gujarati" id="gujarati" value="gujrati" checked="checked"/>Gujrati';
			}
			else
			{
				echo '<input type="checkbox" name="gujarati" id="gujarati" value="gujrati"/>Gujrati';
			}
			//echo $d[0];
			//echo $d[1];
			//echo $d[2];
			//echo $d[3];
			if(@$d[1]=="Hindi"||@$d[2]=="Hindi"||@$d[3]=="Hindi")
			{
				
            echo '<input type="checkbox" name="Hindi" id="Hindi" value=",Hindi" checked="checked"/>Hindi';
			}
            else
			{
				echo '<input type="checkbox" name="Hindi" id="Hindi" value=",Hindi"/>Hindi';
			}
			//echo $d[2];
			if(@$d[1]=="English" || @$d[2]=="English" ||@$d[3]=="English" )
			{
            echo '<input type="checkbox" name="English" id="English" value=",English" checked="checked"/>English'; 
			}
            else
			{
				echo '<input type="checkbox" name="English" id="English" value=",English"/>English'; 
			}
			?>
        </td></tr>
        <tr>
        <td>
        
        	<label>Discription :</label>
        </td>
        <td>
        	<input type="text" width="200" name="discription" id="discription" value="<?php echo $data['s_description'] ?>"/>
        </td>
        </tr>
        <tr id="abtarchi">
        </tr>
<tr>
<td colspan="3" align="center">
<input type="button" name="b_address" value="Next" onclick="display('pro')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('pro')"/>
    <input type="button" value="Save" onclick="change_aboutyou()"/>
</td>
</tr>
    </table>
<table id="pro" align="center" style="display:none; width:60%; vertical-align:top; text-align:left;" cellpadding="5" cellspacing="5">
<tr>
<td colspan="2">
<h2><u>About School</u></h2>
</td>
</tr>
	<tr>
        <td><label>School Name :</label></td>
        <td><input type="text" width="200" name="schoolname" id="schoolname" value="<?php echo $data['s_schoolname'] ?>"/>
        </td>
        </tr>
        <tr>
        <td>
        	<label>School principal Name :</label>
        </td>
        <td>
        	<input type="text" width="200" name="sch_pri_name" id="sch_pri_name" value="<?php echo $data['s_principalname'] ?>"/>
        </td></tr>
        <tr>
        <td>
        	<label>Contact Number :</label>
        </td>
         <td>
        	<input type="text" width="200" name="contactno" id="contactno" value="<?php echo $data['s_contactnumber'] ?>" />
        </td>
       </tr>
       <tr id="archimsg">
       </tr>
        <tr>
        <td  colspan="3" align="center">
        <input type="button" name="submit" id="submit" value="Next" onclick="display('cpwd')"/>
         <input type="button" name="submit" id="submit" value="Skip" onclick="display('cpwd')"/>
         <input type="button" name="submit" id="submit" value="Save" onclick="change_school()"/>
        </td>
        </tr>
    
</table>

</td>
</tr>
</table>
</form>



</body>
</html>