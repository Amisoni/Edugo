<link href="../pagestyle.css" rel="stylesheet" type="text/css" />

<?php 
include('../config.php');
session_start();
$id=$_SESSION['id'];
$result=mysql_query("select * from sun s,profile p,student st,p_type pt  where s.p_id=".$id." and s.s_id=p.s_id and st.id=s.s_id and pt.id=p.t_id ORDER BY p.c_time desc" );// and p.p_id=s.p_id and s.s_id=p.s_id");
echo "<table align='left' width='80%' style='border-right:1px solid #cccccc' class='font'>";
while($data=mysql_fetch_array($result))
{
	
	echo "<tr><td valign='top' rowspan='2' align='center'><img src='../student/".$data['image']."' style='width:50px; height:50px;' /></td><td>".$data['f_name']." ".$data['l_name']."";//";
	echo " ".$data['text']." On ".$data['c_time']."<br /><br /></td></tr>";
	if($data['t_id']==1)
	{
		$r1=mysql_query("select * from profile_picture where p_id=".$data['n_id']);
		$d1=mysql_fetch_array($r1);	
		echo "<tr><td><table style='border:1px solid #999'><tr><td><img src='../student/".$d1['image']."' style='width:200px; height:200px;'/></td></tr></table></td></tr>";
	}
	else if($data['t_id']==2)
	{
		$r1=mysql_query("select * from result where rid=".$data['n_id']);
		$d1=mysql_fetch_array($r1);
	    echo "<tr><td><table style='border:1px solid #999; text-align:center;' cellspacing='0'><tr style='background-color:#cccccc;'><td>Total Marks</td><td>Get Marks</td><td>Attampt</td></tr><tr><td>".$d1[5]."</td><td>".$d1[6]."</td><td>".$d1[3]."</td></tr></table></td></tr>"; 	
	}
	echo "<tr><td colspan='2'><hr /></td></tr>";
	
}
echo "</table>";
?>
