<?php
if(isset($_POST['f_name']))
{	
	$to ="conatct@arctechnology.in";
   $subject = "Project Inquiry";
   $message = "Details:-".$pwd;
   $header = "From:10dit110@nirmauni.ac.in \r\n";
	$message="";
	$message=$message.$_POST['f_name'];
	$message=$message.$_POST['e_id'];
	$message=$message.$_POST['c_no'];
	$message=$message.$_POST['country'];
	$message=$message.$_POST['company'];
	$message=$message.$_POST['p_bdj'];
	$message=$message.$_POST['p_del'];
	$message=$message.$_POST['language'];
	$message=$message.$_POST['h_did'];
	echo "<script>alert('hi....')</script>";
	$retval = mail ($to,$subject,$message,$header);
   if( $retval == true )  
   {

      echo "Message sent successfully...";
//header('location:registration/first.php?msg=2');
   }
   else
   {
      echo "Message could not be sent...";
//header('location:registration/first.php?msg=3');
   }
}
?>
<?php
require 'file:///F|/ /arctechnology/menu/header.php';
?>
<div id="content_wrapper">
  <div id="content">
  <div id="content_left">
  <div class="content_left_section">
  <div class="content_header_01"></div>
  <div class="news_section" style="width:400px;">
  
  
  <table style="text-align:left;">
  <tr>
  <td colspan="1" height="50px" valign="middle"></td><td>
  <div class="content_header_01">
      <h1 style="text-align:center;">Address</h1></div>
 </td></tr>
 <tr>

 <td colspan="2" align="right">
 <img src="file:///F|/ /arctechnology/images/arcaddress.png" height="170" width="230"/>
 </td>
 </tr>
 
    <tr><td><img src="file:///F|/ /arctechnology/images/download (35).jpg" width="50px" height="50px" />
        </td>
      <td><p>4th Floor,Chanda Niwas,
        </p>
        <p>Nr. Karnawati Hospital,<br>
          Ellise Bridge Cross Road<br>
          Ahmedabad-380006<br>
          (Gujarat)<br>
        </p></td>
    </tr>
    <tr>
      <td><img src="file:///F|/ /arctechnology/images/images.jpg" width="50px" height="50px" /></td>
      <td> +91 794 0051811/ 15</td>
    </tr>
    <tr>
      <td><img src="file:///F|/ /arctechnology/images/icon_5.png" width="50px" height="50px" /></td>
      <td> +91 9428779595 / 9913344118</td>
    </tr>
    <tr>
      <td><img src="file:///F|/ /arctechnology/images/phone_email.jpg" width="50px" height="50px" /></td>
      <td> contact@arctechnology.in</td>
      </tr>
      </table>
  
  
  
 
  <table>
  <tr>
  <td colspan="1" height="90px" align="left"><img src="file:///F|/ /arctechnology/images/Regular_Contact_Person.png"/></td><td>

      <h1 align="center" style="text-align:center; width:80px; color:#4895c8" style="font-size:15px">Directors</h1></div>
  </td></tr>
    <tr><td>
    <img src="file:///F|/ /arctechnology/images/person-icon.png"/></td>
      <td><p><b>Managing Director:</b><p><br />
      <p>Vishal Patel</p>
      <p>vishal@arctechnology.in</p>
      <p>+91-9904444479</p><br />
        </p></td>
    </tr>
    <tr>
      <td><img src="file:///F|/ /arctechnology/images/person-icon.png" width="50px" height="50px" /></td>
      <td> <p><b>Business Director:</b><p><br />
      <p>Sapan Pandya</p>
      <p>sapan@arctechnology.in</p>
      <p>+91-8866077773</p><br />
        </p></td>
    </tr>
    
    <tr>
      <td><img src="file:///F|/ /arctechnology/images/person-icon.png" width="50px" height="50px" /></td>
      <td> <p><b>Director:</b><p><br />
      <p>Mayur Jain</p>
      <p>mayur@arctechnology.in</p>
      <p>+91-9428779595</p><br />
        </p></td>
      </tr>
      </table>
  
  
  
  
  
  <table>
  <tr>
  <td colspan="1" height="90px" align="left"></td><td>

      <h1 align="center" style="text-align:center;  color:#4895c8" style="font-size:15px">Quick Links</h1></div>
  </td></tr>
    <tr><td>
    <img src="file:///F|/ /arctechnology/images/aaarccc.png"/></td>
      <td><p>www.arctechnology.in</p></td>
    </tr>
    <tr>
      <td><img src="file:///F|/ /arctechnology/images/skype-icon.png" width="50px" height="50px" /></td>
      <td> <p>www.skype.com
        </p></td>
    </tr>
    
    <tr>
      <td><img src="file:///F|/ /arctechnology/images/95319137_facebook-icon.png" width="50px" height="50px" /></td>
      <td> <p>www.facebook.com
        </p></td>
      </tr>
       <tr>
      <td><img src="file:///F|/ /arctechnology/images/Yahoo Icon.jpg" width="50px" height="50px" /></td>
      <td> <p>www.yahoo.com
        </p></td>
      </tr>
       <tr>
      <td><img src="file:///F|/ /arctechnology/images/gmail.png" width="50px" height="50px" /></td>
      <td> <p>www.gmail.com
        </p></td>
      </tr>
      </table>
  
  
  
  
      
      </div>
      
    
      </div>
    
      </div>
    
    <!-- end of news section -->
    
         </div>
    
    <!-- end of content left -->
    
    <div class="content_header_01" style="font-size:30px;">
      
Contact Us</div>
    <br>
    <br>
     
    
    <p>Thank you for your interest in our services. To enable our Team to understand your requirements and provide a accurate quote, please fill the form below with the details for your project. If you have a ready RFP/RFQ document for your project, you can email us directly at- <br>
      <br>
    
      <br>
      <b>
You can also send your request by filling the form as below.     <br>
    <br>
      <div class="content_left_section">
    
      <form action="#" method="post" >
    
      <table>
    <p>
    <tr>
      <td><p>Full Name:
      <td><p>
          <input type="text" name="f_name" id="search_field" />
    </tr>
    <tr>
      <td><p>Email:
      <td><p>
          <input type="text" name="e_id" id="search_field" />
    </tr>
    <tr>
      <td><p>Contact No:</td>
      <td><p>
          <input type="text" name="c_no" id="search_field" /></td>
    </tr>
    <tr>
      <td><p>Country:</td>
      <td><p>
          <select name="country" name="country" id="country">
          <option value="">------Select Country------</option>
          <option value="India">India</option>
          <option value="U.S.A">U.S.A</option>
          <option value="England">England</option>
          <option value="Australia">Australia</option>
          <option value="Africa">Africa</option>
         
          </select></p><br /></td>
    </tr>
    <tr>
      <td><p>Company Name:
      <td><p>
          <input type="text" name="company" id="search_field" />
    </tr>
    <tr>
      <td><p>Website:
      <td><p>
          <input type="text" name="wabsite" id="search_field" />
    </tr>
    <tr>
      <td><p>Project Budget:</p></td>
      <td><p>
          <input type="text" name="p_bdj" id="search_field" /></p></td>
    </tr>
    <tr>
      <td><p>Project Detail:</td>
      <td><p>
          <textarea type="text" name="p_del" rows="5" cols="30"></textarea></p><br /></td>
    </tr>
    <tr>
    <td><p>Project Platform:</p></td>
    <td><p>
    <select name="language" name="lang" id="language">
          <option value="">------Select Platform-----</option>
          <option value="PHP">PHP</option>
          <option value="JAVA">JAVA</option>
          <option value="ASP.NET">ASP.NET</option>
          <option value="VB.NET">VB.NET</option>
          <option value="I-PHONE">I-phone</option>
         
          </select></p><br />
    </td>
    </tr>
    <tr>
      <td><p>How did you Hear about Us?:
      <td><p>
          <input type="text" name="h_did" id="search_field" />
    </tr>
    <tr>
      <td><p>Attach File:
      <td><p>
    <form action="file:///F|/ /arctechnology/upload_file.php" method="post"
enctype="multipart/form-data">
      <label for="file"></label>
      <input type="file" name="file" id="file">
      <br>
    </form>
      </tr>
    <tr>
    <td>
    </td>
    <td>
    </td></tr>
    <tr>
      <td ><br /><br /><br /><div class="rc_btn_02"><input type="submit" name="f_submit">Submit</label></div></td>
    </tr>
  </table>
</div>
<div class="cleaner"></div>
</div>
<div class="cleaner">&nbsp;</div>
</div>
<div class="cleaner_h20">&nbsp;</div>
</div>
<!-- end of content right -->

<div class="cleaner">&nbsp;</div>
</div>
<!-- end of content -->
</div>
<!-- end of content wrapper -->

<div id="footer_wrapper">
  <div id="footer"> Copyright © 2013 <a href="http://www.arctechnology.in">ARC Technology</a> </div>
  <!-- end of footer --> 
</div>
<!-- end of footer wrapper -->
</body>
</html>