<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sample Home Page</title>
<link rel="stylesheet" type="text/css" href="../css/popup.css" />
<script src="../css/popup1.js" type="text/javascript"></script>
<script>
function display(id)
{
	//
	document.getElementById('s_add').style.display="none";
	
	document.getElementById('s_det').style.display="none";
	
	document.getElementById('p_del').style.display="none";
	document.getElementById('s_det').style.display="none";
	document.getElementById('p_del').style.display="none";
	//document.getElementById('pro').style.display="none";
	document.getElementById('archi').style.display="none";
	//alert("hi..");
	document.getElementById('s_add1').style.backgroundColor="gray";
	document.getElementById('s_det1').style.backgroundColor="gray";
	document.getElementById('p_del1').style.backgroundColor="gray";
	//document.getElementById('pro1').style.backgroundColor="blue";
	document.getElementById('archi1').style.backgroundColor="gray";
	
	document.getElementById(id).style.display="table";
	var sid=id+"1";
	document.getElementById(sid).style.backgroundColor="white";
}
</script>

</head>
<body style="margin:0px">
<div style="margin-top:-8px;"> 
<form method="get" style="margin-bottom:0px">
<table width="100%" bgcolor="#3745F0">
<tr>
	<td width="60%" height="110px" style="vertical-align: middle; font-size: 50px; font-family: Miriam; color: #FFFFFF; font-weight: bold;padding-left:25px"><div style="margin-left:5px">EduGo&nbsp;<img src="../registration/image/tutor.jpg" height="33px" width="33px" ></div></td>
    <td style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif;font-size:13px;font-weight:bold">
    	<?php 
			session_start();
			if($_SESSION['id']!="")
			{
			$id=$_SESSION['id'];
			include("../config.php");
			$q="select * from tutor where ID=".$id;
			$res=mysql_query($q);
			$data=mysql_fetch_array($res);
			echo "<font color='#FFFFFF'>Welcome ".ucfirst($data['f_name'])." ".ucfirst($data['l_name'])."</font>";
			}
			else
			{
				header('location:registration/first.php');
			}
			
		?>
    </td>
   <td width="10%" style="vertical-align: middle; font-size: 20px; font-family: Miriam; color: #FFFFFF; font-weight: bold;"><a href="../logout.php?logout=1" style="color:#FFF"> Logout </a></td>
</tr>
</table>
</form>
</div>
<form action="t_insert.php" method="post" enctype="multipart/form-data">
<table width="70%" align="center" border="1px">

<tr>
<td>
<table width="100%" style="vertical-align:top; text-transform:capitalize; color:#CCC; cursor:pointer;" cellpadding="0" cellspacing="0">
<tr bgcolor="gray" style="text-align:center; cursor:p">
<td id="s_add1" bgcolor="#FFFFFF" width="100px" height="30px;"><label onclick="display('s_add')">Address</label></td>
<td id="s_det1"><label onclick="display('s_det')">Qualification</label></td>
<td id="p_del1"><label onclick="display('p_del')">Class Details</label></td>
<td id="archi1"><label onclick="display('archi')">Profile Picture</label></td>
</tr>
</table>
</td>
</tr>
<tr>
<td>

<table id="s_add" width="60%" align="center" style="vertical-align:top;" cellpadding="5" cellspacing="5" border="0">

<tr>
<td colspan="2"><h2><u>Address Detail</u></h2></td>
</tr>
<tr>
<td>Permanent Address</td>
<td><input type="text" name="tuaddress" id="tuaddress" rows="1" width="200px" />
</td></tr><tr><td>temporary Address</td>
<td><input type="text" name="tpaddress" id="tpaddress" width="200px"></textarea>
</td></tr>
<tr>
<td>City:</td>
<td>
<select name="city" id="city" value="Select city">
<option value="1">--Select city--</option>
<option value="Ahmedabad">Ahmedabad</option>
<option value="Baroda">Baroda</option>
<option value="Surat">Surat</option>
<option value="Bharuch">Bharuch</option>
</select>
</td>
</tr>
<tr>
<td>State:
</td>
<td>
<select name="state" id="state" value="Select state">
<option value="1">--Select State--</option>
<option value="Gujarat">Gujarat</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Madhyadesh">Madhyadesh</option>
<option value="Rajasthan">Rajasthan</option>
</select>
</td>
</tr>
<tr>
<td>Zip:
</td>
<td>
<input type="text" width="200" name="zip" />
</td>
</tr>
<tr>
<td>Neighbourhood:
</td>
<td>
<input type="text" width="200" name="neigh"/>
</td>
</tr>
<tr>
	<th colspan="2"><input type="button" name="b_address" value="Next" onclick="display('s_det')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('s_det')"/>
    </th>
</tr>
</table>

<table align="center" cellpadding="5" cellspacing="5" id="s_det" style="vertical-align:top; display:none;" border="0">

<tr>
<td colspan="2"><h2><u>Qualification:-</u></h2></td>
</tr>
<tr>
<td>Educational Detais:
</td>
<td>
<select name="qualifi" id="qualifi" value="Select qualification">
<option value="1">---Select education--</option>
<option value="mca">MCA</option>
<option>MBA</option>
<option>ME</option>
<option>MED</option>
</select>
</td>

</tr>
<tr>
<td>Upload Resume:</td>
<td>
<input type="file" name="f1" id="f1" />

</td>
</tr>
<tr>
<td width="100px" class="label">Date Of Joining:</td>
<td class="placeholder">
<select name="day">
<option value="--Day--">--Day--</option>
<?php
$i=1;
while($i<32)
{if($i<10){
echo "<option value=0$i>0".$i."</option>";}else
{echo "<option value=$i>$i</option>";}
$i++;
}
?>
</select>
<select style="" name="month">
<option value="--Month--">--Month--</option>
<option value=01>Jan</option>
<option value=02>Feb</option>
<option value=03>Mar</option>
<option value=04>Apr</option>
<option value=05>May</option>
<option value=06>Jun</option>
<option value=07>Jul</option>
<option value=08>Aug</option>
<option value=09>Sep</option>
<option value=10>Oct</option>
<option value=11>Nov</option>
<option value=12>Dec</option>
</select>
<select name="year">
<option value="--Year--">--Year--</option>
<?php
$i=1990;
while($i<2030)
{
echo "<option value=$i>$i</option>";
$i++;
}
?>
</select>
</td>
</tr>
<tr>
<td>Experience:</td>
<td><select name="exp" id="exp" value="Select exp">
<option value="1">---Select experience--</option>
<option value="1year">1year</option>
<option>2year</option>
<option>3year</option>
<option>4year</option>
<option>5year</option>
<option>6year</option>
<option>7year</option>
<option>8year</option>
<option>9year</option>
<option>10year</option>
</select>
</td>
</tr>
<tr>
	<th colspan="2"><input type="button" name="b_address" value="Next" onclick="display('p_del')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('p_del')"/></th>
</tr>
 </table>

<table id="p_del" align="center" style=" vertical-align:top; display:none;" cellpadding="5" cellspacing="5" border="0">
<tr>
<td colspan="2"><h2><u>Class Details</u></h2></td></tr>
<tr>
<td>No of Sessions:</td>
<td><select name="session" id="session" value="Select session">
<option value="1">---Select sessions--</option>
<option value="1">1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
</select>
</td>
</tr>
<tr>
<td>No of Students:</td>
<td>
<input type="text" width="200" name="stud" />
</td>
</tr>
<tr>
<td>Timing:</td>
<td>
  <input type="text" name="starttime" size="6">
  <select name="ampm" id="ampm" value="Select ampm" size="1">
    <option value="AM">AM</option>
    <option value="PM">PM</option>
  </select> To
    <input type="text" name="endtime" size="6">
    <select name="ampm1" id="ampm2" value="Select ampm">
      <option value="AM">AM</option>
      <option value="PM">PM</option>
    </select>
</td>
</tr>
<tr>
<td>Expert Subject:</td>
<td>
<select name="expert" id="expert" value="Select expert">
<option value="1">---Select subject--</option>
<option value="1">maths</option>
<option value="english">english</option>
<option value="scince">science</option>
<option value="computer">computer</option>
</select>
</td>
</tr>

<tr>
<td>Advanced Subject:</td>
<td>
<input type="text" name="c" width="200px" />
</td>
</tr>

<tr>
<td>
	
    
    </td>
  </tr>
  
  <tr>
    	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('archi')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('archi')"/></th>
    </tr>
</table>
 
	<table id="archi" align="center" style=" vertical-align:top; display:none;" cellpadding="5" cellspacing="5" border="0">

	<tr>
    	<td align="center">
        <img src="<?php $data['image']; ?>" width="150" height="150" />
        
        </td>
    </tr>
    <tr align="center">
    	<td><input type="file" name="sh_image" id="sh_image" /></td>
    </tr>
    <tr>
    	<th></th>
    </tr>
	<tr>
    	<th><input type="submit" value="Save & continue" name="saveprofile" /></th>
    </tr>
    </table>
</td>
</tr>
</table>
</form>
</body>
</html>
