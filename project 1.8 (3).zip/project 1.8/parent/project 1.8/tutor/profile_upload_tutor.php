<?php
include("../config.php");
session_start();
$id=$_SESSION['id'];
if(isset($_POST['saveprofile']))
{
	if ($_FILES['sh_image']['type'] != 'image/jpeg')
			{
				echo "file not supported";
			}
			else
			{
			move_uploaded_file($_FILES['sh_image']['tmp_name'], "images/".$_FILES['sh_image']['name']);
			$filepath = "images/".$_FILES['sh_image']['name']; 
			
			if($_SESSION['id']!="")
			{
			$id=$_SESSION['id'];
			$q="select * from tutor where ID=".$id;
			$res=mysql_query($q);
			$data=mysql_fetch_array($res);
			
			}
			mysql_query("update tutor set image='$filepath' where id=$id" ) ;

			//mysql_close($con);
			//header('Location:header4.php');
			
	}
}

//echo "select * from s_info where s_id=".$id;
$result1=mysql_query("select * from tutor where id=".$id);
$data1=mysql_fetch_array($result1);
$result=mysql_query("select * from t_info where t_id=".$id);
$data=mysql_fetch_array($result);
//echo $data[0];



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sample Home Page</title>
<link rel="stylesheet" type="text/css" href="../css/popup.css" />
<script src="../css/popup1.js" type="text/javascript"></script>
<script>
function set_city()
{
	//alert("hi..");
	var ddl = document.getElementById('city');
	var opts = ddl.options.length;
	for (var i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['t_city']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	ddl = document.getElementById('state');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['t_state']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	ddl = document.getElementById('expert');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['t_expsub']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	
	<?php
  	$d=explode("-",$data1['birth_date']);
  	?>
	ddl = document.getElementById('day');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[2]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	
	ddl = document.getElementById('month');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
		
    if (ddl.options[i].value == '<?php echo $d[1]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	//alert("hi..");
	}
	ddl = document.getElementById('year');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[0]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	
	ddl = document.getElementById('qualifi');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['t_edu']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	
	ddl = document.getElementById('exp');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['t_exp']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	
	//alert("ankh")
	<?php
  	$d=explode("-",$data['t_date']);
  	?>
	ddl = document.getElementById('day5');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[2]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	ddl = document.getElementById('month5');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[1]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	ddl = document.getElementById('year5');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[0]; ?>'){
        ddl.options[i].selected = true;
        break;
	}
	}
	ddl = document.getElementById('session');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['t_ses']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
}
function display(id)
{
	document.getElementById('s_add').style.display="none";
	document.getElementById('cpwd').style.display="none";
	document.getElementById('s_det').style.display="none";
	document.getElementById('acco').style.display="none";
	document.getElementById('p_del').style.display="none";
	document.getElementById('s_det').style.display="none";
	document.getElementById('p_del').style.display="none";
	//document.getElementById('pro').style.display="none";
	document.getElementById('archi').style.display="none";
	//alert("hi..");
	document.getElementById('s_add1').style.backgroundColor="gray";
	document.getElementById('cpwd1').style.backgroundColor="gray";
	document.getElementById('acco1').style.backgroundColor="gray";

	document.getElementById('s_det1').style.backgroundColor="gray";
	document.getElementById('p_del1').style.backgroundColor="gray";
	//document.getElementById('pro1').style.backgroundColor="blue";
	document.getElementById('archi1').style.backgroundColor="gray";
	
	document.getElementById(id).style.display="table";
	var sid=id+"1";
	document.getElementById(sid).style.backgroundColor="white";
}
 
function Change_Password()
{
	
var old=document.forms["edit"]["opwd"].value;
var pwd=document.forms["edit"]["npwd"].value;
var cpwd=document.forms["edit"]["rpwd"].value;

	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("pmsg").innerHTML=xmlhttp.responseText;
    }
  	}
	 xmlhttp.open("GET","edit_php.php?old="+old+"&&new="+pwd+"&&cnew="+cpwd,true); 
	 xmlhttp.send();
	
}
function change_address()
{
	document.getElementById("z_id").style.display="none"; 
	var numbers = /^[0-9]+$/; 
	var tadd=document.forms["edit"]["tuaddress"].value;
	var padd=document.forms["edit"]["tpaddress"].value;
	var a=document.getElementById("city");	
	var city=a.options[a.selectedIndex].value;
	a=document.getElementById("state");	
	var state=a.options[a.selectedIndex].value;
	var zip=document.forms["edit"]["zip"].value;
	var neigh=document.forms["edit"]["neigh"].value;
	 if((!numbers.test(zip))|| zip.length!=6)
      { 
	  document.getElementById("z_id").style.display="block"; 
	  document.getElementById("msgadd").innerHTML=""; 
      
      }  
	 else
	 {
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("msgadd").innerHTML=xmlhttp.responseText;
    }
  	}
  //alert("edit_php.php?tadd="+tadd+"&&padd="+padd+"&&city="+city+"&&state="+state+"&&zip="+zip+"&&neigh="+neigh);
	 xmlhttp.open("GET","edit_php.php?tadd="+tadd+"&&padd="+padd+"&&city="+city+"&&state="+state+"&&zip="+zip+"&&neigh="+neigh,true); 
	 xmlhttp.send();
	 }
}
function change_qualification()
{	
	
	var a=document.getElementById("qualifi");	
	var qual=a.options[a.selectedIndex].value;
	//var adv=document.forms["edit"]["c"].value;
	a=document.getElementById("exp");	
	var expe=a.options[a.selectedIndex].value;
	
	a=document.getElementById("day5");	
	var day=a.options[a.selectedIndex].value;
	//alert("hi..");
	a=document.getElementById("month5");	
	var month=a.options[a.selectedIndex].value;
	a=document.getElementById("year5");	
	var year=a.options[a.selectedIndex].value;
	var date=year+month+day;
//alert(date);	
	
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("expmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  //alert("edit_php.php?tadd="+tadd+"&&padd="+padd+"&&city="+city+"&&state="+state+"&&zip="+zip+"&&neigh="+neigh);
	 xmlhttp.open("GET","edit_php.php?qual="+qual+"&&expe="+expe+"&&date="+date,true); 
	 xmlhttp.send();
	
}
function change_class()
{	
	
	var a=document.getElementById("session");	

	var session=a.options[a.selectedIndex].value;
	
	var stdu=document.forms["edit"]["stud"].value;
	a=document.getElementById("ampm");	
	//alert("hi...");
	var s_am=a.options[a.selectedIndex].value;
	a=document.getElementById("ampm1");	
	var e_am=a.options[a.selectedIndex].value;
	
	var s_time=(document.forms["edit"]["starttime"].value)+s_am;
	var e_time=(document.forms["edit"]["endtime"].value)+e_am;
	a=document.getElementById("expert");
	var subj=a.options[a.selectedIndex].value;
	var adv=document.forms["edit"]["c"].value;
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("clsmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  //alert("edit_php.php?tadd="+tadd+"&&padd="+padd+"&&city="+city+"&&state="+state+"&&zip="+zip+"&&neigh="+neigh);
	 //alert("edit_php.php?session="+session+"&&stud="+stdu+"&&stime="+s_time+"&&etime="+e_time+"&&subj="+subj+"&&adv="+adv);
	 xmlhttp.open("GET","edit_php.php?session="+session+"&&stud="+stdu+"&&stime="+s_time+"&&etime="+e_time+"&&subj="+subj+"&&adv="+adv,true); 
	 xmlhttp.send();
	
}
function get_radio_value()
{
            var inputs = document.getElementsByName("sex");
            for (var i = 0; i < inputs.length; i++) {
              if (inputs[i].checked) {
                return inputs[i].value;
              }
      }
}
function change_account()
{	
	document.getElementById("m_id").style.display="none"; 
	var f_name=document.forms["edit"]["f_name"].value;
	var l_name=document.forms["edit"]["l_name"].value;
	var sch_name=document.forms["edit"]["institute"].value;

	var e_id=document.forms["edit"]["email"].value;
	
	var m_no=document.forms["edit"]["number"].value;
	
	var p_no=document.forms["edit"]["pnumber2"].value;
	a=document.getElementById("day");	
	var day1=a.options[a.selectedIndex].value;
	a=document.getElementById("month");	
	var month1=a.options[a.selectedIndex].value;
	a=document.getElementById("year");	
	var year1=a.options[a.selectedIndex].value;
//	alert(year1);
	var date1=year1+month1+day1;
	var chk_arr =  document.getElementsByName("cb[]");
	var chklength = chk_arr.length;             
	var s="";
	for(k=0;k< chklength;k++)
	{
    if(chk_arr[k].checked ==  true)
	{
		s=s+chk_arr[k].value;
		//alert("hi...");
	}
	} 
	//alert(s);
	var subj=document.forms["edit"]["sub"].value;
	var numbers = /^[0-9]+$/; 
 if((!numbers.test(m_no))|| m_no.length!=10)
      { 
	  document.getElementById("m_id").style.display="block"; 
	  document.getElementById("account").innerHTML=""; 
      }  
	 else
	 {

    //alert("hi..");
 var id = get_radio_value();
	//alert(id);
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
 	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("account").innerHTML=xmlhttp.responseText;
    }
  	}
	
  
	 xmlhttp.open("GET","edit_php.php?f_name="+f_name+"&&l_name="+l_name+"&&sch_name="+sch_name+"&&e_id="+e_id+"&&m_no="+m_no+"&&p_no="+p_no+"&&subj="+subj+"&&sex="+id+"&&date1="+date1+"&&s="+s,true); 
	 xmlhttp.send();
	 }
}

</script>

</head>
<body style="margin:0px" onload="set_city();">
<form action="" name="edit" method="post" enctype="multipart/form-data">
<table width="70%" align="center" border="1px">

<tr>
<td>
<table width="100%" style="vertical-align:top; text-transform:capitalize; color:#CCC; cursor:pointer;" cellpadding="0" cellspacing="0">
<tr bgcolor="gray" style="text-align:center; cursor:pointer;">
<td id="s_add1" width="100px" height="30px;"><label onclick="display('s_add')">Address</label></td>
<td id="acco1" width="100px" height="30px;"  ><label onclick="display('acco')">Account</label></td>
<td id="s_det1" width="100px" height="30px;"><label onclick="display('s_det')">Qualification</label></td>
<td id="p_del1" width="100px" height="30px;"><label onclick="display('p_del')">Class Details</label></td>
<td id="archi1" width="100px" height="30px; bgcolor="#FFFFFF" ><label onclick="display('archi')" >Profile Picture</label></td>
<td id="cpwd1" width="100px" height="30px;"><label onclick="display('cpwd')">Password</label></td>
</tr>
</table>
</td>
</tr>
<tr>
<td>
<table style="display:none;" border="0" cellpadding="4" cellspacing="2" width="420px" id="acco" align="center">
<tr>
<td colspan="3"><h2><u>Account Detail</u></h2></td></tr>
<tr>
	<td width="116" class="label">First Name:</td>
	<td width="10" class="label"><label id="name" style="color:#F00; display:none" class="label">*</label></td>
    	<td class="label"><input type="text" name="f_name" maxlength="20" placeholder="First Name" style="width:85px; height:18px; font-size:15px" onclick="validation('f_n')" value="<?php echo $data1['f_name']; ?>" readonly="readonly" /> Last Name <input type="text" name="l_name" maxlength="20" placeholder="Last Name" style="width:85px; height:18px; font-size:15px" onclick="validation('l_n')" readonly="readonly" value="<?php echo $data1['l_name']; ?> " />
	</td>
</tr>

<tr>
	<td width="116" class="label">Institute Name:</td>
	<td width="10"><label id="sname" style="color:#F00; display:none" class="label">*</label>
    </td>
	<td><input type="text" name="institute" maxlength="50" placeholder="Enter Name Of Institute" class="placeholder" onclick="validation('s_n')" width="255" value="<?php echo $data1['u_name']; ?>"/>
	</td>
</tr>

<tr>
	<td width="116" class="label">Email:</td>
	<td width="10"><label id="email" style="color:#F00; display:none" class="label">*</label>
    </td>
	<td><input type="text" name="email" placeholder="Enter Email Address" class="placeholder" onclick="validation('e_i')" readonly="readonly" width="255" value="<?php echo $data1['email']; ?>"/>
	</td>
</tr>

<tr>
	<td width="116" class="label">Standard:</td>
	<td width="10" class="label"><label id="std" style="color:#F00; display:none" class="label">*</label>
    </td>
	<td style="font-size:15px;color:#000">
	 <?php
	include("../config.php");
	$r1=mysql_query("select * from class");
    $i=0;
	while($d1=mysql_fetch_array($r1))
	{
		
		if($i==4)
		{
			echo "<br/>";
		}
		$d=explode(',',$data1['std']);
		$no=count($d);
		$count=0;
		for($p=0;$p<$no;$p++)
		{
			if($d1[0]==$d[$p])
			{
				$count++;
			}
		}
		if($count>0)
		{
			echo "<input type='checkbox' name='cb[]' value=',".$d1[0]."' checked='checked'/>".ucfirst($d1[1]);
		}
		else
		{
		echo "<input type='checkbox' name='cb[]' value=',".$d1[0]."'/>".ucfirst($d1[1]);
		}
		$i++;
	}
	?>
	</td>
</tr>

<tr>
	<td width="116" class="label">Subject Name:</td>
	<td width="10"><label id="subb" style="color:#F00; display:none" class="label">*</label>
    </td>
	<td><input id="searchField" name="sub" type="text" maxlength="100" placeholder="Enter Subject Name" class="placeholder" onclick="validation('sub_i')" style="width:255px;" value="<?php echo $data1['sub']; ?>"/></td>
</tr>



<tr>
	<td width="116" class="label">Mobile:</td>
	<td width="10"><label id="contact" style="color:#F00; display:none" class="label">*</label>		</td>
	<td><input type="text" name="number" maxlength="10" placeholder="Enter Contact Number" class="placeholder"  onclick="validation('m_n')" value="<?php echo $data1['contact']; ?>"/>
	</td>
</tr>

<tr>
  <td width="116" class="label">Phone No:</td>
  <td width="10"><label id="lan" style="color:#F00; display:none" class="label" >*</label></td>
  <td><input type="text" name="pnumber2" class="placeholder" onclick="validation('p_n')"   maxlength="12" value="<?php echo $data1['phone']; ?>"/>
  </td>
</tr>

<tr>	
  <td width="116" class="label">Birth Date:</td>
  <td width="10"><label id="bd" style="color:#F00; display:none" class="label">*</label></td>
  <td style="color:#000; font-size:15px">
  <?php
  $d=explode("-",$data1['birth_date']);
  ?>
  <select name="day" id="day">
  <option value="day">Day</option>
    
    <?php
$i=1;
while($i<32)
{if($i<10){
echo "<option value=0$i>0".$i."</option>";}else
{echo "<option value=$i>$i</option>";}
$i++;
}
?>
  </select>
<select name="month" id="month">
     <option value=00>Month</option>
      <option value=01>Jan</option>
      <option value=02>Feb</option>
      <option value=03>Mar</option>
      <option value=04>Apr</option>
      <option value=05>May</option>
      <option value=06>Jun</option>
      <option value=07>Jul</option>
      <option value=08>Aug</option>
      <option value=09>Sep</option>
      <option value=10>Oct</option>
      <option value=11>Nov</option>
      <option value=12>Dec</option>
    </select>
<select name="year" id="year">
<option value="0000">Year</option>  <?php
$i=1900;

while($i<2031)
{
echo "<option value=$i>$i</option>";
$i++;
}
?>
</select></td>
</tr>

<tr>
	<td width="116" class="label">Gender:</td>
	<td></td>
	<td style="color:#000; font-size:15px">
	 <?php
	if($data1['sex']=="Male")
	{
		echo '<input name="sex" id="sex" type="radio" value="Male" checked="checked"/>Male';
	echo '<input type="radio" name="sex" id="sex" value="Female" />Female';
	}
	else
	{
		echo '<input name="sex" type="radio" id="sex" value="Male" />Male';
	echo '<input type="radio" name="sex" value="Female" id="sex" checked="checked"/>Female';
	}
	?>
	</td>
</tr>
<tr id="account">
</tr>
<tr>
   	<td colspan="2"><label id="m_id" style="color:#F00;display:none;">Enter Only 10 Digit</label></td>
	</tr>   
<tr>
<td colspan="3">
<input type="button" value="Next" onclick="display('s_det')"/>
    <input type="button" value="Skip" onclick="display('s_det')"/>
    <input type="button" value="Save" onclick="change_account()"/>
</td>
</tr>
</table>
<table id="cpwd" width="60%" align="center" style="vertical-align:top; text-align:left; display:none;" cellpadding="5" cellspacing="5">
<tr>
<td colspan="3">
<h2><u>Change Password</u></h2>
</td>
</tr>
<tr><td>Old Password</td><td>:</td><td><input type="text" width="200px" name="opwd" /></td></tr>
<tr><td>New Password</td><td>:</td><td><input type="text" width="200px" name="npwd" /></td></tr>
<tr><td>Confirm Password</td><td>:</td><td><input type="text" width="200px" name="rpwd" /></td></tr>
<tr id="pmsg"></tr>
<tr><td colspan="3"><input type="button" name="password" id="password" value="Change Password" onclick="Change_Password()" /></td></tr>
</table>

<table id="s_add" width="60%" align="center" style="vertical-align:top;display:none;" cellpadding="5" cellspacing="5">

<tr>
<td><h2><u>Address</u></h2></td>
</tr>
<tr>
<td>permanent Address</td>
<td><input type="text" name="tuaddress" id="tuaddress" rows="1" width="200px" value="<?php echo $data['t_p_add'] ?>"/>
</td></tr><tr><td>temporary Address</td>
<td><input type="text" name="tpaddress" id="tpaddress" width="200px" value="<?php echo $data['t_p_add'] ?>">
</td></tr>
<tr>
<td>city:</td>
<td>
<select name="city" id="city" value="Select city" style="width:155px">
<option value="1">Select city</option>

<option value="Ahmedabad">Ahmedabad</option>
<option value="Baroda">Baroda</option>
<option value="Surat">Surat</option>
<option value="Bharuch">Bharuch</option>
</select>
</td>
</tr>
<tr>
<td>State:
</td>
<td>
<select name="state" id="state" value="Select state" style="width:155px">
<option value="ahmd">Gujarat</option>
<option>Maharashtra</option>
<option>Madhyadesh</option>
<option>Rajasthan</option>
</select>
</td>
</tr>
<tr>
<td>Zip:
</td>
<td>
<input type="text" width="200" name="zip" value="<?php echo $data['t_zip'] ?>"/>
</td>
</tr>
<tr>
<td>Neighbourhood:
</td>
<td>
<input type="text" width="200" name="neigh" value="<?php echo $data['t_nb'] ?>"/>
</td>
</tr>
<tr id="msgadd">
</tr>
<tr>
   	<td colspan="2"><label id="z_id" style="color:#F00;display:none;">Enter Only 6 Digits in Zip Code..</label></td>
	</tr>   
<tr>
	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('s_det')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('s_det')"/>
    <input type="button" value="Save" onclick="change_address()"/>
    </th>
</tr>
</table>

<table align="center" cellpadding="5" cellspacing="5" id="s_det" style="vertical-align:top; display:none;" width="60%">

<tr>
<td><h2><u>Qualification:-</u></h2></td>
</tr>
<tr>
<td>Educational Detais:
</td>
<td>
<select name="qualifi" id="qualifi" value="Select qualification" style="width:183px">
<option>Select</option>
<option value="mca">MCA</option>
<option value="MBA">MBA</option>
<option value="ME">ME</option>
<option value="MED">MED</option>
</select>
</td>

</tr>
<tr>
<td>Upload Resume:</td>
<td>
<input type="file" name="f1" id="f1" value=<?php echo $data['t_resume'] ?>/>

</td>
</tr>
<tr>
<td width="100px" class="label">Date Of Joining:</td>
<td class="placeholder">
<select name="day5" id="day5">
<option value="Day">Day</option>
<?php
$i=1;

while($i<32)
{if($i<10){
echo "<option value=0$i>0".$i."</option>";}else
{echo "<option value=$i>$i</option>";}
$i++;
}
?>
</select>
<select name="month5" id="month5">
<option value="Month">Month</option>
<option value=01>Jan</option>
<option value=02>Feb</option>
<option value=03>Mar</option>
<option value=04>Apr</option>
<option value=05>May</option>
<option value=06>Jun</option>
<option value=07>Jul</option>
<option value=08>Aug</option>
<option value=09>Sep</option>
<option value=10>Oct</option>
<option value=11>Nov</option>
<option value=12>Dec</option>
</select>
<select name="year5" id="year5">
<option value="Year">Year</option>
<?php
$i=1990;
while($i<2030)
{
echo "<option value=$i>$i</option>";
$i++;
}
?>
</select>
</td>
</tr>
<tr>
<td>Experience:</td>
<td><select name="exp" id="exp" value="Select exp" style="width:183px">
<option value="1">1year</option>
<option value="2">2year</option>
<option value="3">3year</option>
<option value="4">4year</option>
<option value="5">5year</option>
<option value="6">6year</option>
<option value="7">7year</option>
<option value="8">8year</option>
<option value="9">9year</option>
<option value="10">10year</option>
</select>
</td>
</tr>
<tr id="expmsg">
</tr>
<tr>
	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('p_del')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('p_del')"/>
    <input type="button" value="Save" onclick=" change_qualification()"/>
    </th>
</tr>
 </table>

<!--<table id="p_del" align="center" style="width:100%; vertical-align:top; display:none;" cellpadding="5" cellspacing="5">
<tr>
<td colspan="2"><h2><u>Class Details</u></h2></td></tr>
<tr>
<td>No of Sessions:</td>
<td><select name="session" id="session" value="Select session">
<option value="1">---Select sessions--</option>
<option value="1">1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
</select>
</td>
</tr>
<tr>
<td>No of Students:</td>
<td>
<input type="text" width="200" name="stud" />
</td>
</tr>
<tr>
<td>Timings:</td>
<td><p>From :
  <input type="text" width="95" name="starttime">
  <select name="ampm" id="ampm" value="Select ampm" size="1">
    <option value="AM">AM</option>
    <option value="PM">PM</option>
  </select>
</p>
  <p>To &nbsp;&nbsp;&nbsp;&nbsp;:    
    <input type="text" width="95" name="endtime">
    <select name="ampm1" id="ampm2" value="Select ampm">
      <option value="AM">AM</option>
      <option value="PM">PM</option>
    </select>
  </p></td>
</tr>
<tr>
<td>Expert Subject:</td>
<td>
<select name="expert" id="expert" value="Select expert">
<option value="1">---Select subject--</option>
<option value="1">maths</option>
<option>english</option>
<option>science</option>
<option>computer</option>
</select>
</td>
</tr>

<tr>
<td>Advanced Subject:</td>
<td>
<input type="text" name="c" width="200px" />
</td>
</tr>

<tr>
<td>
	
    
    </td>
  </tr>
  <tr>
    	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('archi')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('archi')"/></th>
    </tr>
</table>
--> 
<table align="center" cellpadding="5" cellspacing="5" id="p_del" style="display:none;vertical-align:top" width="60%">
<tr>
<td colspan="2"><h2><u>Class Details</u></h2></td></tr>
<tr>
<td>No of Sessions:</td>
<td><select name="session" id="session" value="Select session" style="width:168px">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
</select>
</td>
</tr>
<tr>
<td>No of Students:</td>
<td>
<input type="text" name="stud" size="22px" value="<?php echo $data['t_noofstud'] ?>"/>
</td>
</tr>
<tr>
<td>Timings:</td>
<td><table><tr><td><label>From :</label></td><td>
<?php
$s=$data['t_s_time'];
$e=$data['t_e_time'];
$s1=substr($s,0,2);
$e1=substr($e,0,2);
$d=explode('A',$data['t_s_time']);
$e=explode('P',$data['t_e_time']);
?>
<input type="text" name="starttime" size="5px" value="<?php echo $s1; ?>"></td><td>
<select name="ampm" id="ampm" value="Select ampm">
<option value="<?php echo $d; ?>">AM</option>
<option value=" AM">AM</option>
<option value=" PM">PM</option>
</select></td></tr><tr><td>
<label>To</label></td><td>
<input type="text" name="endtime"  size="5px" value="<?php echo $e1; ?>"></td><td>
<select name="ampm1" id="ampm1" value="Select ampm">
<option value="<?php echo $e; ?>">AM</option>
<option value=" AM">AM</option>
<option value=" PM">PM</option>
</select></td></tr></table>
</td>
</tr>
<tr>
<td>Expert Subject:</td>
<td>
<select name="expert" id="expert" value="Select expert" style="width:168px">
<option value="Maths">maths</option>
<option value="english">english</option>
<option value="science">science</option>
<option value="computer">computer</option>
</select>
</td>
</tr>

<tr>
<td>Advanced Subject:</td>
<td>
<input type="text" name="c" size="22px" value="<?php echo $data['t_advancesub'] ?>"/>
</td>
</tr>

<tr>
<td>
	
    
    </td>
  </tr>
  <tr id="clsmsg">
  </tr>
<tr>
	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('p_del')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('p_del')"/>
    <input type="button" value="Save" onclick="change_class()"/>
    </th>
</tr>


</table>

	<table id="archi" align="center" style=" width:100%; vertical-align:top;" cellpadding="5" cellspacing="5">

	<tr>
    	<td align="center">
        <img src='<?php echo $data1['image'] ?>' width="150" height="150" />
        
        </td>
    </tr>
    <tr align="center">
    	<td><input type="file" name="sh_image" id="sh_image"/></td>
    </tr>
    <tr>
    	<th></th>
    </tr>
	<tr>
    	<th><input type="submit" value="Save & continue" name="saveprofile" /></th>
    </tr>
    </table>
</td>
</tr>
</table>
</form>
</body>
</html>
