<?php 
include("../config.php");
	session_start();
	$id=$_SESSION['id'];
	move_uploaded_file($_FILES['sh_image']['tmp_name'], "images/".$_FILES['sh_image']['name']);
	$filepath = "images/".$_FILES['sh_image']['name']; 
	mysql_query("update tutor set image='$filepath' where id=$id" ) ;
			
$q="INSERT INTO t_info (t_p_add,t_city,t_state,t_zip,t_nb,t_edu,t_resume,t_date,t_exp,t_ses,t_noofstud,t_s_time,t_e_time,t_expsub,t_advancesub)
value('$_POST[tuaddress]','$_POST[tpaddress]','$_POST[city]','$_POST[state]','$_POST[zip]','$_POST[neigh]','$_POST[qualifi]','$_POST[f1]','".$_POST['year'].$_POST['month'].$_POST['day']."','$_POST[session]','$_POST[stud]','".$_POST['starttime'].$_POST['ampm']."','".$_POST['endtime'].$_POST['ampm1']."','$_POST[expert]','$_POST[c]')";
//echo $q;
mysql_query($q);
header("location:header4.php");
//mysql_close();
?>
