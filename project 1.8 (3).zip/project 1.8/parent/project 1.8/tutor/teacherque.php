<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script language="javascript" src="calendar/calendar.js"></script>
<!--<link href="calendar/calendar.css" rel="stylesheet" type="text/css">
--></head>

<body >

<form id="form1" method="post" name="form1" action="que1.php" >

<table width="50%" bgcolor="" align="center"><tr><td>
<font size="+2"> Class  </font></td><td> : </td><td><select name="class" style="height:30px; width:146px;font-size:18px">
<option>Class5</option>
<option>Class6</option>
<option>Class7</option>
<option>Class8</option>
<option>Class9</option>
</select></td></tr>
<tr><td><font size="+2">Subject</font></td><td> : </td><td><select name="sub" style="height:30px; font-size:18px">
<option value="english" >english</option>
<option value="mathematics">Mathematics</option>
<option value="science">science</option>
<option value="social">Social Science</option>
<option value="computer">computer</option>
</select></td></tr><tr><td>
<font size="+2">Select Chapter </font></td><td> : </td><td>
<input type="checkbox" name="chap1" value="chap1" /><font size="+2">chapter1</font><br />
<input type="checkbox" name="chap2" value="chap2" /><font size="+2">chapter2</font><br />
<input type="checkbox" name="chap3" value="chap3" /><font size="+2">chapter3</font><br />
<input type="checkbox" name="chap4" value="chap4" /><font size="+2">chapter4</font></td></tr>
<tr><td colspan="2" align="center"><input type="submit" name="ok" value="Show" style="font-size:18px;"/> 
      </select>
      <input type="reset" name="reset" value="Reset" style="font-size:18px;margin-left:50px"/></td></tr>
</font></table>
</form>

</body>
</html>
