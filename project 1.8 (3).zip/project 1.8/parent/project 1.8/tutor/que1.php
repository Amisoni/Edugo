<form method='post'  name='frm2' action='que1.php'>
<?php
//echo "<form method='post' action='que.php'>";
if(isset($_POST['ok']))
{
	include("../config.php");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
  
$q=mysql_query("select * from chap2 where sub='".$_POST['sub']."' and class='".$_POST['class']."' and (cha='".$_POST['chap1']."' or cha='".$_POST['chap2']."' or cha='".$_POST['chap4']."')");
$class=$_POST['class'];

$s=1;
$c="cb";
$m=1;
$checkbox=1;
//$a=$_POST[$d[4]];

echo "<input type='hidden' name='class' value='$_POST[class]' />";
echo "<input type='hidden' name='sub' value='$_POST[sub]' />";
echo "<input type='hidden' name='chap1' value='$_POST[chap1]' />";
echo "<input type='hidden' name='chap2' value='$_POST[chap2]' />";
echo "<table style='margin-left:0px'> <tr><td colspan=7 align='right'>marks<br/>(change)</td></tr>";
while($d=mysql_fetch_row($q))
{

echo "<tr><td><input type='checkbox' name='cnt[]' value='$d[0]'>$d[0]</td><td>".$d[4]."</td><td><input type='radio' name=".$s." >".$d[5]."</td><td><input type='radio' name=".$s.">".$d[6]."</td><td><input type='radio' name=".$s.">".$d[7]."</td><td><input type='radio' name=".$s.">".$d[8]."</td><td><input type='text' name='qnt[]' size=1 value=".$d[9]."  ></td></tr><tr><td></td></tr>";

 //$p=$p+1;
 $c=$c+$checkbox;
 $checkbox++;
 //$s=$s+$p;
}
echo "</table>";

echo "<input type='submit' name='generate' value='Generate' style='font-size:18px;margin-left:250px'>";
//mysql_close($con);
}
//echo "</form>";
?>
</form>


<form method='post' name frm3 action='que1.php'>
<?php
//echo "<form method='post' name='gn' action='que.php'>";
if(isset($_POST['generate']))
{
$foo = $_POST['cnt'];
$qnt=$_POST['qnt'];
$sum=0;
$l=$_POST['class'];
$s=$_POST['sub'];
$c1=$_POST['chap1'];
$c2=$_POST['chap2'];


if (count($foo) > 0 && count($qnt) > 0) {
// loop through the array

//echo $qnt[3]."<br>";
for ($i=0;$i<count($foo) && $i<count($qnt);$i++) {

include("../config.php");
if (!$con)
  { 
  die('Could not connect: ' . mysql_error());
  }
$q=mysql_query("select * from chap2 where sub='".$s."' and class='".$l."' and (cha='".$c1."' or cha='".$c2."')");
$i=0;
$p=0;
while($d=mysql_fetch_row($q))
{
	if($d[0]==$foo[$i])
	{
		echo $foo[$i]." ".$d[4]." <input type='radio' name=".$s." >".$d[5]." <input type='radio' name=".$s.">".$d[6]."<input type='radio' name=".$s."> ".$d[7]."<input type='radio' name=".$s."> ".$d[8]." ".$qnt[$p]."<br>";
		mysql_query("INSERT INTO tutorque (tqid,que,ans1,ans2,ans3,ans4,marks)VALUES 			('$foo[$i]','$d[4]','$d[5]','$d[6]','$d[7]','$d[8]','$qnt[$p]')");
		$i++;
		$s=$s+$p;
	}
	
	$p++;
	
//$j++;
}
//echo "</form>";
}
@mysql_close($con);
}
}
?>
</form>
