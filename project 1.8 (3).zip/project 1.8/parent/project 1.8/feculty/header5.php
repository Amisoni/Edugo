<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sample Home Page</title>
<link rel="stylesheet" type="text/css" href="../css/popup.css" />
<script src="../css/popup1.js" type="text/javascript"></script>
</head>
<body style="margin:0px">
<div style="margin-top:-8px;"> 
<form method="get" style="margin-bottom:0px">
<table width="100%" bgcolor="#3745F0">
<tr>
	<td width="60%" height="110px" style="vertical-align: middle; font-size: 50px; font-family: Miriam; color: #FFFFFF; font-weight: bold;padding-left:25px"><div style="margin-left:5px">EduGo&nbsp;<img src="../registration/image/feculty.jpg" height="33px" width="33px" ></div></td>
    <td style="font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif;font-size:13px;font-weight:bold">
    	<?php 

			session_start();
                        include("../config.php");
			if($_SESSION['id']!="")
			{
			$id=$_SESSION['id'];
			
			$q="select * from feculty where ID=".$id;
			$res=mysql_query($q);
			$data=mysql_fetch_array($res);
			echo "<font color='#FFFFFF'>Welcome ".ucfirst($data['f_name'])." ".ucfirst($data['l_name'])."</font>";
			}
			else
			{
				header('location:../registration/first.php');	
			}
		?>
 </td>
   <td width="10%" style="vertical-align: middle; font-size: 20px; font-family: Miriam; color: #FFFFFF; font-weight: bold;"><a href="../logout.php?logout=1" style="color:#FFF"> Logout </a></td>
</tr>
</table>
</form>

<div id="overlay" style="height:800px;">
	<div class="over_box">
    <div id="close" style="width:10px;" onclick="toverlay()">X</div>
		<table align=javascript:document.forms['EditForm'].screen.value=3;document.forms['EditForm'].submit();"center">
<tr>
<td colspan="2" ><h2>Upload Images</h2></td>
</tr>
<tr>
<td>
<form method="post" action="header5.php" enctype="multipart/form-data">
<input type="file" name="fileupload" />
<input type="submit" name="submit" /> 
</form></td><td align="left">
           
                    </td></tr></table>
   </div>
</div>
<div>

<table width="100%" style="height:540px">
<tr>
<td width="200px" style="font-size:16px; vertical-align:top; border-right:Solid #03F 1px">
  <table width="200px" height="315" style="text-decoration:none; color: #36F; margin-left:30px;">
  <tr>
  <td width="10%" align="left" valign="top" >
<table align="left" height="60px" border="0">
<tr align="left">
 <?php

			include("../config.php");
			@session_start();
			
			if($_SESSION['id']!="")
			{
			$id=$_SESSION['id'];
			
		
			@$q="select * from feculty where ID=".$id;
			@$res=mysql_query($q);
			@$data=mysql_fetch_array($res);
			echo "<td width='50px' height='70px' align='left'><img src=".$data['image']." name='img1'  width='60px' height='60px'></td><td style='font-size:13px; width:100px; color:#36F;padding-top:10px;font-weight:bold'>".ucfirst($data['f_name'])." ".ucfirst($data['l_name'])."<br/><label style='font-size:11px;font-family:Calibri; color: #36F; text-decoration:underline; cursor:pointer;'><a href='profile_upload.php' target='ifrm'/>Edit Profile</a></label></td>";
			}
			if(isset($_POST['submit']))
			{
	
			if ($_FILES['fileupload']['type'] != 'image/jpeg')
			{
				echo "file not supported";
			}
			else
			{
			move_uploaded_file($_FILES['fileupload']['tmp_name'], "images/".$_FILES['fileupload']['name']);
			$filepath = "images/".$_FILES['fileupload']['name']; 
			
			if($_SESSION['id']!="")
			{
			$id=$_SESSION['id'];
			$q="select * from feculty where ID=".$id;
			$res=mysql_query($q);
			$data=mysql_fetch_array($res);
			
			}
			mysql_query("update feculty set image='$filepath' where id=$id" ) ;

			mysql_close($con);
			header('Location:header5.php');
			
	}
}
	?>
</tr>
<tr>
<td colspan="2">
<ul id="topul">
<li>
<img src="images/home.jpg" width="20px" height="20px" /> Home
</li>
<li><a href="teacherque.php"  target="ifrm" style="text-decoration:none">
<img src="images/question.jpg" width="20px" height="20px" /> Question Paper</a>
</li>
<li>
<img src="images/show.png" width="20px" height="20px" /> Show Details
</li>
<li>
<img src="images/career.jpg" width="20px" height="15px" /> Career
</li>
</ul>
</td></tr>
</table>

  </td>
  </tr>
          		
	
</table>
</td>
<td width="*" valign="top">
<iframe name="ifrm" height="530" frameborder="0"  style="width:100%; font-size: 0.8em;" />
</td>

</tr>
</table>
</div>
                      
                        
</div>
</body>
</html>
<!--</div>
<div id="menu" style="margin-top:0px;margin-left:-10px;margin-right:-8px;height:58px;width:101.90%";> 

  <head>
    <title></title>
</head>
<body bgcolor="#FFFFFF">
    <form id="form1">
  <table width="100%" height="100%">
  <tr>
  <td valign="top" style="border-right: dashed #00F" width="200px">
  <table width="200px" style="vertical-align:top; margin-left:30px; margin-top:30px">
            
    	<tr><td><a style="text-decoration:none; color: #36F;" href="#" shape="poly" target="ifrm">HOME</a></td></tr>
        <tr>
          <td><hr /></td>
        </tr>
        <tr>
        <td>
	<a href="teacherque.php"  target="ifrm" shape="poly" style="text-decoration:none; color: #36F;">QUESTION PAPER</a></td></tr>
        <tr>
          <td><hr /></td>
        </tr>
        <tr>
	<td><a href="#" shape="poly"  target="ifrm" style="text-decoration:none; color: #36F;">SUBJECT</a></td></tr>
        <tr>
          <td><hr /></td>
        </tr>
        <tr>
	<td><a href="#" shape="poly"  target="ifrm" style="text-decoration:none; color: #36F;">SHOW DETAILS</a></td></tr>
			
		</table>
        </td><td>
<iframe name="ifrm" frameborder="0" height="500px" style="width:100%; font-size: 0.8em;" />
</td>
</tr>
</table> 

    </form>
</body>
</div>
-->
	