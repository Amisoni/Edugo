<?php
include('../config.php');
session_start();
//$id=$_SESSION['id'];
$id=5;
@$result=mysql_query('SELECT * FROM exam_expert e, result r, sun s, student s1 WHERE s.p_id ='.$id.' AND r.sid = s.s_id AND e.r_id = r.rid AND s1.id = s.s_id');echo "<table width='60%'>";
while(@$data=mysql_fetch_array($result))
{
	echo "<tr><td rowspan='4'><img src='../student/".$data['image']."' /></td></tr>";
	echo "<tr><td>".$data['f_name']." ".$data['l_name']." Give Exam on ".$data['date']."</td></tr>";
	echo "<tr><td>Score:".$data['getmarks']."</td></tr>";
	echo "<tr><td>Total Marks:".$data['totalmarks']."</td></tr>";
	echo "<tr><td colspan='4'><hr /></td></tr>";
	//echo "</tr>";
}
mysql_close();
?>