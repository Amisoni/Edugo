<?php
include("../config.php");
session_start();
$id=$_SESSION['id'];
//echo "select * from s_info where s_id=".$id;
if(isset($_POST['saveimg']))
{
	if ($_FILES['sh_image']['type'] != 'image/jpeg')
			{
				echo "file not supported";
			}
			else
			{
			move_uploaded_file($_FILES['sh_image']['tmp_name'], "images/".$_FILES['sh_image']['name']);
			$filepath = "images/".$_FILES['sh_image']['name']; 
			
			if($_SESSION['id']!="")
			{
			$id=$_SESSION['id'];
			$q="select * from father where ID=".$id;
			$res7=mysql_query($q);
			$data7=mysql_fetch_array($res7);
			
			}
			mysql_query("update father set image='$filepath' where id=$id" ) ;
			}
		
}

$result1=mysql_query("select * from father where id=".$id);
$data1=mysql_fetch_array($result1);
$date=$data1['birth_date'];
$day=substr($date,8,2);
$month=substr($date,5,2);
$year=substr($date,0,4);

$result=mysql_query("select * from parent where p_id=".$id);
$data=mysql_fetch_array($result);
//echo $data[0];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sample Home Page</title>
<link rel="stylesheet" type="text/css" href="../css/popup.css" />
<script src="../css/popup1.js" type="text/javascript"></script>
<script>
function display(id)
{
	
	document.getElementById('s_add').style.display="none";
	document.getElementById('s_acc').style.display="none";
	document.getElementById('cpwd').style.display="none";
	document.getElementById('s_det').style.display="none";
	

	
	//document.getElementById('p_del').style.display="none";
	document.getElementById('s_det').style.display="none";
	//document.getElementById('p_del').style.display="none";
	//document.getElementById('pro').style.display="none";
	document.getElementById('archi').style.display="none";
	//alert("hi..");
	document.getElementById('s_add1').style.backgroundColor="gray";
	document.getElementById('cpwd1').style.backgroundColor="gray";
	document.getElementById('s_acc1').style.backgroundColor="gray";
	
	document.getElementById('s_det1').style.backgroundColor="gray";
	//document.getElementById('p_del1').style.backgroundColor="gray";
	//document.getElementById('pro1').style.backgroundColor="blue";
	document.getElementById('archi1').style.backgroundColor="gray";
	
	document.getElementById(id).style.display="table";
	var sid=id+"1";
	document.getElementById(sid).style.backgroundColor="white";
}

function Change_Address()
{	

document.getElementById("z_id").style.display="none"; 
var padd=document.forms["edit"]["tuaddress"].value;
var ptown=document.forms["edit"]["town"].value;
var ptadd=document.forms["edit"]["tpaddress"].value;
//var pcity=document.forms["edit"]["city"].value;
//var pstate=document.forms["edit"]["state"].value;
var pzip=document.forms["edit"]["zip"].value;
var pneigh=document.forms["edit"]["neigh"].value;
var a=document.getElementById("city");	
var city=a.options[a.selectedIndex].value;
var numbers = /^[0-9]+$/; 
 if((!numbers.test(pzip))|| pzip.length!=6)
      { 
	  document.getElementById("z_id").style.display="block"; 
	  document.getElementById("addmsg1").innerHTML=""; 
      
      }
	  else
	  {
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("addmsg1").innerHTML=xmlhttp.responseText;
    }
  	}
  //alert ("edit_php.php?padd="+padd+"&&ptown="+ptown+"&&pzip"+pzip+"&&pneg"+pneg+"&&tadd"+tadd);
	 xmlhttp.open("GET","edit_php.php?padd="+padd+"&&ptown="+ptown+"&&ptadd="+ptadd+"&&city="+city+"&&pzip="+pzip+"&&pneigh="+pneigh,true);
	 //xmlhttp.open("GET","edit_php.php?padd="+padd+"&&ppadd="+ppadd+"&&pcity="+pcity+"&&pzip="+pzip+"&&pneg="+pneg,true); 
	 xmlhttp.send();
	  }
}

function set_city()
{
	ddl = document.getElementById('city');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['p_city']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	ddl = document.getElementById('edudetail');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $data['p_edu']; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	<?php
  $d=explode("-",$data1['birth_date']);
  ?>
	ddl = document.getElementById('day');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[2]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}ddl = document.getElementById('month');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[1]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}ddl = document.getElementById('year');
	opts = ddl.options.length;
	for (i=0; i<opts; i++){
    if (ddl.options[i].value == '<?php echo $d[0]; ?>'){
        ddl.options[i].selected = true;
        break;
    }
	}
	
}

function Change_Qulification()
{

var a=document.getElementById("edudetail");	
var pqua=a.options[a.selectedIndex].value;


//alert(city);
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("addmsg2").innerHTML=xmlhttp.responseText;
    }
  	}
  //alert ("edit_php.php?padd="+padd+"&&ptown="+ptown+"&&pzip"+pzip+"&&pneg"+pneg+"&&tadd"+tadd);
	 xmlhttp.open("GET","edit_php.php?pqua="+pqua,true);
xmlhttp.send();
	
}
function Change_Password()
{
	
var old=document.forms["edit"]["opwd"].value;
var pwd=document.forms["edit"]["npwd"].value;
var cpwd=document.forms["edit"]["rpwd"].value;

	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("pmsg").innerHTML=xmlhttp.responseText;
    }
  	}
  
	 xmlhttp.open("GET","edit_php.php?old="+old+"&&new="+pwd+"&&cnew="+cpwd,true); 
	 xmlhttp.send();
}


function get_radio_value()
{
            var inputs = document.getElementsByName("sex");
            for (var i = 0; i < inputs.length; i++) {
              if (inputs[i].checked) {
                return inputs[i].value;
              }
      }
}
function Change_Account()
{	
document.getElementById("m_id").style.display="none"; 
var pocc=document.forms["edit"]["occ"].value;
var pday=document.forms["edit"]["day"].value;
var pmonth=document.forms["edit"]["month"].value;
var pyear=document.forms["edit"]["year"].value;
var pcontact=document.forms["edit"]["number1"].value;
var no=0;
var pcontact2=document.forms["edit"]["pnumber2"].value;
var psex = get_radio_value();
var numbers = /^[0-9]+$/; 
var msg="";
 if((!numbers.test(pcontact))|| pcontact.length!=10)
      { 
	  msg=msg+"Mobile No 10 Digit\n";
	  //document.getElementById("m_id").style.display="block"; 
	 // document.getElementById("addmsg3").innerHTML=""; 
     	no++;
		
      }  
	if(!numbers.test(pcontact2))
	{
		msg=msg+"Phone No.\n";
		no++;
	}
	if(no!=0)
	{
		//alert(msg);		
		    document.getElementById("addmsg3").innerHTML="<td colspan='2' style='color:red;'>Please Fill "+msg+"</td>" ;
	}
	else
	{
		
	if (window.XMLHttpRequest)
  	{// code for IE7+, Firefox, Chrome, Opera, Safari
  	xmlhttp=new XMLHttpRequest();
  	}
	else
  	{// code for IE6, IE5
  	xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  	}
  
  	
	xmlhttp.onreadystatechange=function()
  	{
  	if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("addmsg3").innerHTML=xmlhttp.responseText;
    }
  	}
  //alert ("edit_php.php?padd="+padd+"&&ptown="+ptown+"&&pzip"+pzip+"&&pneg"+pneg+"&&tadd"+tadd);
	 xmlhttp.open("GET","edit_php.php?pocc="+pocc+"&&pcontact="+pcontact+"&&pday="+pday+"&&pmonth="+pmonth+"&&pyear="+pyear+"&&pcontact2="+pcontact2+"&&psex="+psex,true);
	 //xmlhttp.open("GET","edit_php.php?padd="+padd+"&&ppadd="+ppadd+"&&pcity="+pcity+"&&pzip="+pzip+"&&pneg="+pneg,true); 
	 xmlhttp.send();
	 }
}


</script>

</head>
<body style="margin:0px" onload="set_city();">
<form name="edit" action="" method="post" enctype="multipart/form-data">

<table width="70%" align="center" border="1px">

<tr>
<td>
<table width="100%" style="vertical-align:top; text-transform:capitalize; color:#CCC; cursor:pointer;" cellpadding="0" cellspacing="0">
<tr bgcolor="gray" style="text-align:center; cursor:p">
<td id="archi1" bgcolor="#FFFFFF"><label onclick="display('archi')">Profile Picture</label></td>
<td id="s_add1" width="100px" height="30px;"><label onclick="display('s_add')">Address</label></td>
<td id="s_acc1" width="100px" height="30px;"><label onclick="display('s_acc')">Account Details</label></td>
<td id="s_det1"><label onclick="display('s_det')">Qualification</label></td>
<!--<td id="p_del1"><label onclick="display('p_del')">Class Details</label></td>-->

<td id="cpwd1" width="100px" height="30px;"><label onclick="display('cpwd')">Password</label></td>
</tr>
</table>
</td>
</tr>
<tr>
<td>

<table id="cpwd" width="60%" align="center" style="vertical-align:top; text-align:left; display:none;" cellpadding="5" cellspacing="5">
<tr>
<td colspan="3">
<h2><u>Change Password</u></h2>
</td>
</tr>
<tr><td>Old Password</td><td>:</td><td><input type="password" width="200px" name="opwd" /></td></tr>
<tr><td>New Password</td><td>:</td><td><input type="password" width="200px" name="npwd" /></td></tr>
<tr><td>Confirm Password</td><td>:</td><td><input type="password" width="200px" name="rpwd" /></td></tr>
<tr id="pmsg"></tr>
<tr><td colspan="3"><input type="button" name="password" id="password" value="Change Password" onclick="Change_Password()" />
<input type="button" id="submit" value="Save/Close" onclick="window.location='home.php';"/>
</td></tr>
</table>

<table id="s_add" width="60%" align="center" style="vertical-align:top; display:none;" cellpadding="5" cellspacing="5">
<tr>
	<td colspan="2"><h2><u>Address Detail</u></h2></td>
</tr>
<tr>	
        <td>
        <label>Permenent Address:</label>
        </td>
        <td>
        	<input type="text" name="tuaddress" id="tuaddress" value="<?php echo $data['p_p_add']; ?>" /></td>
            </tr>
		    <tr>   
            <td ><label>Town :</label></td><td><input type="text" width="200px" name="town" id="town" value="<?php echo $data['p_town']; ?>"/></td>
			</tr>
            <tr>
           <td ><label>City :</label></td><td>
           <select name="city" id="city">
        <option value="">--Select City--</option>   
		<option value="Ahmedabad">Ahmedabad</option>
		<option value="Baroda">Baroda</option>
		<option value="Surat">Surat</option>
		<option value="Bharuch">Bharuch</option>
            </select></td></tr>
			<tr>
            <td >
            <label>Zip code :</label></td><td><input type="text" width="200px" name="zip" id="zipcode" value="<?php echo $data['p_zipcode']; ?>" maxlength="6"/></td>
			</tr>
            <tr>
            <td >
            
 	        <label>Neighberhood :</label></td><td><input type="text" width="200px" name="neigh" id="neighberhood" value="<?php echo $data['p_neighbour']; ?>" /></td>
            </tr>
            
    
	
    <tr>
		<td>
			<label>Temparary Address:</label>
        </td>
        <td>
        	<input type="text" name="tpaddress" id="taddress" value="<?php echo $data['p_t_add']; ?>"/>
        </td>
	</tr>

<tr id="addmsg1"></tr>
<tr>
	   	<td colspan="2"><label id="z_id" style="color:#F00;display:none;">Enter Only 6 Digit</label></td>
</tr>
<tr>
	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('s_acc')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('s_acc')"/>
    <input type="button" name="save" value="Save" onclick="Change_Address()" />
    </th>
</tr>

</table>



<table align="center" cellpadding="5" cellspacing="5" id="s_det" style="vertical-align:top; display:none;" width="60%">

<tr>
	<td colspan="2"><h2><u>Education Detail</u></h2></td>
</tr>
<tr>
       	<td>
        	Education Detail :
        </td>
        <td>
        	<select name="edudetail" id="edudetail">
            <option selected="">--Select Education--</option>
            <option value="10th">10th</option>
            <option value="12th">12th</option>
            <option value="Graduate">Graduate</option>
            <option value="Post Graduate">Post Graduate</option>
            
            </select>
        </td>
        
       </tr>
<tr id="addmsg2"></tr>
<tr>
	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('cpwd')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('cpwd')"/>
    <input type="button" name="save" value="Save" onclick="Change_Qulification()" />
    </th>
</tr>
 </table>

<table id="archi" align="center" style=" width:60%; vertical-align:top;" cellpadding="5" cellspacing="5">
<tr>
	<td colspan="2"><h2><u>Profile Picture</u></h2></td>
</tr>
	<tr>
    	<td align="center">
        <img src='<?php echo $data1['image']; ?>' width="150" height="150" />
        
        </td>
    </tr>
    <tr align="center">
    	<td><input type="file" name="sh_image" id="sh_image" /></td>
    </tr>
    <tr>
    	<th></th>
    </tr>
	<tr>
	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('s_add')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('s_add')"/>
    <input type="submit" name="saveimg" />
    </th>
</tr>
    </table>
    
    
<table id="s_acc" width="70%" align="center" style="vertical-align:top; display:none;" cellpadding="5" cellspacing="5" border="0">
<tr>
	<td colspan="2"><h2><u>Account Detail</u></h2></td>
</tr>
<tr>
	<td class="label">First Name:</td>
	
	<td class="label"><input name="f_name" type="text" maxlength="20" placeholder="First Name" style="width:85px; height:18px; font-size:15px" onclick="validation('f_n')" value="<?php echo $data1['f_name']; ?>" readonly="readonly"/>
Last Name <input name="l_name" type="text" maxlength="20" placeholder="Last Name" style="width:85px; height:18px; font-size:15px" onclick="validation('l_n')" value="<?php echo $data1['l_name']; ?>" readonly="readonly"/></td>
</tr>

<tr>
	<td class="label">Occupation:</td>
	<td>
 <input type="text" name="occ" maxlength="50" placeholder="Enter Occupation" class="placeholder" onclick="validation('o_n')" value="<?php echo $data1['occ']; ?>"/>	
	</td>
</tr>

<tr>
	<td class="label">Email:</td>
	<td><input type="text" name="email" placeholder="Enter Email Address" class="placeholder" onclick="validation('e_i')" value="<?php echo $data1['email']; ?>" readonly="readonly"/>
</td>

</tr>

<tr>
	<td  class="label">Mobile:</td>
	<td>
    <input type="text" name="number1" maxlength="10" placeholder="Enter Mobile Number" class="placeholder" onclick="validation('m_n')" value="<?php echo $data1['contact']; ?>"/>
	</td>
</tr>

<tr>
	<td class="label">Phone No:</td>
	<td>
    <input type="text" name="pnumber2" class="placeholder" onclick="validation('p_n')" placeholder="Enter Phone Number"  maxlength="12"  value="<?php echo $data1['contact2']; ?>"/>
	</td>
</tr>

<tr>	
	<td class="label" >Birth Date:</td>
	
	<td class="placeholder">
	<select name="day" id="day">	
<?php
$i=1;
while($i<32)
{if($i<10){
echo "<option value=0$i>0".$i."</option>";}else
{echo "<option value=$i>$i</option>";}
$i++;
}
?>
	</select>
<select name="month" id="month">
<option value=01>Jan</option>
<option value=02>Feb</option>
<option value=03>Mar</option>
<option value=04>Apr</option>
<option value=05>May</option>
<option value=06>Jun</option>
<option value=07>Jul</option>
<option value=08>Aug</option>
<option value=09>Sep</option>
<option value=10>Oct</option>
<option value=11>Nov</option>
<option value=12>Dec</option>
</select>
<select name="year" id="year">

<?php
$i=1900;
while($i<2031)
{
echo "<option value=$i>$i</option>";
$i++;
}
?>
</select>
</td>
</tr>

<tr>
	<td class="label">Gender:</td>
	<td style="color:#000; font-size:15px">
	<?php 
    if($data1['sex']=="Male")
	{
		echo '<input name="sex" type="radio" value="Male" checked="checked"/>Male';
		echo '<input type="radio" name="sex" value="Female" />Female';	
	}
	else
	{
		echo '<input name="sex" type="radio" value="Male" />Male';
		echo '<input type="radio" name="sex" value="Female" checked="checked" />Female';	
	}
	
	?>
    </td>
</tr>
<tr id="addmsg3"></tr>
<tr>
	   	<td colspan="2">
        <label id="m_id" style="color:#F00;display:none;">Mobile No Should be 10 Digit.</label>
        <label id="p_id" style="color:#F00;display:none;">Please Fill Phone No.</label>
        </td>
</tr>
<tr>
	<th colspan="3"><input type="button" name="b_address" value="Next" onclick="display('s_det')"/>
    <input type="button" name="b_address" value="Skip" onclick="display('s_det')"/>
    <input type="button" name="save" value="Save" onclick="Change_Account()" />
    </th>
</tr>
  
</table>



</td>
</tr>
</table>
</form>
</body>
</html>