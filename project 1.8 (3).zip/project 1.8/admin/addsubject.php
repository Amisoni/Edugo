<?php
include("../config.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Subject</title>
</head>

<body>
<form action="" method="post">
<table>
<tr>
<td>
Class
</td>
<td>
:
</td>
<td>
<select name="class" id="class" style="width:205px;">
<?php 
$result=mysql_query("select * from class");
while($data=mysql_fetch_array($result))
{
	echo "<option value='".$data[0]."'>".$data[1]."</option>";
}
?>
</select>
</td>
</tr>
<tr>
<td>
Subject Name
</td>
<td>:
</td>
<td>
<input type="text" name="addsub" id=="addsub" style="width:200px;"/>
</td>
</tr>
<tr>
<td>
<input type="submit" value="Add Subject" name="submit" />
</td>
<?php
if(isset($_POST['submit']))
{
	mysql_query("insert into subject (c_id,sname) value(".$_POST['class'].",'".$_POST['addsub']."')");
	echo "<td colspan='2' style='color:#00FF00'>Record Successfully Inserted</td>";
}

?>
</form>
</body>
</html>