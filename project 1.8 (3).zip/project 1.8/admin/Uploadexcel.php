
<html>
<head>
</head>
<body>
<form name="newfile" action="#" method="post" enctype="multipart/form-data">
<table>
<tr>
<td>
File
</td>
<td>:</td>
<td><input type="file" name="excel" id="excel" />
</td>
<td>
<input type="submit" name="upload" id="upload" value="Submit"/>
</td>
</tr>

</table>
<?php

include("../config.php");
if(isset($_POST['upload']))
{
@require_once 'Excel/reader.php';
  {
	move_uploaded_file($_FILES['excel']['tmp_name'], "new/".$_FILES['excel']['name']);
	$filepath = "new/".$_FILES['excel']['name']; 
  
$data = new Spreadsheet_Excel_Reader();
$data->setOutputEncoding('CP1251');

$data->read($filepath);
error_reporting(E_ALL ^ E_NOTICE);
echo "<table>";
if($data->sheets[0]['numRows']>0&&$data->sheets[0]['numCols']==6)
{
for ($i = 2; $i <= $data->sheets[0]['numRows']; $i++) {
	//for ($i = 1; $i <=2; $i++) {
	echo "<tr>";
	echo "insert into chap2 (que,a,b,c,d,marks) values('".$data->sheets[0]['cells'][$i][1]."','".$data->sheets[0]['cells'][$i][2]."','".$data->sheets[0]['cells'][$i][3]."','".$data->sheets[0]['cells'][$i][4]."','".$data->sheets[0]['cells'][$i][5]."','".$data->sheets[0]['cells'][$i][6]."')";
	echo "<br />";
	//smysql_query("insert into chap2 (que,a,b,c,d,marks) values('".$data->sheets[0]['cells'][$i][1]."','".$data->sheets[0]['cells'][$i][2]."','".$data->sheets[0]['cells'][$i][3]."','".$data->sheets[0]['cells'][$i][4]."','".$data->sheets[0]['cells'][$i][5]."','".$data->sheets[0]['cells'][$i][6]."')");
	/*for ($j = 1; $j <= $data->sheets[0]['numCols']; $j++) 
	{
		//for ($j = 1; $j <= 2; $j++)
		//{ 
		echo "<td>".$data->sheets[0]['cells'][$i][$j]."</td>"; 	
	}*/
	echo "</tr>";

}
}
else
{
	echo "Please Provide Valid Excel File";
}
	
echo "</table>";
}
}
//print_r($data);
//print_r($data->formatRecords);
?>
</form>
</body>