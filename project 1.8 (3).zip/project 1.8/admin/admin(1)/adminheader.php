<?php include("header.php"); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table align="center" width="100%" border="1" bordercolor="#33CC66" cellpadding="0" cellspacing="0"  bgcolor="#3745F0" style="color:#FFF;margin-top:5px;">

<tr style="height:50px">
	<th ><a href="addsubject.php" style="color:#FFF" >Add Subject </a></th>
    <th ><a href="subject.php" style="color:#FFF" >View Subject </a></th>
	<th ><a href="addchap.php" style="color:#FFF" >Add Chapter </a></th>
    <th ><a href="chapter.php" style="color:#FFF" >View Chapter </a></th>
    <th ><a href="select_chp_sub_cla.php" style="color:#FFF">Add Question </a></th>
    <th ><a href="teacherque.php" style="color:#FFF">View Question </a></th>
    <th ><a href="viewque.php" style="color:#FFF">View All Question </a></th>

</tr>

</table>
</body>
</html>