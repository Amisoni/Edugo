<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<form action="p_insert.php" method="post">

<table align="center" border="1" width="420">
	<tr>
		<td>
			<label>profile Picture :</label>
		</td>
		<td colspan="2">
			<input type="file" name="profilephoto" id="profilephoto"/>
		</td>
	</tr>
	<tr>
		<td rowspan="6">
			<label>Address:</label><br />
        	
        </td>
        <td>
        <label>Permenent Address:</label>
        </td>
        <td>
        	<textarea name="paddress" id="paddress"></textarea><br />
		    <tr>   
            <td align="right"><label>Town :</label></td><td><input type="text" name="town" id="town"/></td>
			</tr>
            <tr>
           <td align="right"><label>City :</label></td><td><select name="city" id="city">
            <option>Ahmedabad</option>
            <option>Rajkot</option>
            <option>Diu</option>
            <option>Maheshana</option>
            <option>London</option>
            </select></td></tr>
			<tr>
            <td align="right">
            <label>Zip code :</label></td><td><input type="text" name="zipcode" id="zipcode" /></td>
			</tr>
            <tr>
            <td align="right">
            
 	        <label>Neighberhood :</label></td><td><input type="text" name="neighberhood" id="neighberhood" /></td>
            </tr>
            
    
	
    <tr>
		<td>
			<label>Temparary Address:</label>
        </td>
        <td>
        	<textarea name="taddress" id="taddress"></textarea>
        </td>
	</tr>
    <tr>
       	<td>
        	Education Detail :
        </td>
        <td>
        	<select name="edudetail" id="edudetail">
            <option>10th</option>
            <option>12th</option>
            <option>Graduate</option>
            <option>Post Graduate</option>
            
            </select>
        </td>
        
       </tr>
       <tr>
        <td align="right" colspan="3"><input type="submit" name="submit" id="submit" value="Save&Exit"/></td>
        </tr>
    </td>
    </tr>
    </table>
    </form>
</body>
</html>