<?php 
mysql_connect("localhost","root","");
mysql_select_db("eduvish");
$q="INSERT INTO parent (p_photo,p_p_add,p_town,p_city,p_zipcode,p_neighbour,p_t_add,p_edu)
value('$_POST[profilephoto]','$_POST[paddress]','$_POST[town]','$_POST[city]','$_POST[zipcode]','$_POST[neighberhood]','$_POST[taddress]','$_POST[edudetail]')";
echo $q;
mysql_query($q);
//mysql_close();
?>
