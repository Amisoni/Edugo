<html>
<head>
<title>Tutor</title>
</head>
<body>
<form action="t_insert.php" method="post">
<table border="1" align="center">
<tr>
<td><h2><u>Address</u></h2></td>
</tr>
<tr>
<td><h3>permanent Address</h3></td>
<td><textarea name="tuaddress" id="tuaddress"></textarea>
</td><tr><td><h3>temporary Address</h3></td>
<td><textarea name="tpaddress" id="tpaddress"></textarea>
</td></tr>
</tr>
<tr>
<td><h3>city:</h3></td>
<td>
<select name="city" id="city" value="Select city">
<option value="1">Select city</option>
<option value="ahmd">Ahmedabad</option>
<option>Baroda</option>
<option>Surat</option>
<option>Bharuch</option>
</select>
</td>
</tr>
<tr>
<td><h3>State:</h3>
</td>
<td>
<select name="state" id="state" value="Select state">
<option value="1">Select state</option>
<option value="ahmd">Gujarat</option>
<option>Maharashtra</option>
<option>Madhyadesh</option>
<option>Rajasthan</option>
</select>
</td>
</tr>
<tr>
<td><h3>Zip:</h3>
</td>
<td>
<input type="text" name="zip" />
</td>
</tr>
<tr>
<td><h3>Neighbourhood:</h3>
</td>
<td>
<input type="text" name="neigh"/>
</td>
</tr>


<tr>
<td><h2><u>Qualification:-</u></h2></td>
</tr>
<tr>
<td><h3>Educational Detais:</h3>
</td>
<td>
<select name="qualifi" id="qualifi" value="Select qualification">
<option value="1">---Select education--</option>
<option value="mca">MCA</option>
<option>MBA</option>
<option>ME</option>
<option>MED</option>
</td>
</select>
</tr>
<tr>
<td><h3>Upload Resume:</h3></td>
<td>
<input type="file" name="f1" id="f1" />

</td>
</tr>
<tr>
<td width="100px" class="label"><h3>Date Of Joining:</h3></td>
<td class="placeholder">
<select name="day">
<option value="--Day--">--Day--</option>
<?php
$i=1;
while($i<32)
{if($i<10){
echo "<option value=0$i>0".$i."</option>";}else
{echo "<option value=$i>$i</option>";}
$i++;
}
?>
</select>
<select style="" name="month">
<option value="--Month--">--Month--</option>
<option value=01>Jan</option>
<option value=02>Feb</option>
<option value=03>Mar</option>
<option value=04>Apr</option>
<option value=05>May</option>
<option value=06>Jun</option>
<option value=07>Jul</option>
<option value=08>Aug</option>
<option value=09>Sep</option>
<option value=10>Oct</option>
<option value=11>Nov</option>
<option value=12>Dec</option>
</select>
<select name="year">
<option value="--Year--">--Year--</option>
<?php
$i=1990;
while($i<2030)
{
echo "<option value=$i>$i</option>";
$i++;
}
?>
</select>
</td>
</tr>
<tr>
<td><h3>Experience:</h3></td>
<td><select name="exp" id="exp" value="Select exp">
<option value="1">---Select experience--</option>
<option value="1year">1year</option>
<option>2year</option>
<option>3year</option>
<option>4year</option>
<option>5year</option>
<option>6year</option>
<option>7year</option>
<option>8year</option>
<option>9year</option>
<option>10year</option>
</select>
</td>
</tr>

<tr>
<td><h2><u>Class Details</u></h2></td></tr>
<tr>
<td><h3>No of Sessions:</h3></td>
<td><select name="session" id="session" value="Select session">
<option value="1">---Select sessions--</option>
<option value="1">1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
</select>
</td>
</tr>
<tr>
<td><h3>No of Students:</h3></td>
<td>
<input type="text" name="stud" />
</td>
</tr>
<tr>
<td><h3>Timings:</h3></td>
<td><label>start time</label>
<input type="text" name="starttime">
<select name="ampm" id="ampm" value="Select ampm">
<option value="1">---Select ampm--</option>
<option value="AM">AM</option>
<option value="PM">PM</option>
</select><br />
<label>EndTime</label>
<input type="text" name="endtime">
<select name="ampm1" id="ampm" value="Select ampm">
<option value="1">---Select ampm--</option>
<option value="AM">AM</option>
<option value="PM">PM</option>
</select>
</td>
</tr>
<tr>
<td><h3>Expert Subject:</h3></td>
<td>
<select name="expert" id="expert" value="Select expert">
<option value="1">---Select subject--</option>
<option value="1">maths</option>
<option>english</option>
<option>science</option>
<option>computer</option>
</select>
</td>
</tr>

<tr>
<td><h3>Advanced Subject:</h3></td>
<td>
c<input type="checkbox" name="c" value="c" />

php<input type="checkbox" name="php" value="php" />
</td>
</tr>

<tr>
<td>
	<input type="submit" name="submit3" value="submit" />
    
    </td>
  </tr>
</table>
</form>
</body>
</html>