<?php 

include("../config.php");
session_start();
$id=$_SESSION['id'];
$q="INSERT INTO f_info (f_id,f_photo,f_p_add,f_town,f_city,f_zipcode,f_neighbourhood,f_t_add,f_edu,f_resume,f_yearofjoin,f_yearofexperiance,f_schoolname,f_principalname,f_contactno)
value(".$id.",'$_POST[profilephoto]','$_POST[address]','$_POST[town]','$_POST[city]','$_POST[zipcode]','$_POST[neighberhood]','$_POST[taddress]','$_POST[edudetail]','$_POST[resume]','$_POST[joinyear]','$_POST[expyear]','$_POST[schoolname]','$_POST[princename]','$_POST[contactno]')";
echo $q;
mysql_query($q);
//mysql_close();
?>
