<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form action="s_insert.php" method="post">
<table align="center" border="1" border="1">
	<tr>
		<td>
			<label>profile Picture :</label>
		</td>
		<td colspan="2">
			<input type="file" name="profilephoto" id="profilephoto"/>
            
            </td>
	</tr>
	<tr>
		<td rowspan="6">
			<label>Address:</label><br />
        	
        </td>
        <td>
        <label>Permenent Address:</label>
        </td>
        <td>
        	<textarea name="paddress" id="paddress"></textarea><br />
		    <tr>   
            <td align="right"><label>Town :</label></td><td><input type="text" name="town" id="town"/></td>
			</tr>
            <tr>
           <td align="right"><label>City :</label></td><td><select name="city" id="city">
            <option>Ahmedabad</option>
            <option>Rajkot</option>
            <option>Diu</option>
            <option>Maheshana</option>
            <option>London</option>
            </select></td></tr>
			<tr>
            <td align="right">
            <label>Zip code :</label></td><td><input type="text" name="zipcode" id="zipcode" /></td>
			</tr>
            <tr>
            <td align="right">
            
 	        <label>Neighberhood :</label></td><td><input type="text" name="neighberhood" id="neighberhood" /></td>
            </tr>
            
    
	
    <tr>
		<td>
			<label>Temparary Address:</label>
        </td>
        <td>
        	<textarea name="taddress" id="taddress"></textarea>
        </td>
	</tr>
    </td>
    </tr>
    <tr>
    	<td rowspan="3">
        	<label>Intrested</label>
        </td>
        <td align="right">
            <label>Hobby :</label>
            </td>
 
        <td>
        	<input type="text" name="hobby" id="hoby"/>
        </td>
         <tr>   
        <td align="right">
        	<label>Sports :</label>
        </td>
        <td>
        	<input type="text" name="sport" id="sport"/>
        </td>
        </tr>
         <tr>   
        <td align="right">
        	<label>Subject :</label>
        </td>
        <td>
        	<input type="text" name="subject" id="subject"/>
        </td>
        </tr>
        <tr>
        <td rowspan="3"><label>About you :</label></td>
        <td align="right"><label>Relegions :</label></td>
        <td><input type="text" name="Relegions" id="Relegions"/>
        </tr>
        <tr>
        <td align="right">
        	<label>language :</label>
            </td><td>
            <label>Gujrati</label><input type="checkbox" name="gujrati" id="gujrati" value="gujrati"/>
            <label>Hindi</label><input type="checkbox" name="Hindi" id="Hindi" value="Hindi"/>
            <label>English</label><input type="checkbox" name="English" id="English" value="English"/>
            
        </td>
        <tr>
        <td align="right">
        	<label>Discription :</label>
        </td>
        <td>
        	<input type="text" name="discription" id="discription"/>
        </td>
        </tr>
    </tr>
    <tr>
        <td rowspan="3"><label>About School :</label></td>
        <td align="right"><label>School Name :</label></td>
        <td><input type="text" name="schoolname" id="schoolname"/>
        </tr>
        <tr>
        <td align="right">
        	<label>School principal Name :</label>
        </td>
        <td>
        	<input type="text" name="sch_pri_name" id="sch_pri_name"/>
        </td>
        <tr>
        <td align="right">
        	<label>Contact Number :</label>
        </td>
         <td>
        	<input type="text" name="contactno" id="contactno"/>
        </td>
       </tr>
       
        <tr>
        <td align="right" colspan="3"><input type="submit" name="submit" id="submit" value="Save&Exit"/></td>
        </tr>
    </tr>
</table>
</form>
</body>
</html>