

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form action="f_insert.php" method="post">
<table align="center" border="1">
<tr>
		<th>
			profile Picture :
		</th>
		<td colspan="2">
			<input type="file" name="profilephoto" id="profilephoto"/>
            
            </td>
	</tr>
	<tr>
		<th rowspan="6">
		Address :
		</th>
        <th>
        Permenent Address:
        
        	<textarea name="address" id="address"></textarea></th>
            <tr>   
            <th>Town :<input type="text" name="town" id="town"/></th>
			</tr>
            <tr>
           <th>City :<select name="city" id="city">
            <option>Ahmedabad</option>
            <option>Rajkot</option>
            <option>Diu</option>
            <option>Maheshana</option>
            <option>London</option>
            </select></th></tr>
			<tr>
            <th>
            Zip code :<input type="text" name="zipcode" id="zipcode" /></th>
			</tr>
            <tr>
            <th>
            
 	        Neighberhood :<input type="text" name="neighberhood" id="neighberhood" /></th>
            </tr>
            
    
	
    <tr>
		<th>
			Temparary Address:
      
        	<textarea name="taddress" id="taddress"></textarea>
        </th>
	</tr>
        </td>
        
       </tr>
       <tr>
       	<th>
        	Education Detail :
        </th>
        <td>
        	<select name="edudetail" id="edudetail">
            <option>10th</option>
            <option>12th</option>
            <option>Graduate</option>
            <option>Post Graduate</option>
            
            </select>
        </td>
        
       </tr>
       <tr>
       <th>Upload Resume :</th>
		<td>
			<input type="file" name="resume" id="resume"/>
            
           </td>
	</tr>
	<tr>
    	<th rowspan="2">Designation :</th>
        
    	<th>Year of join :
       
        
        
        <select name="joinyear" id="joinyear">
            <option>Join Year</option>
            </select>
        </th>
        
        <tr>
        <th>Year of Experiance :
        
         <select name="expyear" id="expyear">
            <option>year of experiance</option>
            </select>
            
        </th>
        </tr>
        <tr>
        <th rowspan="3">School Detail</th>
        <th align="right">School name :
        <input type="text" name="schoolname" id="schoolname"/>
        </th>
       
        
        </tr>
        <tr>
        	<th align="right">Principal name :
        <input type="text" name="princename" id="princename"/>
        </th>
        </tr>
        <tr>
        	<th align="right">Contact No :
        <input type="text" name="contactno" id="contactno"/>
        </th>
        </tr>
         <tr>
        <td align="right" colspan="3"><input type="submit" value="Save&Exit"/></td>
        </tr>
       </tr>
    
</table>
</form>
</body>
</html>