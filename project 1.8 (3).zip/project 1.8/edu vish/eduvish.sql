-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 09, 2013 at 09:15 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eduvish`
--

-- --------------------------------------------------------

--
-- Table structure for table `f_info`
--

CREATE TABLE IF NOT EXISTS `f_info` (
  `f_id` int(20) NOT NULL auto_increment,
  `f_photo` varchar(200) NOT NULL,
  `f_p_add` varchar(200) NOT NULL,
  `f_town` varchar(50) NOT NULL,
  `f_city` varchar(20) NOT NULL,
  `f_zipcode` int(6) NOT NULL,
  `f_neighbourhood` varchar(50) NOT NULL,
  `f_t_add` varchar(200) NOT NULL,
  `f_edu` varchar(20) NOT NULL,
  `f_resume` varchar(200) NOT NULL,
  `f_yearofjoin` int(4) NOT NULL,
  `f_yearofexperiance` int(4) NOT NULL,
  `f_schoolname` varchar(50) NOT NULL,
  `f_principalname` varchar(50) NOT NULL,
  `f_contactno` int(10) NOT NULL,
  PRIMARY KEY  (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `parent`
--

CREATE TABLE IF NOT EXISTS `parent` (
  `p_id` int(10) NOT NULL auto_increment,
  `p_photo` varchar(200) NOT NULL,
  `p_p_add` varchar(200) NOT NULL,
  `p_town` varchar(50) NOT NULL,
  `p_city` varchar(50) NOT NULL,
  `p_zipcode` int(6) NOT NULL,
  `p_neighbour` varchar(20) NOT NULL,
  `p_t_add` varchar(200) NOT NULL,
  `p_edu` varchar(50) NOT NULL,
  PRIMARY KEY  (`p_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `s_info`
--

CREATE TABLE IF NOT EXISTS `s_info` (
  `s_id` int(20) NOT NULL auto_increment,
  `s_photo` varchar(200) NOT NULL,
  `s_p_add` varchar(200) NOT NULL,
  `s_town` varchar(50) NOT NULL,
  `s_city` varchar(20) NOT NULL,
  `s_zipcode` int(6) NOT NULL,
  `s_neighbour` varchar(20) NOT NULL,
  `s_t_add` varchar(200) NOT NULL,
  `s_hobby` varchar(50) NOT NULL,
  `s_sport` varchar(50) NOT NULL,
  `s_subject` varchar(20) NOT NULL,
  `s_relegions` varchar(20) NOT NULL,
  `s_language` varchar(20) NOT NULL,
  `s_description` varchar(200) NOT NULL,
  `s_schoolname` varchar(50) NOT NULL,
  `s_principalname` varchar(50) NOT NULL,
  `s_contactnumber` int(10) NOT NULL,
  PRIMARY KEY  (`s_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
