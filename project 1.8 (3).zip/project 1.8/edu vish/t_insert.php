<?php 
mysql_connect("localhost","root","");
mysql_select_db("eduvish");
$q="INSERT INTO tutor (t_p_add,t_city,t_state,t_zip,t_nb,t_edu,t_resume,t_date,t_exp,t_ses,t_noofstud,t_s_time,t_e_time,t_expsub,t_advancesub)
value('$_POST[tuaddress]','$_POST[tpaddress]','$_POST[city]','$_POST[state]','$_POST[zip]','$_POST[neigh]','$_POST[qualifi]','$_POST[f1]','".$_POST['year'].$_POST['month'].$_POST['day']."','$_POST[session]','$_POST[stud]','".$_POST['starttime'].$_POST['ampm']."','".$_POST['endtime'].$_POST['ampm1']."','$_POST[expert]','$_POST[c]/$_POST[php]')";
echo $q;
mysql_query($q);
//mysql_close();
?>
