-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 09, 2013 at 12:05 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `eduvish`
--

-- --------------------------------------------------------

--
-- Table structure for table `tutor`
--

CREATE TABLE IF NOT EXISTS `t_info` (
  `t_id` int(20) NOT NULL AUTO_INCREMENT,
  `t_p_add` varchar(200) NOT NULL,
  `t_city` varchar(50) NOT NULL,
  `t_state` varchar(20) NOT NULL,
  `t_zip` varchar(6) NOT NULL,
  `t_nb` varchar(50) NOT NULL,
  `t_edu` varchar(50) NOT NULL,
  `t_resume` varchar(200) NOT NULL,
  `t_date` date NOT NULL,
  `t_exp` varchar(50) NOT NULL,
  `t_ses` varchar(20) NOT NULL,
  `t_noofstud` varchar(50) NOT NULL,
  `t_s_time` varchar(20) NOT NULL,
  `t_e_time` varchar(20) NOT NULL,
  `t_expsub` varchar(20) NOT NULL,
  `t_advancesub` varchar(50) NOT NULL,
  PRIMARY KEY (`t_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;
