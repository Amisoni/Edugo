<TD align="center" valign="top">
<br />
<table width="100%" align="center">
<tr align="center">
<td width="160" height="160">
<a href="first.php"><img src="image/student`.jpg" class="rightImage" alt="Student Registration"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a></td>
<td width="160" height="160"><a href="parence.php">
<img src="image/parent1.jpg" alt="Parents Registration" class="rightImage"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a>
</td>
</tr>
<tr align="center">
<td colspan="2" width="160" height="160" align="center"><a href="tutor_teachar.php"><img src="image/tutor.jpg" class="rightImage" alt="Tutor Registration"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a> </td></tr>
<tr>
<td width="160" height="160" align="center"><a href="feculty.php"><img src="image/feculty1.jpg" alt="Feculty Registration" class="rightImage"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a>
</td>
<td width="160" height="160" align="center"><a href="school.php"><img src="image/sch.jpg" alt="School Registration" class="rightImage"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a>
</td>
</tr>


</table>
</td>