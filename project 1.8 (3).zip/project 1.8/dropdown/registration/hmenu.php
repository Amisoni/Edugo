<TD align="center" valign="top" width="60%">
<img src="image/arrow.jpg" width="260" height="60" style="margin-left:300px;" />
<table background="sflow.jpg" width="572px" height="400px" style="vertical-align:top"><tr>
<td width="500px" height=100px" colspan="4" align="center">
<a href="first.php"><img src="image/sch.jpg" style="width:100px;height:100px" /></a>
</td>
</tr>
<tr height="100px">
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td align="center" width="100px" height="120px" valign="bottom">
<a href="parence.php">
<img src="image/parent1.jpg" class="rightImage" alt="Student Registration"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a>
</td>
<td></td>
<td align="center" ></td>
<td align="center" width="100px" height="120px" valign="bottom"><a href="feculty.php"><img src="image/feculty1.jpg" alt="Feculty Registration" class="rightImage"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a></td>
</tr>
<tr>
<td></td>
<td align="center" width="100px" height="120px" valign="top">
<a href="tutor_teachar.php">
<img src="image/tutor.jpg" alt="Parents Registration" class="rightImage"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a>
</td>
<td align="center" width="100px" height="120px" valign="top"><a href="first.php"><img src="image/student`.jpg" alt="School Registration" class="rightImage"  onmouseover="this.className='mouseOver'" 
                    onmouseout="this.className='mouseOut'"/></a></td>
<td></td>
</tr>

</table>
</td>

