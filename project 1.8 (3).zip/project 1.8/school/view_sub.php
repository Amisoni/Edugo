<?php
include("../config.php");
if(isset($_GET['c_id']))
{
	echo "hi...";
	$result=mysql_query("select * from subject s, class c where c.c_id=s.c_id && s.c_id=".$_GET['c_id']);
	echo "<table>";
	while($data=mysql_fetch_array($result))
	{
		echo "<tr><td>".$data['c.cname']."</td><tr>";
	}
}

if(isset($_GET['del']))
{
	echo "hi...";
	$result=mysql_query("select * from subject s, class c where c.c_id=s.c_id && s.c_id=".$_GET['s_id']);
	echo "<table>";
	while($data=mysql_fetch_array($result))
	{
		echo "<tr><td>".$data['c.cname']."</td><tr>";
	}
}

?>