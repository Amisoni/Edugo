
<?php 
include("../config.php");
session_start();
$id=$_SESSION['id'];
if (isset($_GET['q']))
{

echo "<select id='subject' style='width:140px; font-size:15px;' onchange='showchap(this.value)'>";
echo "<option value=''>--Select Subject--</option>";
	if($_GET['q']!='no')
	{
	$sq="select * from subject where c_id=".$_GET['q'];
	$res=mysql_query($sq);
	while($data=mysql_fetch_array($res))
	{ 	echo $data['s_id'];
		echo "<option value='".$data['s_id']."'>".$data['sname']."</option>";	
	}
                   		
	}
	echo "</select>";
}
if(isset($_GET['cname']) && isset($_GET['sname']))
{
	$chpq="SELECT *
FROM expert_paper e, subject s, class c, sun s1
WHERE e.s_id = s.s_id
AND c.c_id = s.c_id
AND (
e.u_type != 'p'
OR (
s1.s_id =$id
AND e.u_id = s1.p_id
)
) ";
	//echo $chpq;
	$result=mysql_query($chpq);
	echo "<td colspan='3' align='center'><table border='1' width='80%'>";
	echo "<tr>
		<td>Paper ID</td><td>Class</td><td>Subject</td><td></td></tr>";
	$i=0;	

	
	while(@$data1=mysql_fetch_array($result))
	{
		echo "<tr style='text-transform:capitalize;'>
		<td>".$data1[0]."</td><td>".$data1['cname']."</td><td>".$data1['sname']."</td><td>".$data1[3]."</td><td><a href='expert_paper_exam.php?p_id=".$data1[0]."'>Give Exam</a></td></tr>";
		//echo "expert_paper_exam.php?p_id=".$data1[0]."<br/>";
		$i++;	
	}

	echo "</table></td>";
}
?>
